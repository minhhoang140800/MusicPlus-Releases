# Music Plus 1.0.1

Bản compact Windows x64, cần .NET Framework 4.8 và WebView2 Runtime.
Đây là bản kiểm chứng sau audit; chưa đưa vào kênh cập nhật stable.

## Cài và cập nhật giữ dữ liệu

1. Sao lưu `%LOCALAPPDATA%\MusicPlus8` trên chính máy của bạn.
2. Thoát hẳn Music Plus, kể cả biểu tượng khay hệ thống.
3. Giải nén toàn bộ ZIP, chép đè các file vào thư mục app cũ rồi mở `MusicPlus.exe`.

Đường dẫn dữ liệu không đổi. Không đóng gói tài khoản, settings, cache hoặc log trong ZIP.
Không gửi thư mục đăng nhập cho người khác: session được mã hoá theo tài khoản Windows.
Phiên cũ được đọc tương thích; lần đăng nhập mới lưu cookies và tài khoản đã chọn trong
một file mã hoá atomic `session-v10.bin`, có backup. File session cũ giữ để tương thích;
nếu quay lại bản 0.9.x sau khi đổi tài khoản ở 1.0.0, hãy đăng nhập lại trong bản cũ.

## Thay đổi chính

- Queue nhận diện mục playlist theo setVideoId: refresh không nhân đôi queue; các bản sao
  được thêm có chủ ý vẫn là những mục riêng. Giữ quy tắc không replay khi chọn bài đang nghe.
- Lỗi thao tác người dùng có thông báo; lỗi ảnh/tác vụ nền chỉ ghi log.
- Đổi tài khoản dừng tác vụ cũ, xoá view/queue cũ trước khi lưu snapshot mới. Cache audio
  và link stream được tách theo tài khoản. Lần nghe đầu sau nâng cấp có thể phải tải lại cache.
- Add đơn và nhiều bài dùng chung parser: ghép videoId với setVideoId, không dựa vào thứ tự
  kết quả. Thiếu/mâu thuẫn ID hoặc mất kết nối: báo kết quả chưa xác định, cần refresh trước
  khi retry. Không tự retry thao tác ghi. Remove chỉ xoá hàng sau xác nhận của server.
- Confirmed additions được giữ qua stale refresh tối đa 30 phút, cache có giới hạn;
  khi quan sát được mục từ server thì bỏ bản bù. Đây không phải đồng bộ giao dịch vĩnh viễn.
- Settings chặn phím tắt chính phía sau overlay. Trang artist chỉ theo shelf Songs/Top songs
  có endpoint; artist/album có nhiều shelf hợp lệ sẽ báo lỗi thay vì chọn đại.
- Lỗi giới hạn vùng/Premium không tự đánh dấu bài là đã bị xoá vĩnh viễn.
- Bỏ CLI/probe/test và fixture khỏi exe; bỏ cache tổng thời lượng và icon trùng.
  Bỏ quét cây process mỗi giây. Chẩn đoán RAM chỉ lấy khi cần, phân biệt working set/private bytes.
- Giảm polling Library: khi đang active tối đa mỗi 5 phút, activation tối thiểu cách 2 phút;
  nút Refresh vẫn có thể dùng ngay.

Giữ các tính năng 0.9.4: copy/chọn text, triple-click, hover từng artist, Ctrl/Shift multi-select,
Add picker một click có ảnh, cảnh báo trùng, link search, Back search, Lyrics, kéo thả Library,
và cột Views/Artist/Album theo từng loại màn hình.

## Cập nhật từ Settings

Nút Check for updates chỉ kiểm tra và tải ZIP sau khi kiểm checksum, đường dẫn, phiên bản
và đủ dependencies. Không chạy PowerShell chép đè file, không tự đóng app để cài.
Tạm cập nhật thủ công sau tải; cơ chế tự cài/rollback cũ đã bị xoá vì chưa được kiểm thử Windows.
SHA-256 bảo vệ tính toàn vẹn, không thay thế chữ ký nhà phát hành. Bản này chưa có Authenticode.

## Source, build và kiểm chứng

Source chỉ ở repo private `minhhoang140800/MusicPlus`; public `MusicPlus-Releases` chỉ chứa
ZIP, checksum và ghi chú. Không có dịch vụ cập nhật hoặc browser chạy nền mới.

- Cài SDK theo `global.json`, chạy `./Build.ps1` trên Windows. Script đọc version từ csproj,
  xoá stage/build cũ, đóng gói đủ Engine/dependencies/licenses và tạo SHA256.json.
- Portable: `dotnet run --project tests/tests.csproj -f net8.0 -c Release`.
- Framework thật: build `tests/tests.csproj -f net48`, chạy `tests.exe` trên Windows.
- Windows storage/WPF smoke: build `tests-windows/windows.csproj`, chạy `windows.exe`.
  Dùng thư mục tạm; không cần account hay gọi API thật.
- GitHub Actions chạy các bước trên ở Windows khi push, nhưng chỉ upload artifact;
  không tự phát hành stable. Kết quả thực tế và giới hạn ghi ở CHANGELOG-1.0.0.md.

Source khôi phục từ binary 0.8.11, không phải source gốc. Audio engine native giữ nguyên
bản đã khôi phục; thiếu source/build recipe engine. `DEPENDENCIES.md` ghi hash và nguồn gốc
của từng runtime kèm license. Chưa thể cam kết đủ điều kiện phân phối cho hàng nghìn người.

## Còn phải kiểm chứng

WPF/login/audio thật, tài khoản Free/Premium, hết bài tự next, seek, retry khi mất mạng,
đổi account khi đang thao tác, ZIP update và rollback trên Windows. Cold audio vẫn cần
API + decipher + tải toàn bài + remux; không có benchmark chứng minh đã nhanh hơn hoặc
RAM thấp hơn. Eager paging, đồng bộ playlist khi chỉnh từ nơi khác, tính bất biến của model,
và kiểm chứng nguồn gốc native engine còn là công việc tiếp theo. Không dùng số phiên bản
1.0.0 làm bằng chứng rằng tất cả điểm audit đã được giải quyết.

## 1.0.1

Lyrics: tên bài, artist và lời bài hát có thể chọn/copy bằng Ctrl+C hoặc menu chuột phải. Flyout giữ tên bài/artist khi pause; chỉ nút điều khiển đổi trạng thái. Build và 102 portable checks đạt; thao tác WPF cần thử trên Windows.

# Music Plus 1.0.2

Windows x64, .NET Framework 4.8 và WebView2 Runtime. Source chỉ ở GitHub private;
repo public MusicPlus-Releases chỉ chứa gói chạy, checksum, manifest và release notes.

## Cài một lần

1. Thoát Music Plus cũ, kể cả khay hệ thống.
2. Giải nén toàn bộ ZIP vào thư mục bạn có quyền ghi, ví dụ `D:\MusicPlus`.
3. Luôn mở `MusicPlus.exe` ở thư mục ngoài cùng. Có thể tạo shortcut tới file này.

Giữ nguyên thư mục `versions` và `current.json`; không chỉ chép riêng exe bên trong ra ngoài.
Không dùng thư mục Program Files cần quyền admin. Không xoá `%LOCALAPPDATA%\MusicPlus8`:
đăng nhập, settings, metadata, thứ tự Library vẫn ở đó. Không gửi dữ liệu đăng nhập cho người khác.
Từ các bản <=1.0.1 cần cài gói này một lần vì đổi cấu trúc cài đặt.

## Cập nhật qua GitHub

Trong Settings bấm **Check for updates**. App kiểm tra stable `update.json`, tải ZIP và kiểm
SHA-256, đủ dependencies, từng file, đường dẫn và version. Nếu có bản mới, app chuẩn bị nó
trong `versions/<version>` rồi khởi động lại. Không cần tải/giải nén thủ công mỗi bản nữa.
Không có tiến trình updater chạy nền thường trực hoặc GitHub token trên máy người dùng.

File ngoài cùng là launcher cố định cho layout `versioned-v1`. Khi cài bản mới, launcher chờ
app cũ đóng và chờ bản mới báo giao diện đã khởi tạo. Chỉ sau đó mới đổi `current.json`
atomic và giữ Previous. Nếu bản mới lỗi lúc khởi động, launcher mở lại bản cũ. Nếu mất điện
sau khi chuẩn bị, lần mở tiếp theo xử lý transaction đang dở. Không chép đè file app đang chạy.
Cơ chế này kiểm tra khởi tạo, không bảo đảm phát hiện mọi lỗi xảy ra sau khi app đã mở.
Các bản app/dependencies tương thích layout v1 dùng được cùng launcher; thay runtime hoặc
protocol launcher ngoài v1 có thể cần gói cài mới.

Manifest dùng TLS và checksum trên GitHub. SHA-256 bảo vệ tính toàn vẹn, không thay thế
chữ ký nhà phát hành. Chưa có Authenticode. Source/build recipe native audio engine còn thiếu.

## Clear unused cache

Settings có nút xoá cache không dùng: ảnh cache, audio không được bảo vệ cho bài đang phát/
chuẩn bị, phiên bản cũ hơn bản dùng để rollback, staging thất bại và ZIP updater cũ.
Không xoá sign-in, settings, metadata, ảnh cover tự sửa, file tải đang dở, phiên bản hiện tại,
Previous hoặc pending version. File bị Windows khoá sẽ được bỏ qua. Clear không chạy lúc update.
Giữ Previous giúp cập nhật lỗi có thể quay về; vì vậy nút này không xoá toàn bộ dữ liệu trên đĩa.

## Tính năng được giữ

Copy/select title/artist/album và Lyrics; flyout giữ metadata khi pause. Ctrl/Shift nhiều bài,
Add picker có ảnh một click, cảnh báo trùng, link search, Back search, Lyrics, Library order,
Views/Artist/Album theo màn hình. Các sửa queue, session và mutation từ 1.0.0 được giữ.

## Build / kiểm chứng

`global.json` ghim SDK. Windows: `./Build.ps1` tạo ZIP versioned và checksum.
Portable: `dotnet run --project tests/tests.csproj -f net8.0 -c Release`.
Framework thật: build tests/tests.csproj -f net48 rồi chạy tests.exe trên Windows.
Windows storage/WPF: tests-windows/windows.csproj.
Launcher: `dotnet build launcher/launcher.csproj -f net48 -c Release`.
Process recovery test: build launcher -f net8.0, chạy tests/installer-process-test.py với dotnet
và đường dẫn output net8. Test dùng executable giả; không dùng tài khoản hoặc mạng.

118 portable checks và 14 launcher process checks đạt trên Linux; app, launcher và Windows
tests cross-build được. Chưa chạy vòng restart/update WPF net48 thật trên Windows.
Chưa benchmark RAM/latency; cold audio vẫn tải/remux toàn bài. Giữ các giới hạn Free/native
engine và đồng bộ playlist đã ghi ở CHANGELOG-1.0.0.md. Nguồn runtime: DEPENDENCIES.md.

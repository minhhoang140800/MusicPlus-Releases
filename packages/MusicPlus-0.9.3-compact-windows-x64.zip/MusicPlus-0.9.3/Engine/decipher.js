const __jsExtractorGlobal = typeof globalThis !== 'undefined' ? globalThis :
  typeof self !== 'undefined' ? self :
  typeof window !== 'undefined' ? window :
  typeof global !== 'undefined' ? global : {};

const exportedVars = (function(g) {
  const window = typeof __jsExtractorGlobal.window !== 'undefined' ? __jsExtractorGlobal.window : Object.create(null);
  const document = typeof __jsExtractorGlobal.document !== 'undefined' ? __jsExtractorGlobal.document : {};
  const self = typeof __jsExtractorGlobal.self !== 'undefined' ? __jsExtractorGlobal.self : window;

  var Xx, Q, m4, zp, jd, T8, s9, lp3, wQw, Hh, Igg, tP, kp, Dz, oXT, vO, QY1, rI, PO, Uj, Jco, G1y, BM7, KO7, kYY, KcT, h4Y, pU, bU6, fP, vg, UP7, Nd, dY, du, fpN, lay, ti, zJ, RD, vs, LU, Db, pq, Je, q2, GK, v6, rG, VG, xL, ZK, SN, qw, M9o, EG, FZ, RE, O8, U8, xew, me, v7, wJw, bt, m2, Lp, Xb, c6, B_0, br, Kq, eN, JN, ih0, j_, kf, zx, yR, B9o, N90, Uo, P8, rf, v8, wj1, bl, rM, RY, Vj, Oh, YX, Q1q, NP, Qw, ylG, JlA, G24, ZH, eGw, X5, W8, QHT, pj7, MZ, df, F$, MdY, qZ, W46, nlg, Iro, Th, iXy, Y16, xH, Eo, XZw, fW, hzY, SB, I$, SpY, tA, Tq7, sHT, fdo, nW, jX0, Cw, g6, Xh, ch, $q, AS, tdY, c46, $0o, H8, a$, z5, Sc, GF, yl, Eg, Ff, d8, xp, AP, JP, lr3, Vd$, Rzq, mU, hA, cc, D0w, pW, K4N, m01, p5I, QS, eyY, rD, qp0, Eo6, dPw, now, y1T, oow, Gu7, iI$, DW, ldo, J17, O$, DR, aEq, iA, PH, Ik, hbY, KK, LCq, uDw, ZPY, Us, Qto, oST, cH, bA, hi, LK, Zn, SAg, yQg, jG, Ia3, Ok6, Ak, xq, Png, nQ, uX, gL, Yf, yG, Ae, H4, Xj, Bs, te, mi, DT, xf, r1w, Qg, lX, Nw, QG, oD, wL, nq, Ws, cV, EV, voY, W6, Gx, o1, jX, np, sC, e_, Cp, Tx, DPg, eU, V8y, BZT, GC3, QXy, OIY, Ktw, Nq0, ct, $g, szy, ec, Go, R9$, YAg, yv, Zko, Xq3, gSq, Id3, M8q, CR, goT, S11, Fxg, jBN, e4q, aK6, sE7, fK6, q80, Trq, zS, F86, Bx, px, Gy, Qzg, oBw, me6, e4, W8w, K8q, Mq1, Urq, Yp, w8, o3o, Ql, z4, ixw, yP, xr$, px6, jl, yU, kg, BbT, Pt, CoN, Ep1, Iw, Li, EdN, dr, a4Y, s8, B5, OvY, mF, kew, Uy, mr, c10, UH1, lj, oEN, Ey, F5, HzN, EE7, uv, WJy, izy, INy, Zp, CqT, wp, Bt, xg, Ge3, sy, tc, S2o, yK0, cQ, $X, JKY, mO, xH1, AKw, dHY, Ht, oe, NT, BSg, TS, QM, FJq, c8, uG, h2, HH, WCg, VUy, kS, RH, XP, vu1, Op, gq, LI, Dq0, h1, VX3, Y83, Dd, Zd, OUT, Vw, XVg, t1, qv, eG, iPy, nZT, JZ, Ax6, jB, Tug, kH, A2, dby, EZY, qa6, HPo, C17, FC6, KCg, Nu0, Dg0, dq, CI, nx, wb, BuY, lto, Sa1, Cn6, kCw, zzN, HIy, CK, ft7, t2, zh, s56, at$, ebw, Jxo, yxT, M3w, Gs6, a5, fT$, ek$, CP, XT, $q6, tX6, sa, ujw, Ea, s1w, aT3, z4q, kiq, jE$, TGT, wqw, fR, ik7, af, Ej, U7y, MQq, NU, sV, AT, jN, Zb, x00, B6, pp, FL, AQN, d7w, ij, nw, Wl, Gjg, sj, Ce6, Dn, vH, Og, t30, zbw, j56, stw, e9$, FHq, T9q, qA$, Os, wZ0, aaw, faN, YJ, ex, bj, apw, M7, r9, Gb, vq, EA0, s_3, elY, aX0, UI, It, ie, Kk, F01, T17, RL$, F2, zC, S4, GbN, jY, Lgq, aS1, uk, e7o, hQ, Diw, y0T, g_T, yhN, nyq, Vp0, SZq, Jhw, FtT, gS, KMq, adg, XJN, ZVN, r2w, OZY, gd$, olq, uQT, DuT, Hj;

  //#region --- start [nsigFunction] ---
  Q = "splice;K;://;;match;length;call;n;r;path;set;B;push;split;()[,;,;fromCharCode;reverse;scheme;indexOf;url;cmo=pf;slice;redirector.googlevideo.com;UA;playerfallback;unshift;undefined;s;Jj;\\.a1\\.googlevideo\\.com$;startsWith;a1.googlevideo.com;local;S;j;clone;join;fallback_count;www.youtube.com;il;%3D;/;1969-12-31T14:16:04.000-09:45;1970-01-01T10:45:22.000+10:45;signatureCipher;rr?[1-9].*\\.c\\.youtube\\.com$;forEach;1;hA;/initplayback;pop;dN;youtube.player.web_20261014_11_RC00;/videoplayback;&;index.m3u8;replace;mn;false;/api/manifest;toString;eN;file;1970-01-01T07:31:09.000+07:30;fvip;\\.googlevideo\\.com$;sp;assign;=;get;A;cmo=td;1969-12-31T20:00:32.000-04:00;1970-01-01T09:15:06.000+09:15;yR;cmo;mMZnNSxqPSQhKIB-93-_w8_;//;rr;1970-01-01T10:15:42.000+10:15;/file/index.m3u8;Untrusted URL;http://local;https://local".split(";");
  g.vc = class extends Error{constructor(f,...a){super(f);this.args=[...a];Object.setPrototypeOf(this,new.target.prototype)}};
  var pO6 = RegExp("^((http(s)?):)?\\/\\/((((lh[3-6](-tt|-d[a-g,z])?\\.((ggpht)|(googleusercontent)|(google)|(sandbox\\.google)))|(lh7\\-(eu|us|qw|rt|xx)\\.((googleusercontent)|(google)))|((photos|testonly|work)\\.fife\\.usercontent\\.google)|([\\w\\-]+\\.fife\\.usercontent\\.google)|(([1-4]\\.bp\\.blogspot)|(bp[0-3]\\.blogger))|(ccp-lh\\.googleusercontent)|((((cp|ci|gp)[3-6])|(ap[1-2]))\\.(ggpht|googleusercontent))|(gm[1-4]\\.ggpht)|(play-(ti-)?lh\\.googleusercontent)|(gz[0-1]\\.googleusercontent)|(lh3\\-gm\\.google)|(((yt[3-4])|(sp[1-3]))\\.(ggpht|googleusercontent)))\\.com)|(drive\\.google\\.com\\/drive\\-(usercontent|viewer))|(dp[3-6]\\.googleusercontent\\.cn)|(dp4\\.googleusercontent\\.com)|((photos|drive|contribution)\\-image\\-(dev|qa)(-us|-eu)?(-auth|-cookie)?\\.corp\\.google\\.com)|(photos\\-image\\-dev\\-dl\\-(auth|eu|us)\\.corp\\.google\\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\\.sandbox\\.google\\.com\\/image)|(image\\-(dev|qa)\\-lighthouse(-auth)?\\.sandbox\\.google\\.com(\\/image)?)|(drive\\-qa\\.corp\\.google\\.com\\/drive\\-(usercontent|viewer))|(docs(\\-(dev|qa)\\.corp)?\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|brands|email\\-layouts)\\-images\\-(rt|qw|xx))|(docs\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|brands|email\\-layouts)\\-images)|(sites\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(atari-green-test\\.corp\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(sites\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images))\\/|^https://([A-Za-z0-9-]{1,63}\\.)+demos\\.corp\\.google\\.com(/(?!url\\b)|$)|^https://([A-Za-z0-9-]{1,63}\\.)+sslproxy\\.corp\\.google\\.com(/|$)|^https?://(([A-Za-z0-9-]{1,63}\\.)*(corp\\.google\\.com|proxy\\.googleprod\\.com|c\\.googlers\\.com|proxy\\.googlers\\.com|borg\\.google\\.com|docs\\.google\\.com|drive\\.google\\.com|googleplex\\.com|googlevideo\\.com|prod\\.google\\.com|lh3\\.photos\\.google\\.com|mail\\.google\\.com|youtube\\.com|yt\\.akamaized\\.net|chat\\.google\\.com)[.]?(:[0-9]+)?/|([A-Za-z0-9-]{1,63}\\.)*(sandbox\\.google\\.com)(:[0-9]+)?(/(?!url\\b)|$)|([A-Za-z0-9-]{1,63}\\.)*c\\.lh3(-d[a-gyz]|-testonly)?\\.(googleusercontent|photos\\.google)\\.com/.*$)");
  var BIY = RegExp("^https?://([A-Za-z0-9-]{1,63}\\.)*(currents\\.google\\.com)[.]?(:[0-9]+)?/");
  var yRg = !1;
  T8 = function(f,a,e){return a&&a.test(f)||yRg&&e&&e.test(f)?!0:!1};
  g.S6 = {};
  var jwF = {};
  var Yg = {};
  g.gp = function(f,a){return f in Yg?Yg[f]:a};
  wQw = function(f,a={}){if(f=f.Yw){let e=f.Xck;f=[["componentStack",f.Hl],["wizTagName",f.tagName],["wizOwnerTrace",f.pbk?.join(" > ")],["errorSeverity",f.I2?.toString()],["wizFeatureFlags",e?Object.entries(e).join("\n"):void 0]];for(let [T,q]of f)f=q,f!==void 0&&(a[T]=f)}return a};
  Hh = function(f,a){f=g.gp("EXPERIMENT_FLAGS",{})[f];return f!==void 0?f:a};
  g.C2 = function(f,a){f=Hh(f,a);return typeof f==="string"&&f==="false"?!1:!!f};
  var WO1 = [];
  var ig$ = [];
  g.yY = function(f,a){f=f.split(".");a=a||g.S6;for(var e=0;e<f.length;e++)if(a=a[f[e]],a==null)return null;return a};
  kp = function(f){var a="";typeof f.toString==="function"&&(a=""+f);return a+f.stack};
  tP = function(f,a){a||(a={});a[kp(f)]=!0;var e=f.stack||"",T=f.cause;T&&!a[kp(T)]&&(e+="\nCaused by: ",T.stack&&T.stack.indexOf(T.toString())==0||(e+=typeof T==="string"?T:T.message+"\n"),e+=tP(T,a));f=f.errors;if(Array.isArray(f)){T=1;let q;for(q=0;q<f.length&&!(T>4);q++)a[kp(f[q])]||(e+="\nInner error "+T++ +": ",f[q].stack&&f[q].stack.indexOf(f[q].toString())==0||(e+=typeof f[q]==="string"?f[q]:f[q].message+"\n"),e+=tP(f[q],a));q<f.length&&(e+="\n... "+(f.length-q)+" more inner errors")}return e};
  var zF = {};
  Igg = function(f){var a=g.yY("window.location.href");f==null&&(f='Unknown Error of type "null/undefined"');if(typeof f==="string")return{message:f,name:"Unknown error",lineNumber:"Not available",fileName:a,stack:"Not available"};var e=!1;try{var T=f.lineNumber||f.line||"Not available"}catch(F){T="Not available",e=!0}try{var q=f.fileName||f.filename||f.sourceURL||g.S6.$googDebugFname||a}catch(F){q="Not available",e=!0}a=tP(f);if(!(!e&&f.lineNumber&&f.fileName&&f.stack&&f.message&&f.name)){e=f.message;
if(e==null){if(f.constructor&&f.constructor instanceof Function){if(f.constructor.name)e=f.constructor.name;else if(e=f.constructor,zF[e])e=zF[e];else{e=String(e);if(!zF[e]){let F=/function\s+([^\(]+)/m.exec(e);zF[e]=F?F[1]:"[Anonymous]"}e=zF[e]}e='Unknown Error of type "'+e+'"'}else e="Unknown Error of unknown type";typeof f.toString==="function"&&Object.prototype.toString!==f.toString&&(e+=": "+f.toString())}return{message:e,name:f.name||"UnknownError",lineNumber:T,fileName:q,stack:a||"Not available"}}return{message:f.message,
name:f.name,lineNumber:f.lineNumber,fileName:f.fileName,stack:a}};
  Dz = function(f){try{return(typeof f==="string"?f:String(JSON.stringify(f))).substr(0,500)}catch(a){return`unable to serialize ${typeof f} (${a.message})`}};
  vO = function(f,a,e,T){e+=`.${f}`;f=Dz(a);T[e]=f;return e.length+f.length};
  rI = function(f){var a=f(),e=a&127;if(a<128)return e;a=f();e|=(a&127)<<7;if(a<128)return e;a=f();e|=(a&127)<<14;if(a<128)return e;a=f();return a<128?e|(a&127)<<21:Infinity};
  QY1 = function(f){var a=f.length,e=0,T=()=>f.charCodeAt(e++);
do{var q=rI(T);if(q===Infinity)break;let F=q>>3;switch(q&7){case 0:q=rI(T);if(F===2)return q;break;case 1:if(F===2)return;e+=8;break;case 2:q=rI(T);if(F===2)return f.substr(e,q);e+=q;break;case 5:if(F===2)return;e+=4;break;default:return}}while(e<a)};
  oXT = function(f,a,e,T){if(f)if(Array.isArray(f)){var q=T;for(T=0;T<f.length&&!(f[T]&&(q+=vO(T,f[T],a,e),q>500));T++);T=q}else if(typeof f==="object")for(q in f){if(f[q]){a:{var F=q;var E=f[q],H=a,C=e;if(typeof E!=="string"||F!=="clickTrackingParams"&&F!=="trackingParams"){F=0;break a}F=(E=QY1(atob(E.replace(/-/g,"+").replace(/_/g,"/"))))?vO(`${F}.ve`,E,H,C):0}T+=F;T+=vO(q,f[q],a,e);if(T>500)break}}else e[a]=Dz(f),T+=e[a].length;else e[a]=Dz(f),T+=e[a].length;return T};
  var pQY = class{constructor(){this.Lv=[];this.mT=[]}};
  Uj = undefined;
  Jco = function(f){if(f.name==="JavaException")return!0;f=f.stack;return f.includes("chrome://")||f.includes("-extension://")||f.includes("webkit-masked-url://")};
  G1y = function(f){if(!f.stack)return!0;var a=!f.stack.includes("\n");return a&&f.stack.includes("ErrorType: ")||a&&f.stack.includes("Anonymous function (Unknown script")||f.stack.toLowerCase()==="not available"||f.fileName==="user-script"||f.fileName.startsWith("user-script:")?!0:!1};
  var NM6 = {};
  BM7 = function(f,a){a.mT&&f.mT.unshift.apply(f.mT,a.mT);a.Lv&&f.Lv.unshift.apply(f.Lv,a.Lv)};
  PO = function(){if(!Uj){var f=Uj=new pQY;f.mT.length=0;f.Lv.length=0;BM7(f,NM6)}return Uj};
  var Ip0 = [];
  g.th = function(){this.L9=this.L9;this.pG=this.pG};
  g.Kg = function(f){g.th.call(this);this.G=1;this.K=[];this.A=0;this.j=[];this.B={};this.W=!!f};
  g.U = g.Kg.prototype;
  g.U.subscribe = function(f,a,e){var T=this.B[f];T||(T=this.B[f]=[]);var q=this.G;this.j[q]=f;this.j[q+1]=a;this.j[q+2]=e;this.G=q+3;T.push(q);return q};
  g.U.unsubscribe = function(f,a,e){if(f=this.B[f]){let T=this.j;if(f=f.find(function(q){return T[q+1]==a&&T[q+2]==e}))return this.Pc(f)}return!1};
  g.sI = function(f,a){return Array.prototype.splice.call(f,a,1).length==1};
  g.T4 = function(f,a){a=Array.prototype.indexOf.call(f,a,void 0);var e;(e=a>=0)&&g.sI(f,a);return e};
  g.U.Pc = function(f){var a=this.j[f];if(a){let e=this.B[a];this.A!=0?(this.K.push(f),this.j[f+1]=()=>{}):(e&&g.T4(e,f),delete this.j[f],delete this.j[f+1],delete this.j[f+2])}return!!a};
  pU = function(f){g.S6.setTimeout(()=>{throw f;},0)};
  var Mb6 = class{constructor(){this.next=this.scope=this.j=null}set(f,a){this.j=f;
this.scope=a;this.next=null}reset(){this.next=this.scope=this.j=null}};
  var iE0 = class{constructor(f,a){this.K=f;this.A=a;this.B=0;this.j=null}get(){if(this.B>0){this.B--;var f=this.j;this.j=f.next;f.next=null}else f=this.K();return f}put(f){this.A(f);this.B<100&&(this.B++,f.next=this.j,this.j=f)}};
  var Lx6 = {};
  var Iww = class{constructor(){this.B=this.j=null}add(f,a){var e=Lx6.get();e.set(f,a);this.B?this.B.next=e:this.j=e;this.B=e}remove(){var f=null;this.j&&(f=this.j,this.j=this.j.next,this.j||(this.B=null),f.next=null);return f}};
  bU6 = {};
  fP = !1;
  h4Y = function(){for(var f;f=bU6.remove();){try{f.j.call(f.scope)}catch(a){pU(a)}Lx6.put(f)}fP=!1};
  vg = undefined;
  KcT = ()=>{var f=Promise.resolve(void 0);vg=()=>{f.then(h4Y)}};
  g.FD = (f,a)=>{vg||KcT();fP||(vg(),fP=!0);bU6.add(f,a)};
  kYY = function(f,a,e){g.FD(function(){f.apply(a,e)})};
  g.U.publish = function(f,a){var e=this.B[f];if(e){let q=Array(arguments.length-1);var T=arguments.length;let F;for(F=1;F<T;F++)q[F-1]=arguments[F];if(this.W)for(F=0;F<e.length;F++)T=e[F],kYY(this.j[T+1],this.j[T+2],q);else{this.A++;try{for(F=0,T=e.length;F<T&&!this.yH();F++){let E=e[F];this.j[E+1].apply(this.j[E+2],q)}}finally{if(this.A--,this.K.length>0&&this.A==0)for(;e=this.K.pop();)this.Pc(e)}}return F!=0}return!1};
  g.U.clear = function(f){if(f){let a=this.B[f];a&&(a.forEach(this.Pc,this),delete this.B[f])}else this.j.length=0,this.B={}};
  g.U.Bi = function(){g.Kg.lF.Bi.call(this);this.clear();this.K.length=0};
  var Rf = {};
  var UV0 = 0;
  g.VS = function(){return{innertubeApiKey:g.gp("INNERTUBE_API_KEY"),innertubeApiVersion:g.gp("INNERTUBE_API_VERSION"),It:g.gp("INNERTUBE_CONTEXT_CLIENT_CONFIG_INFO"),NH:g.gp("INNERTUBE_CONTEXT_CLIENT_NAME","WEB"),TK:g.gp("INNERTUBE_CONTEXT_CLIENT_NAME",1),innertubeContextClientVersion:g.gp("INNERTUBE_CONTEXT_CLIENT_VERSION"),L_:g.gp("INNERTUBE_CONTEXT_HL"),gi:g.gp("INNERTUBE_CONTEXT_GL"),Pv:g.gp("INNERTUBE_HOST_OVERRIDE")||"",vv:!!g.gp("INNERTUBE_USE_THIRD_PARTY_AUTH",!1),BE:!!g.gp("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT",
!1),appInstallData:g.gp("SERIALIZED_CLIENT_CONFIG_DATA")}};
  UP7 = function(){return"INNERTUBE_API_KEY"in Yg&&"INNERTUBE_API_VERSION"in Yg};
  g.Qv = class{constructor(f){this.config_=null;f?this.config_=f:UP7()&&(this.config_=g.VS())}isReady(){!this.config_&&UP7()&&(this.config_=g.VS());return!!this.config_}};
  dY = window;
  g.u = undefined;
  du = function(){var f=g.yY("_lact",window);return f==null?-1:Math.max(Date.now()-f,0)};
  var BO = {};
  fpN = function(f){BO[f]=f in BO?BO[f]+1:0;return BO[f]};
  var pR = [];
  g.x3 = function(f,a,e){f=f.split(".");e=e||g.S6;for(var T;f.length&&(T=f.shift());)f.length||a===void 0?e[T]&&e[T]!==Object.prototype[T]?e=e[T]:e=e[T]={}:e[T]=a};
  ti = function(f,a){var e=g.yY("yt.logging.transport.enableScrapingForTest"),T=Hh("il_payload_scraping");T=(T!==void 0?String(T):"")==="enable_il_payload_scraping";if(!e)if(T)pR=[],g.x3("yt.logging.transport.enableScrapingForTest",!0),g.x3("yt.logging.transport.scrapedPayloadsForTesting",pR),g.x3("yt.logging.transport.payloadToScrape","visualElementShown visualElementHidden visualElementAttached screenCreated visualElementGestured visualElementStateChanged".split(" ")),g.x3("yt.logging.transport.getScrapedPayloadFromClientEventsFunction"),
g.x3("yt.logging.transport.scrapeClientEvent",!0);else return;e=g.yY("yt.logging.transport.scrapedPayloadsForTesting");T=g.yY("yt.logging.transport.payloadToScrape");a&&(a=a.payload,(a=g.yY("yt.logging.transport.getScrapedPayloadFromClientEventsFunction").bind(a)())&&e.push(a));a=g.yY("yt.logging.transport.scrapeClientEvent");if(T&&T.length>=1)for(let q=0;q<T.length;q++)f&&f.payload[T[q]]&&(a?e.push(f.payload):e.push((f?.payload)[T[q]]));g.x3("yt.logging.transport.scrapedPayloadsForTesting",e)};
  var Fc = {};
  var T_ = [1,2];
  LU = function(f,a=!1){return a&&Symbol.for&&f?Symbol.for(f):f!=null?Symbol(f):Symbol()};
  var YL = undefined;
  vs = function(f){return f[YL]??(f[YL]=new Map)};
  var ut = undefined;
  pq = function(f,a,e,T,q){var F=e+(q?0:-1),E=f.length-1;if(E>=1+(q?0:-1)&&F>=E){let H=f[E];if(H!=null&&typeof H==="object"&&H.constructor===Object)return H[e]=T,a}if(F<=E)return f[F]=T,a;T!==void 0&&(E=(a??(a=f[ut]|0))>>14&1023||536870912,e>=E?T!=null&&(f[E+(q?0:-1)]={[e]:T}):f[F]=T);return a};
  Je = function(f,a,e,T){if(a===-1)return null;var q=a+(e?0:-1),F=f.length-1;if(!(F<1+(e?0:-1))){if(q>=F){var E=f[F];if(E!=null&&typeof E==="object"&&E.constructor===Object){e=E[a];var H=!0}else if(q===F)e=E;else return}else e=f[q];if(T&&e!=null){T=T(e);if(T==null)return T;if(!Object.is(T,e))return H?E[a]=T:f[q]=T,T}return e}};
  Db = function(f,a,e,T,q){var F=f.get(T);if(F!=null)return F;F=0;for(let E=0;E<T.length;E++){let H=T[E];Je(a,H,q)!=null&&(F!==0&&(e=pq(a,e,F,void 0,q)),F=H)}f.set(T,F);return F};
  RD = function(f,a,e){f=f.uN;return Db(vs(f),f,void 0,a)===e?e:-1};
  var TY = {};
  var hL = {};
  GK = function(f,a,e,T,q){Object.isExtensible(f);a=Je(f.uN,a,e,q);if(a!==null||T&&f.A!==hL)return a};
  v6 = function(f){return f==null||typeof f==="string"?f:void 0};
  q2 = function(f,a){return v6(GK(f,a,void 0,TY))};
  rG = function(f){if(f!=null&&typeof f!=="string")throw Error();return f};
  ZK = function(f,a){return a===void 0?f.j!==hL&&!!(2&(f.uN[ut]|0)):!!(2&a)&&f.j!==hL};
  EG = function(f,a,e){f=new f.constructor(a);e&&(f.j=hL);f.A=hL;return f};
  FZ = function(f,a,e){return e&2?!0:e&32&&!(e&4096)?(a[ut]=e|2,f.j=hL,!0):!1};
  var OC = {};
  var Vg = undefined;
  var vV = {};
  O8 = function(f){if(f!==vV)throw Error("illegal external caller");};
  var KU = /[-_.]/g;
  var SI7 = {"-":"+",_:"/",".":"="};
  xew = function(f){return SI7[f]||""};
  U8 = function(f){f=KU.test(f)?f.replace(KU,xew):f;f=atob(f);var a=new Uint8Array(f.length);for(let e=0;e<f.length;e++)a[e]=f.charCodeAt(e);return a};
  RE = function(f){O8(vV);var a=f.j;a=a==null||a!=null&&a instanceof Uint8Array?a:typeof a==="string"?U8(a):null;return a==null?a:f.j=a};
  var rr = class{isEmpty(){return this.j==null}sizeBytes(){var f=RE(this);return f?f.length:0}constructor(f,a){O8(a);this.j=f;if(f!=null&&f.length===0)throw Error("ByteString should be constructed with non-empty values");}};
  M9o = function(f,a){if(typeof f!=="object")return f;if(Array.isArray(f)){var e=f[ut]|0;f.length===0&&e&1?f=void 0:e&2||(!a||4096&e||16&e?f=qw(f,e,!1,a&&!(e&16)):(f[ut]|=34,e&4&&Object.freeze(f)));return f}if(f!=null&&f[Vg]===OC)return a=f.uN,e=a[ut]|0,ZK(f,e)?f:FZ(f,a,e)?EG(f,a):qw(a,e);if(f instanceof rr)return f};
  var gG = undefined;
  v7 = function(f){return f};
  var od7 = undefined;
  var gr = void 0;
  m2 = function(f,a){f.__closure__error__context__984382||(f.__closure__error__context__984382={});f.__closure__error__context__984382.severity=a};
  bt = function(f,a){if(f!=null){var e=gr??(gr={});var T=e[f]||0;T>=a||(e[f]=T+1,f=Error(),m2(f,"incident"),pU(f))}};
  wJw = function(f,a){a<100||bt(od7,1)};
  Lp = function(f,a){for(let e in f)!isNaN(e)&&a(f,+e,f[e])};
  Xb = function(f){return f};
  c6 = undefined;
  var hT = class{};
  B_0 = function(f){var a=new hT;Lp(f,(e,T,q)=>{a[T]=[...q]});
a.uR=f.uR;return a};
  br = function(f){var a=v7(gG);return a?f[a]:void 0};
  me = function(f,a,e,T){var q=T!==void 0;T=!!T;var F=v7(gG),E;!q&&F&&(E=f[F])&&Lp(E,wJw);F=[];var H=f.length;E=4294967295;var C=!1,A=!!(a&64),y=A?a&128?0:-1:void 0;if(!(a&1)){var J=H&&f[H-1];J!=null&&typeof J==="object"&&J.constructor===Object?(H--,E=H):J=void 0;!A||a&128||q||(C=!0,E=(c6??Xb)(E-y,y,f,J,void 0)+y)}a=void 0;for(var p=0;p<H;p++){let B=f[p];if(B!=null&&(B=e(B,T))!=null)if(A&&p>=E){let w=p-y;(a??(a={}))[w]=B}else F[p]=B}if(J)for(let B in J){H=J[B];if(H==null||(H=e(H,T))==null)continue;p=
+B;let w;A&&!Number.isNaN(p)&&(w=p+y)<E?F[w]=H:(a??(a={}))[B]=H}a&&(C?F.push(a):F[E]=a);q&&v7(gG)&&(f=br(f))&&f instanceof hT&&(F[gG]=B_0(f));return F};
  qw = function(f,a,e,T){T??(T=!!(34&a));f=me(f,a,M9o,T);T=32;e&&(T|=2);a=a&16769217|T;f[ut]=a;return f};
  SN = function(f){if(f.j!==hL)return!1;var a=f.uN;a=qw(a,a[ut]|0);a[ut]|=2048;f.uN=a;f.j=void 0;f.A=void 0;return!0};
  xL = function(f){if(!SN(f)&&ZK(f,f.uN[ut]|0))throw Error();};
  Kq = function(f,a,e,T,q){T===0||e.includes(T);var F=vs(f),E=Db(F,f,a,e,q);E!==T&&(E&&(a=pq(f,a,E,void 0,q)),F.set(e,T));return a};
  VG = function(f,a,e,T){xL(f);var q=f.uN,F=q[ut]|0;if(T==null){let E=vs(q);if(Db(E,q,F,e)===a)E.set(e,0);else return f}else F=Kq(q,F,e,a);pq(q,F,a,T);return f};
  JN = function(f,a){var e=g.yY("CLOSURE_FLAGS");f=e&&e[f];return f!=null?f:a};
  var TK = undefined;
  var I4y = undefined;
  ih0 = function(){if(TK)throw Error("carr");bt(I4y,5)};
  eN = function(f,a,e,T=0){if(f==null){var q=32;e?(f=[e],q|=128):f=[];a&&(q=q&-16760833|(a&1023)<<14)}else{if(!Array.isArray(f))throw Error("narr");q=f[ut]|0;if(TK&&1&q)throw Error("rfarr");2048&q&&!(2&q)&&ih0();if(q&256)throw Error("farr");if(q&64)return(q|T)!==q&&(f[ut]=q|T),f;if(e&&(q|=128,e!==f[0]))throw Error("mid");a:{e=f;q|=64;var F=e.length;if(F){var E=F-1;let C=e[E];if(C!=null&&typeof C==="object"&&C.constructor===Object){a=q&128?0:-1;E-=a;if(E>=1024)throw Error("pvtlmt");for(var H in C)if(F=
+H,F<E)e[F+a]=C[H],delete C[H];else break;q=q&-16760833|(E&1023)<<14;break a}}if(a){H=Math.max(a,F-(q&128?0:-1));if(H>1024)throw Error("spvt");q=q&-16760833|(H&1023)<<14}}}f[ut]=q|64|T;return f};
  var nd1 = {};
  var l4Y = undefined;
  var pFN = undefined;
  var GBo = undefined;
  yR = function(f){f.GVi=!0;return f};
  var tT = undefined;
  zx = function(f){switch(typeof f){case "number":return Number.isFinite(f)?f:""+f;case "bigint":return tT(f)?Number(f):""+f;case "boolean":return f?1:0;case "object":if(Array.isArray(f)){var a=f[ut]|0;return f.length===0&&a&1?void 0:me(f,a,zx)}if(f!=null&&f[Vg]===OC)return kf(f);if(f instanceof rr){a=f.j;if(a==null)f="";else if(typeof a==="string")f=a;else{let e="",T=0,q=a.length-10240;for(;T<q;)e+=String.fromCharCode.apply(null,a.subarray(T,T+=10240));e+=String.fromCharCode.apply(null,T?a.subarray(T):
a);a=btoa(e);f=f.j=a}return f}return}return f};
  kf = function(f){f=f.uN;return me(f,f[ut]|0,zx)};
  j_ = function(f,a){if(a){c6=a==null||a===Xb||a[l4Y]!==nd1?Xb:a;try{return kf(f)}finally{c6=void 0}}return kf(f)};
  var Iq = class{constructor(f,a,e){this.uN=eN(f,a,e,2048)}toJSON(){return j_(this)}TW(f){return JSON.stringify(j_(this,f))}clone(){var f=this.uN,a=f[ut]|0;return FZ(this,f,a)?EG(this,f,!0):new this.constructor(qw(f,a,!1))}};
  var KHy = class extends Iq{constructor(f){super(f)}x0(){return q2(this,RD(this,T_,1))}setVideoId(f){return VG(this,1,T_,rG(f))}getPlaylistId(){return q2(this,RD(this,T_,2))}};
  var qd = {};
  zJ = function(f,a=!1){var e="";if(f.dangerousLogToVisitorSession)e="visitorOnlyApprovedKey";else if(f.cttAuthInfo){if(a){a=f.cttAuthInfo.token;e=f.cttAuthInfo;let T=new KHy;e.videoId?T.setVideoId(e.videoId):e.playlistId&&VG(T,2,T_,rG(e.playlistId));qd[a]=T}else a=f.cttAuthInfo,e={},a.videoId?e.videoId=a.videoId:a.playlistId&&(e.playlistId=a.playlistId),Fc[f.cttAuthInfo.token]=e;e=f.cttAuthInfo.token}return e};
  var jt6 = {accountStateChangeSignedIn:23,accountStateChangeSignedOut:24,delayedEventMetricCaptured:11,latencyActionBaselined:6,latencyActionInfo:7,latencyActionTicked:5,offlineTransferStatusChanged:2,offlineImageDownload:335,playbackStartStateChanged:9,systemHealthCaptured:3,mangoOnboardingCompleted:10,mangoPushNotificationReceived:230,mangoUnforkDbMigrationError:121,mangoUnforkDbMigrationSummary:122,mangoUnforkDbMigrationPreunforkDbVersionNumber:133,mangoUnforkDbMigrationPhoneMetadata:134,mangoUnforkDbMigrationPhoneStorage:135,
mangoUnforkDbMigrationStep:142,mangoAsyncApiMigrationEvent:223,mangoDownloadVideoResult:224,mangoHomepageVideoCount:279,mangoHomeV3State:295,mangoImageClientCacheHitEvent:273,sdCardStatusChanged:98,framesDropped:12,thumbnailHovered:13,deviceRetentionInfoCaptured:14,thumbnailLoaded:15,backToAppEvent:318,streamingStatsCaptured:17,offlineVideoShared:19,appCrashed:20,youThere:21,offlineStateSnapshot:22,mdxSessionStarted:25,mdxSessionConnected:26,mdxSessionDisconnected:27,bedrockResourceConsumptionSnapshot:28,
nextGenWatchWatchSwiped:29,kidsAccountsSnapshot:30,zeroStepChannelCreated:31,tvhtml5SearchCompleted:32,offlineSharePairing:34,offlineShareUnlock:35,mdxRouteDistributionSnapshot:36,bedrockRepetitiveActionTimed:37,unpluggedDegradationInfo:229,uploadMp4HeaderMoved:38,uploadVideoTranscoded:39,uploadProcessorStarted:46,uploadProcessorEnded:47,uploadProcessorReady:94,uploadProcessorRequirementPending:95,uploadProcessorInterrupted:96,uploadFrontendEvent:241,assetPackDownloadStarted:41,assetPackDownloaded:42,
assetPackApplied:43,assetPackDeleted:44,appInstallAttributionEvent:459,playbackSessionStopped:45,adBlockerMessagingShown:48,distributionChannelCaptured:49,dataPlanCpidRequested:51,detailedNetworkTypeCaptured:52,sendStateUpdated:53,receiveStateUpdated:54,sendDebugStateUpdated:55,receiveDebugStateUpdated:56,kidsErrored:57,mdxMsnSessionStatsFinished:58,appSettingsCaptured:59,mdxWebSocketServerHttpError:60,mdxWebSocketServer:61,startupCrashesDetected:62,coldStartInfo:435,offlinePlaybackStarted:63,liveChatMessageSent:225,
liveChatUserPresent:434,liveChatBeingModerated:457,liveChatGiftButtonImpressed:558,liveCreationCameraUpdated:64,liveCreationEncodingCaptured:65,liveCreationError:66,liveCreationHealthUpdated:67,liveCreationVideoEffectsCaptured:68,liveCreationStageOccured:75,offlineSystemFailure:546,liveCreationBroadcastScheduled:123,liveCreationArchiveReplacement:149,liveCreationCostreamingConnection:421,liveCreationPlayablesMetrics:533,liveCreationStreamWebrtcStats:288,liveCreationWebrtcError:526,mdxSessionRecoveryStarted:69,
mdxSessionRecoveryCompleted:70,mdxSessionRecoveryStopped:71,visualElementShown:72,visualElementHidden:73,visualElementGestured:78,visualElementStateChanged:208,screenCreated:156,playbackAssociated:202,visualElementAttached:215,playbackContextEvent:214,cloudCastingPlaybackStarted:74,webPlayerApiCalled:76,tvhtml5AccountDialogOpened:79,foregroundHeartbeat:80,foregroundHeartbeatScreenAssociated:111,kidsOfflineSnapshot:81,mdxEncryptionSessionStatsFinished:82,playerRequestCompleted:83,liteSchedulerStatistics:84,
mdxSignIn:85,spacecastMetadataLookupRequested:86,spacecastBatchLookupRequested:87,spacecastSummaryRequested:88,spacecastPlayback:89,spacecastDiscovery:90,tvhtml5LaunchUrlComponentChanged:91,mdxBackgroundPlaybackRequestCompleted:92,mdxBrokenAdditionalDataDeviceDetected:93,tvhtml5LocalStorage:97,tvhtml5DeviceStorageStatus:147,autoCaptionsAvailable:99,playbackScrubbingEvent:339,flexyState:100,interfaceOrientationCaptured:101,mainAppBrowseFragmentCache:102,offlineCacheVerificationFailure:103,offlinePlaybackExceptionDigest:217,
vrCopresenceStats:104,vrCopresenceSyncStats:130,vrCopresenceCommsStats:137,vrCopresencePartyStats:153,vrCopresenceEmojiStats:213,vrCopresenceEvent:141,vrCopresenceFlowTransitEvent:160,vrCowatchPartyEvent:492,vrCowatchUserStartOrJoinEvent:504,vrPlaybackEvent:345,kidsAgeGateTracking:105,offlineDelayAllowedTracking:106,mainAppAutoOfflineState:107,videoAsThumbnailDownload:108,videoAsThumbnailPlayback:109,liteShowMore:110,renderingError:118,kidsProfilePinGateTracking:119,abrTrajectory:124,scrollEvent:125,
streamzIncremented:126,kidsProfileSwitcherTracking:127,kidsProfileCreationTracking:129,buyFlowStarted:136,integrationAttributionEvent:556,mbsConnectionInitiated:138,mbsPlaybackInitiated:139,mbsLoadChildren:140,liteProfileFetcher:144,mdxRemoteTransaction:146,reelPlaybackError:148,reachabilityDetectionEvent:150,mobilePlaybackEvent:151,courtsidePlayerStateChanged:152,musicPersistentCacheChecked:154,musicPersistentCacheCleared:155,playbackInterrupted:157,playbackInterruptionResolved:158,fixFopFlow:159,
anrDetection:161,backstagePostCreationFlowEnded:162,clientError:163,gamingAccountLinkStatusChanged:164,liteHousewarming:165,buyFlowEvent:167,kidsParentalGateTracking:168,kidsSignedOutSettingsStatus:437,kidsSignedOutPauseHistoryFixStatus:438,tvhtml5WatchdogViolation:444,ypcUpgradeFlow:169,yongleStudy:170,ypcUpdateFlowStarted:171,ypcUpdateFlowCancelled:172,ypcUpdateFlowSucceeded:173,ypcUpdateFlowFailed:174,liteGrowthkitPromo:175,paymentFlowStarted:341,transactionFlowShowPaymentDialog:405,transactionFlowStarted:176,
transactionFlowSecondaryDeviceStarted:222,transactionFlowSecondaryDeviceSignedOutStarted:383,transactionFlowCancelled:177,transactionFlowPaymentCallBackReceived:387,transactionFlowPaymentSubmitted:460,transactionFlowPaymentSucceeded:329,transactionFlowSucceeded:178,transactionFlowFailed:179,transactionFlowPlayBillingConnectionStartEvent:428,transactionFlowSecondaryDeviceSuccess:458,transactionFlowErrorEvent:411,liteVideoQualityChanged:180,watchBreakEnablementSettingEvent:181,watchBreakFrequencySettingEvent:182,
videoEffectsCameraPerformanceMetrics:183,adNotify:184,startupTelemetry:185,playbackOfflineFallbackUsed:186,outOfMemory:187,ypcPauseFlowStarted:188,ypcPauseFlowCancelled:189,ypcPauseFlowSucceeded:190,ypcPauseFlowFailed:191,uploadFileSelected:192,ypcResumeFlowStarted:193,ypcResumeFlowCancelled:194,ypcResumeFlowSucceeded:195,ypcResumeFlowFailed:196,adsClientStateChange:197,ypcCancelFlowStarted:198,ypcCancelFlowCancelled:199,ypcCancelFlowSucceeded:200,ypcCancelFlowFailed:201,ypcCancelFlowGoToPaymentProcessor:402,
ypcDeactivateFlowStarted:320,ypcRedeemFlowStarted:203,ypcRedeemFlowCancelled:204,ypcRedeemFlowSucceeded:205,ypcRedeemFlowFailed:206,ypcFamilyCreateFlowStarted:258,ypcFamilyCreateFlowCancelled:259,ypcFamilyCreateFlowSucceeded:260,ypcFamilyCreateFlowFailed:261,ypcFamilyManageFlowStarted:262,ypcFamilyManageFlowCancelled:263,ypcFamilyManageFlowSucceeded:264,ypcFamilyManageFlowFailed:265,restoreContextEvent:207,embedsAdEvent:327,autoplayTriggered:209,clientDataErrorEvent:210,experimentalVssValidation:211,
tvhtml5TriggeredEvent:212,tvhtml5FrameworksFieldTrialResult:216,tvhtml5FrameworksFieldTrialStart:220,musicOfflinePreferences:218,watchTimeSegment:219,appWidthLayoutError:221,accountRegistryChange:226,userMentionAutoCompleteBoxEvent:227,downloadRecommendationEnablementSettingEvent:228,musicPlaybackContentModeChangeEvent:231,offlineDbOpenCompleted:232,kidsFlowEvent:233,kidsFlowCorpusSelectedEvent:234,videoEffectsEvent:235,unpluggedOpsEogAnalyticsEvent:236,playbackAudioRouteEvent:237,interactionLoggingDebugModeError:238,
offlineYtbRefreshed:239,kidsFlowError:240,musicAutoplayOnLaunchAttempted:242,deviceContextActivityEvent:243,deviceContextEvent:244,templateResolutionException:245,musicSideloadedPlaylistServiceCalled:246,embedsStorageAccessNotChecked:247,embedsHasStorageAccessResult:248,embedsItpPlayedOnReload:249,embedsRequestStorageAccessResult:250,embedsShouldRequestStorageAccessResult:251,embedsRequestStorageAccessState:256,embedsRequestStorageAccessFailedState:257,embedsItpWatchLaterResult:266,searchSuggestDecodingPayloadFailure:252,
siriShortcutActivated:253,tvhtml5KeyboardPerformance:254,latencyActionSpan:255,elementsLog:267,ytbFileOpened:268,tfliteModelError:269,apiTest:270,yongleUsbSetup:271,touStrikeInterstitialEvent:272,liteStreamToSave:274,appBundleClientEvent:275,ytbFileCreationFailed:276,adNotifyFailure:278,ytbTransferFailed:280,blockingRequestFailed:281,liteAccountSelector:282,liteAccountUiCallbacks:283,dummyPayload:284,browseResponseValidationEvent:285,entitiesError:286,musicIosBackgroundFetch:287,mdxNotificationEvent:289,
layersValidationError:290,musicPwaInstalled:291,liteAccountCleanup:292,html5PlayerHealthEvent:293,watchRestoreAttempt:294,liteAccountSignIn:296,notaireEvent:298,kidsVoiceSearchEvent:299,adNotifyFilled:300,delayedEventDropped:301,analyticsSearchEvent:302,systemDarkThemeOptOutEvent:303,flowEvent:304,networkConnectivityBaselineEvent:305,ytbFileImported:306,downloadStreamUrlExpired:307,directSignInEvent:308,lyricImpressionEvent:309,accessibilityStateEvent:310,tokenRefreshEvent:311,genericAttestationExecution:312,
tvhtml5VideoSeek:313,unpluggedAutoPause:314,scrubbingEvent:315,bedtimeReminderEvent:317,tvhtml5UnexpectedRestart:319,tvhtml5DeviceStorageStats:535,tvhtml5StabilityTraceEvent:478,tvhtml5OperationHealth:467,tvhtml5WatchKeyEvent:321,voiceLanguageChanged:322,tvhtml5LiveChatStatus:323,parentToolsCorpusSelectedEvent:324,offerAdsEnrollmentInitiated:325,networkQualityIntervalEvent:326,deviceStartupMetrics:328,heartbeatActionPlayerTransitioned:330,tvhtml5Lifecycle:331,heartbeatActionPlayerHalted:332,adaptiveInlineMutedSettingEvent:333,
mainAppLibraryLoadingState:334,thirdPartyLogMonitoringEvent:336,appShellAssetLoadReport:337,tvhtml5AndroidAttestation:338,tvhtml5StartupSoundEvent:340,iosBackgroundRefreshTask:342,iosBackgroundProcessingTask:343,sliEventBatch:344,postImpressionEvent:346,musicSideloadedPlaylistExport:347,idbUnexpectedlyClosed:348,voiceSearchEvent:349,mdxSessionCastEvent:350,idbQuotaExceeded:351,idbTransactionEnded:352,idbTransactionAborted:353,tvhtml5KeyboardLogging:354,idbIsSupportedCompleted:355,creatorStudioMobileEvent:356,
idbDataCorrupted:357,parentToolsAppChosenEvent:358,webViewBottomSheetResized:359,activeStateControllerScrollPerformanceSummary:360,navigatorValidation:361,mdxSessionHeartbeat:362,clientHintsPolyfillDiagnostics:363,clientHintsPolyfillEvent:364,proofOfOriginTokenError:365,kidsAddedAccountSummary:366,musicWearableDevice:367,ypcRefundFlowEvent:368,tvhtml5PlaybackMeasurementEvent:369,tvhtml5WatermarkMeasurementEvent:370,clientExpGcfPropagationEvent:371,mainAppReferrerIntent:372,leaderLockEnded:373,leaderLockAcquired:374,
googleHatsEvent:375,persistentLensLaunchEvent:376,parentToolsChildWelcomeChosenEvent:378,browseThumbnailPreloadEvent:379,finalPayload:380,mdxDialAdditionalDataUpdateEvent:381,webOrchestrationTaskLifecycleRecord:382,startupSignalEvent:384,accountError:385,gmsDeviceCheckEvent:386,accountSelectorEvent:388,accountUiCallbacks:389,mdxDialAdditionalDataProbeEvent:390,downloadsSearchIcingApiStats:391,downloadsSearchIndexUpdatedEvent:397,downloadsSearchIndexSnapshot:398,dataPushClientEvent:392,kidsCategorySelectedEvent:393,
mdxDeviceManagementSnapshotEvent:394,prefetchRequested:395,prefetchableCommandExecuted:396,gelDebuggingEvent:399,webLinkTtsPlayEnd:400,clipViewInvalid:401,persistentStorageStateChecked:403,cacheWipeoutEvent:404,playerEvent:410,sfvEffectPipelineStartedEvent:412,sfvEffectPipelinePausedEvent:429,sfvEffectPipelineEndedEvent:413,sfvEffectChosenEvent:414,sfvEffectLoadedEvent:415,sfvEffectUserInteractionEvent:465,sfvEffectFirstFrameProcessedLatencyEvent:416,sfvEffectAggregatedFramesProcessedLatencyEvent:417,
sfvEffectAggregatedFramesDroppedEvent:418,sfvEffectPipelineErrorEvent:430,sfvEffectGraphFrozenEvent:419,sfvEffectGlThreadBlockedEvent:420,mdeQosEvent:510,mdeVideoChangedEvent:442,mdePlayerPerformanceMetrics:472,mdeExporterEvent:497,genericClientExperimentEvent:423,homePreloadTaskScheduled:424,homePreloadTaskExecuted:425,homePreloadCacheHit:426,polymerPropertyChangedInObserver:427,applicationStarted:431,networkCronetRttBatch:432,networkCronetRttSummary:433,repeatChapterLoopEvent:436,seekCancellationEvent:462,
lockModeTimeoutEvent:483,externalVideoShareToYoutubeAttempt:501,parentCodeEvent:502,offlineTransferStarted:4,musicOfflineMixtapePreferencesChanged:16,mangoDailyNewVideosNotificationAttempt:40,mangoDailyNewVideosNotificationError:77,dtwsPlaybackStarted:112,dtwsTileFetchStarted:113,dtwsTileFetchCompleted:114,dtwsTileFetchStatusChanged:145,dtwsKeyframeDecoderBufferSent:115,dtwsTileUnderflowedOnNonkeyframe:116,dtwsBackfillFetchStatusChanged:143,dtwsBackfillUnderflowed:117,dtwsAdaptiveLevelChanged:128,
blockingVisitorIdTimeout:277,liteSocial:18,mobileJsInvocation:297,biscottiBasedDetection:439,coWatchStateChange:440,embedsVideoDataDidChange:441,shortsFirst:443,cruiseControlEvent:445,qoeClientLoggingContext:446,atvRecommendationJobExecuted:447,tvhtml5UserFeedback:448,producerProjectCreated:449,producerProjectOpened:450,producerProjectDeleted:451,producerProjectElementAdded:453,producerProjectElementRemoved:454,producerAppStateChange:509,producerProjectDiskInsufficientExportFailure:516,producerMediaServicesResetDetails:522,
tvhtml5ShowClockEvent:455,deviceCapabilityCheckMetrics:456,youtubeClearcutEvent:461,offlineBrowseFallbackEvent:463,getCtvTokenEvent:464,startupDroppedFramesSummary:466,screenshotEvent:468,miniAppPlayEvent:469,elementsDebugCounters:470,fontLoadEvent:471,webKillswitchReceived:473,webKillswitchExecuted:474,cameraOpenEvent:475,manualSmoothnessMeasurement:476,tvhtml5AppQualityEvent:477,polymerPropertyAccessEvent:479,miniAppSdkUsage:480,cobaltTelemetryEvent:481,crossDevicePlayback:482,channelCreatedWithObakeImage:484,
channelEditedWithObakeImage:485,offlineDeleteEvent:486,crossDeviceNotificationTransfer:487,androidIntentEvent:488,unpluggedAmbientInterludesCounterfactualEvent:489,keyPlaysPlayback:490,shortsCreationFallbackEvent:493,vssData:491,castMatch:494,miniAppPerformanceMetrics:495,userFeedbackEvent:496,kidsGuestSessionMismatch:498,musicSideloadedPlaylistMigrationEvent:499,sleepTimerSessionFinishEvent:500,watchEpPromoConflict:503,innertubeResponseCacheMetrics:505,miniAppAdEvent:506,dataPlanUpsellEvent:507,
producerProjectRenamed:508,producerMediaSelectionEvent:511,embedsAutoplayStatusChanged:512,remoteConnectEvent:513,connectedSessionMisattributionEvent:514,producerProjectElementModified:515,adsSeenClientLogging:517,producerEvent:518,tvhtml5CleanStart:519,deviceAccountMetricsEvent:520,derpLogEvent:521,playablesPortalEvent:523,ipValidationStarted:524,ipValidationReceived:525,reelsSequenceMutationEvent:527,watchZoomStateChange:528,metadataEditorEvent:529,kidsPrismaDeeplinksEvent:530,creationOrchestrationEvent:531,
coordinatedSamplingTriggered:532,recapScreenshotEvent:534,mdxLocalNetworkPermissionRequestEvent:536,mdxLocalNetworkPermissionResponseEvent:537,sessionReplayEvent:538,sessionReplayStatusEvent:539,loggingReliabilityProbe:540,keyValueStoreStatsEvent:541,deviceLocationPermissionEvent:542,remoteControlStarted:543,remoteControlCompleted:544,reelsAdsEvents:545,ytlrLoaderTestHarnessEvent:547,biometricAuthenticationEvent:548,mainAppLifecycleEvent:549,musicDownloadBackgroundContinuedProcessingTask:550,musicMetadataMismatchEvent:551,
scrollToComponentCompleted:552,entityStoreTelemetry:553,streamingDarkLaunchEvent:554,childAccountsDisplayEvent:555,tvfasPlaybackContext:557,mdeC2PaEvent:559,mdeBatchedPlayerEvents:560,tvhtml5UlpCreationFlowData:561,alwaysConnectedHandshakeRemoteControlStarted:562,alwaysConnectedHandshakeRemoteControlCompleted:563,alwaysConnectedHandshakeAwarenessStarted:564,alwaysConnectedHandshakeAwarenessCompleted:565,customThumbnailSourceMetadata:567,miniAppInGameEvent:568,androidToastyRun:569};
  B9o = function(f){f=Object.keys(f);for(let a of f)if(jt6[a])return a};
  var QB_ = class extends g.th{constructor(){super();this.B=[];this.j=[];var f=g.yY("yt.gcf.config.hotUpdateCallbacks");f?(this.B=[...f],this.j=f):(this.j=[],g.x3("yt.gcf.config.hotUpdateCallbacks",this.j))}Bi(){for(let a of this.B){var f=this.j;let e=f.indexOf(a);e>=0&&f.splice(e,1)}this.B.length=0;super.Bi()}};
  Uo = function(f,a){f.B=a;g.x3("yt.gcf.config.hotConfigGroup",f.B||null)};
  P8 = function(f,a){f.j=a;g.x3("yt.gcf.config.coldConfigGroup",f.j||null)};
  rf = function(){return g.yY("yt.gcf.config.coldConfigGroup")};
  v8 = function(){return g.yY("yt.gcf.config.hotConfigGroup")};
  rM = function(f){this.j=f};
  Vj = function(f){this.j=f;this.B=null};
  g.U = Vj.prototype;
  g.U.isAvailable = function(){if(this.B===null){var f=this.j;if(f)try{f.setItem("__sak","1");f.removeItem("__sak");var a=!0}catch(e){a=e instanceof DOMException&&(e.name==="QuotaExceededError"||e.code===22||e.code===1014||e.name==="NS_ERROR_DOM_QUOTA_REACHED")&&f&&f.length!==0}else a=!1;this.B=a}return this.B};
  Oh = function(f){if(f.j==null)throw Error("Storage mechanism: Storage unavailable");f.isAvailable()||pU(Error("Storage mechanism: Storage unavailable"))};
  g.U.set = function(f,a){Oh(this);try{this.j.setItem(f,a)}catch(e){if(this.j.length==0)throw"Storage mechanism: Storage disabled";throw"Storage mechanism: Quota exceeded";}};
  g.U.get = function(f){Oh(this);f=this.j.getItem(f);if(typeof f!=="string"&&f!==null)throw"Storage mechanism: Invalid value was encountered";return f};
  g.U.remove = function(f){Oh(this);this.j.removeItem(f)};
  g.E1 = function(){};
  g.J5 = {};
  g.HZ = function(f){return{value:f,done:!1}};
  g.U.V8 = function(f){Oh(this);var a=0,e=this.j,T=new g.E1;T.next=function(){if(a>=e.length)return g.J5;var q=e.key(a++);if(f)return g.HZ(q);q=e.getItem(q);if(typeof q!=="string")throw"Storage mechanism: Invalid value was encountered";return g.HZ(q)};
return T};
  g.U.clear = function(){Oh(this);this.j.clear()};
  g.U.key = function(f){Oh(this);return this.j.key(f)};
  RY = function(){var f=null;try{f=g.S6.localStorage||null}catch(a){}Vj.call(this,f)};
  YX = function(f,a){this.B=f;this.j=a+"::"};
  g.XS = function(f){var a=new RY;return a.isAvailable()?f?new YX(a,f):a:null};
  Q1q = function(){};
  g.o5 = function(f){return(new Q1q).TW(f)};
  NP = function(f){this.j=f||{cookie:""}};
  g.U = NP.prototype;
  g.U.isEnabled = function(){if(!g.S6.navigator.cookieEnabled)return!1;if(!this.isEmpty())return!0;this.set("TESTCOOKIESENABLED","1",{zt:60});if(this.get("TESTCOOKIESENABLED")!=="1")return!1;this.remove("TESTCOOKIESENABLED");return!0};
  g.U.set = function(f,a,e){var T=!1;if(typeof e==="object"){var q=e.sameSite;T=e.secure||!1;var F=e.domain||void 0;var E=e.path||void 0;var H=e.zt}if(/[;=\s]/.test(f))throw Error('Invalid cookie name "'+f+'"');if(/[;\r\n]/.test(a))throw Error('Invalid cookie value "'+a+'"');H===void 0&&(H=-1);e=F?";domain="+F:"";E=E?";path="+E:"";T=T?";secure":"";H=H<0?"":H==0?";expires="+(new Date(1970,1,1)).toUTCString():";expires="+(new Date(Date.now()+H*1E3)).toUTCString();this.j.cookie=f+"="+a+e+E+H+T+(q!=null?
";samesite="+q:"")};
  g.U.get = function(f,a){var e=f+"=",T=(this.j.cookie||"").split(";");for(let q=0,F;q<T.length;q++){F=T[q].trim();if(F.lastIndexOf(e,0)==0)return F.slice(e.length);if(F==f)return""}return a};
  g.U.remove = function(f,a,e){var T=this.get(f)!==void 0;this.set(f,"",{zt:0,path:a,domain:e});return T};
  Qw = function(f){f=(f.j.cookie||"").split(";");var a=[],e=[];for(let F=0;F<f.length;F++){var T=f[F].trim();var q=T.indexOf("=");q==-1?(a.push(""),e.push(T)):(a.push(T.substring(0,q)),e.push(T.substring(q+1)))}return{keys:a,values:e}};
  g.U.ge = function(){return Qw(this).keys};
  g.U.Ow = function(){return Qw(this).values};
  g.U.isEmpty = function(){return!this.j.cookie};
  g.U.clear = function(){var f=Qw(this).keys;for(let a=f.length-1;a>=0;a--)this.remove(f[a])};
  var n2 = {};
  var lL = !1;
  g.Wh = function(f,a,e,T="youtube.com",q=!1){lL||n2.set(""+f,a,{zt:e,path:"/",domain:T,secure:q})};
  g.Kt = function(f,a){if(!lL)return n2.get(""+f,a)};
  g.iL = function(f,a="/",e="youtube.com"){lL||n2.remove(""+f,a,e)};
  var TJ = class{constructor(f){this.j=(f=g.XS(f))?new rM(f):null;this.domain=document.domain||window.location.hostname}B(){return!!this.j}set(f,a,e,T){e=e||31104E3;this.remove(f);if(this.j)try{this.j.set(f,a,Date.now()+e*1E3);return}catch(F){}var q="";if(T)try{q=escape(g.o5(a))}catch(F){return}else q=escape(String(a));g.Wh(f,q,e,this.domain)}get(f,a){var e=void 0,T=!this.B();if(!T&&this.j)try{e=this.j.get(f)}catch(q){T=!0}if(T&&(e=g.Kt(f)))if(T=unescape(e),a)try{e=JSON.parse(T)}catch(q){this.remove(f),
e=void 0}else e=T;return e}remove(f){this.j&&this.j.remove(f);g.iL(f,"/",this.domain)}getCreationTime(f){return this.j&&(f=(this.j.B(f)||{}).creation,typeof f==="number")?f:null}};
  var gD = undefined;
  bl = function(){return gD()?.get("LAST_RESULT_ENTRY_KEY",!0)};
  ylG = {AUTH_INVALID:"No user identifier specified.",EXPLICIT_ABORT:"Transaction was explicitly aborted.",IDB_NOT_SUPPORTED:"IndexedDB is not supported.",MISSING_INDEX:"Index not created.",MISSING_OBJECT_STORES:"Object stores not created.",DB_DELETED_BY_MISSING_OBJECT_STORES:"Database is deleted because expected object stores were not created.",DB_REOPENED_BY_MISSING_OBJECT_STORES:"Database is reopened because expected object stores were not created.",UNKNOWN_ABORT:"Transaction was aborted for unknown reasons.",QUOTA_EXCEEDED:"The current transaction exceeded its quota limitations.",
QUOTA_MAYBE_EXCEEDED:"The current transaction may have failed because of exceeding quota limitations.",EXECUTE_TRANSACTION_ON_CLOSED_DB:"Can't start a transaction on a closed database",INCOMPATIBLE_DB_VERSION:"The binary is incompatible with the database version"};
  JlA = {AUTH_INVALID:"ERROR",EXECUTE_TRANSACTION_ON_CLOSED_DB:"WARNING",EXPLICIT_ABORT:"IGNORED",IDB_NOT_SUPPORTED:"ERROR",MISSING_INDEX:"WARNING",MISSING_OBJECT_STORES:"ERROR",DB_DELETED_BY_MISSING_OBJECT_STORES:"WARNING",DB_REOPENED_BY_MISSING_OBJECT_STORES:"WARNING",QUOTA_EXCEEDED:"WARNING",QUOTA_MAYBE_EXCEEDED:"WARNING",UNKNOWN_ABORT:"WARNING",INCOMPATIBLE_DB_VERSION:"WARNING"};
  G24 = {};
  g.kb = class extends g.vc{constructor(f,a={},e=ylG[f],T=JlA[f],q=G24[f]){super(e,{name:"YtIdbKnownError",isSw:self.document===void 0,isIframe:self!==self.top,type:f,...a});this.type=f;this.message=e;this.level=T;this.j=q;Object.setPrototypeOf(this,g.kb.prototype)}};
  g.eB = function(f,a,e){var T=bl();return new g.kb("IDB_NOT_SUPPORTED",{context:{caller:f,publicName:a,version:e,hasSucceededOnce:T?.hasSucceededOnce}})};
  X5 = function(...f){f=arguments;f.length>1?Yg[f[0]]=f[1]:f.length===1&&Object.assign(Yg,f[0])};
  eGw = function(f,a,e,T,q,F){var E=g.yY("yt.logging.errors.log");E?E(f,a,e,T,q,void 0,F):(E=g.gp("ERRORS",[]),E.push([f,a,e,T,q,void 0,F]),X5("ERRORS",E))};
  ZH = function(f,a,e,T,q){eGw(f,"WARNING",a,e,T,q)};
  W8 = function(){return g.yY("ytglobal.idbToken_")||void 0};
  MdY = function(f,a,e){var T=()=>{try{f.removeEventListener("success",q),f.removeEventListener("error",F)}catch{}},q=()=>{a(f.result);
T()},F=()=>{e(f.error);
T()};
f.addEventListener("success",q);f.addEventListener("error",F)};
  qZ = class{constructor(f){this.j=f}};
  W46 = function(f){return f};
  nlg = function(f){if(!f)throw Error();throw f;};
  Th = function(f,a,e,T,q){a===e?q(new TypeError("Circular promise chain detected.")):e.then(F=>{F instanceof g.so?Th(f,a,F,T,q):T(F)},F=>{q(F)})};
  Iro = function(f,a,e,T,q){try{if(f.state.status!=="REJECTED")throw Error("calling handleReject before the promise is rejected.");let F=e(f.state.reason);F instanceof g.so?Th(f,a,F,T,q):T(F)}catch(F){q(F)}};
  iXy = function(f,a,e,T,q){try{if(f.state.status!=="FULFILLED")throw Error("calling handleResolve before the promise is fulfilled.");let F=e(f.state.value);F instanceof g.so?Th(f,a,F,T,q):T(F)}catch(F){q(F)}};
  g.so = class{constructor(f){this.state={status:"PENDING"};this.j=[];this.B=[];f=f.j;var a=T=>{if(this.state.status==="PENDING"){this.state={status:"FULFILLED",value:T};for(let q of this.j)q()}},e=T=>{if(this.state.status==="PENDING"){this.state={status:"REJECTED",
reason:T};for(let q of this.B)q()}};
try{f(a,e)}catch(T){e(T)}}static all(f){return new g.so(new qZ((a,e)=>{var T=[],q=f.length;q===0&&a(T);for(let F=0;F<f.length;++F)g.so.resolve(f[F]).then(E=>{T[F]=E;q--;q===0&&a(T)}).catch(E=>{e(E)})}))}static resolve(f){return new g.so(new qZ((a,e)=>{f instanceof g.so?f.then(a,e):a(f)}))}static reject(f){return new g.so(new qZ((a,e)=>{e(f)}))}then(f,a){var e=f??W46,T=a??nlg;
return new g.so(new qZ((q,F)=>{this.state.status==="PENDING"?(this.j.push(()=>{iXy(this,this,e,q,F)}),this.B.push(()=>{Iro(this,this,T,q,F)})):this.state.status==="FULFILLED"?iXy(this,this,e,q,F):this.state.status==="REJECTED"&&Iro(this,this,T,q,F)}))}catch(f){return this.then(void 0,f)}};
  F$ = function(f){return new g.so(new qZ((a,e)=>{MdY(f,a,e)}))};
  var uU6 = class{constructor(f,a){this.request=f;
this.cursor=a}delete(){return F$(this.cursor.delete()).then(()=>{})}getValue(){return this.cursor.value}update(f){return F$(this.cursor.update(f))}};
  xH = function(f){return F$(f).then(a=>a?new uU6(f,a):null)};
  g.J2 = function(f){f.cursor.continue(void 0);return xH(f.request)};
  Eo = function(f,a){return new g.so(new qZ((e,T)=>{var q=()=>{var F=f?a(f):null;F?F.then(E=>{f=E;q()},T):e()};
q()}))};
  g.yS = function(f,a,e){f=f.j.openCursor(a.query,a.direction);return xH(f).then(T=>Eo(T,e))};
  Y16 = function(f,a){return g.yS(f,{query:a},e=>e.delete().then(()=>g.J2(e))).then(()=>{})};
  XZw = function(f,a,e){var T=[];return g.yS(f,{query:a},q=>{if(!(e!==void 0&&T.length>=e))return T.push(q.getValue()),g.J2(q)}).then(()=>T)};
  fW = class extends Error{constructor(f,a){super();this.index=f;this.objectStore=a;Object.setPrototypeOf(this,fW.prototype)}};
  g.Gh = function(f,a,e){var {query:T=null,direction:q="next"}=a;f=f.j.openCursor(T,q);return xH(f).then(F=>Eo(F,e))};
  hzY = function(f,a,e){var T=[];return g.Gh(f,{query:a},q=>{if(!(e!==void 0&&T.length>=e))return T.push(q.getValue()),g.J2(q)}).then(()=>T)};
  var BU_ = class{constructor(f){this.j=f}count(f){return F$(this.j.count(f))}delete(f){return g.Gh(this,{query:f},a=>a.delete().then(()=>g.J2(a)))}get(f){return F$(this.j.get(f))}getAll(f,a){return"getAll"in IDBIndex.prototype?F$(this.j.getAll(f,a)):hzY(this,f,a)}keyPath(){return this.j.keyPath}unique(){return this.j.unique}};
  var OX3 = class{constructor(f){this.j=f}add(f,a){return F$(this.j.add(f,a))}autoIncrement(){return this.j.autoIncrement}clear(){return F$(this.j.clear()).then(()=>{})}count(f){return F$(this.j.count(f))}delete(f){return f instanceof IDBKeyRange?Y16(this,f):F$(this.j.delete(f))}get(f){return F$(this.j.get(f))}getAll(f,a){return"getAll"in IDBObjectStore.prototype?F$(this.j.getAll(f,
a)):XZw(this,f,a)}index(f){try{return new BU_(this.j.index(f))}catch(a){if(a instanceof Error&&a.name==="NotFoundError")throw new fW(f,this.j.name);
throw a;}}getName(){return this.j.name}keyPath(){return this.j.keyPath}put(f,a){return F$(this.j.put(f,a))}};
  df = function(f,a,e){f=f.j.createObjectStore(a,e);return new OX3(f)};
  SB = function(f,a,e){f.j.createIndex(a,e,{unique:!1})};
  tA = function(f){if(f.indexOf(":")>=0)throw Error("Database name cannot contain ':'");};
  var lG = {};
  nW = undefined;
  var LQ = !1;
  g.sg = function(){var f=g.S6.navigator;return f&&(f=f.userAgent)?f:""};
  g.j9 = function(f,a){return f.indexOf(a)!=-1};
  Cw = function(f){return g.j9(g.sg(),f)};
  g.wf = undefined;
  g6 = function(){var f=/WebKit\/([0-9]+)/.exec(g.sg());return!!(f&&parseInt(f[1],10)>=602)};
  Xh = function(){var f=/WebKit\/([0-9]+)/.exec(g.sg());return!!(f&&parseInt(f[1],10)>=600)};
  ch = undefined;
  AS = function(){return Cw("iPhone")&&!Cw("iPod")&&!Cw("iPad")};
  $q = {};
  g.o$ = $q||ch;
  H8 = function(){return g.C2("idb_immediate_commit")};
  z5 = function(f){return f.substr(0,f.indexOf(":"))||f};
  Sc = function(){return AS()||Cw("iPad")||Cw("iPod")};
  yl = function(){return Cw("Firefox")||Cw("FxiOS")};
  var siw = {};
  Ff = undefined;
  var qK = undefined;
  var TF = undefined;
  Eg = function(f){if(!TF&&!qK||!Ff)return!1;for(let a=0;a<Ff.brands.length;a++){let {brand:e}=Ff.brands[a];if(e&&g.j9(e,f))return!0}return!1};
  d8 = function(){return TF||qK?!!Ff&&Ff.brands.length>0:!1};
  xp = function(){return d8()?Eg("Microsoft Edge"):Cw("Edg/")};
  AP = function(){return d8()?!1:Cw("Opera")};
  JP = function(){return d8()?Eg("Chromium"):(Cw("Chrome")||Cw("CriOS"))&&!(d8()?0:Cw("Edge"))||Cw("Silk")};
  GF = function(){return Cw("Safari")&&!(JP()||(d8()?0:Cw("Coast"))||AP()||(d8()?0:Cw("Edge"))||xp()||(d8()?Eg("Opera"):Cw("OPR"))||yl()||Cw("Silk")||Cw("Android"))};
  g.jk = {};
  lr3 = ["The database connection is closing","Can't start a transaction on a closed database","A mutation operation was attempted on a database that did not allow mutations"];
  a$ = function(f,a,e,T){a=z5(a);var q=f instanceof Error?f:Error(`Unexpected error: ${f}`);if(q instanceof g.kb)return q;f={objectStoreNames:e,dbName:a,dbVersion:T};if(q.name==="QuotaExceededError")return new g.kb("QUOTA_EXCEEDED",f);if(g.jk&&q.name==="UnknownError")return new g.kb("QUOTA_MAYBE_EXCEEDED",f);if(q instanceof fW)return new g.kb("MISSING_INDEX",{...f,objectStore:q.objectStore,index:q.index});if(q.name==="InvalidStateError"&&lr3.some(F=>q.message.includes(F)))return new g.kb("EXECUTE_TRANSACTION_ON_CLOSED_DB",
f);
if(q.name==="AbortError")return new g.kb("UNKNOWN_ABORT",f,q.message);q.args=[{...f,name:"IdbError",pj:q.name}];q.level="WARNING";return q};
  var ul = [];
  hA = undefined;
  mU = function(f,a){LQ||(hA?hA.logEvent(f,a):(ul.push({type:"EVENT",eventType:f,payload:a}),ul.length>10&&ul.shift()))};
  Rzq = function(f,a,e,T,q,F="IDB_TRANSACTION_TAG_UNKNOWN"){mU("TRANSACTION_ENDED",{objectStoreNames:T,connectionHasUnknownAbortedTransaction:f.B,duration:q,isSuccessful:a,tryCount:e,tag:F})};
  cc = function(f){LQ||(hA?hA.S$(f):(ul.push({type:"ERROR",payload:f}),ul.length>10&&ul.shift()))};
  Vd$ = function(f,a,e,T,q,F,E){a=e-a;q?(q instanceof g.kb&&(q.type==="QUOTA_EXCEEDED"||q.type==="QUOTA_MAYBE_EXCEEDED")&&mU("QUOTA_EXCEEDED",{dbName:z5(f.j.name),objectStoreNames:F,transactionCount:f.transactionCount,transactionMode:E.mode}),q instanceof g.kb&&q.type==="UNKNOWN_ABORT"&&(e-=f.K,e<0&&e>=2147483648&&(e=0),mU("TRANSACTION_UNEXPECTEDLY_ABORTED",{objectStoreNames:F,transactionDuration:a,transactionCount:f.transactionCount,dbDuration:e}),f.B=!0),Rzq(f,!1,T,F,a,E.tag),cc(q)):Rzq(f,!0,T,F,a,
E.tag)};
  var vlw = class{constructor(f){this.j=f;this.B=new Map;this.aborted=!1;this.done=new Promise((a,e)=>{this.j.addEventListener("complete",()=>{a()});
this.j.addEventListener("error",T=>{T.currentTarget===T.target&&e(this.j.error)});
this.j.addEventListener("abort",()=>{var T=this.j.error;if(T)e(T);else if(!this.aborted){T=g.kb;var q=this.j.objectStoreNames;let F=[];for(let E=0;E<q.length;E++){let H=q.item(E);if(H===null)throw Error("Invariant: item in DOMStringList is null");F.push(H)}T=new T("UNKNOWN_ABORT",{objectStoreNames:F.join(),dbName:this.j.db.name,mode:this.j.mode});e(T)}})})}abort(){this.j.abort();
this.aborted=!0;throw new g.kb("EXPLICIT_ABORT");}commit(){this.aborted||this.j.commit?.()}objectStore(f){f=this.j.objectStore(f);var a=this.B.get(f);a||(a=new OX3(f),this.B.set(f,a));return a}};
  D0w = function(f,a,e){var T=new Promise((q,F)=>{try{let E=a(f);e&&f.commit();E.then(H=>{q(H)}).catch(F)}catch(E){F(E),f.abort()}});
return Promise.all([T,f.done]).then(([q])=>q)};
  g.CW = async function(f,a,e,T){var q={mode:"readonly",oV:!1,tag:"IDB_TRANSACTION_TAG_UNKNOWN"};typeof e==="string"?q.mode=e:Object.assign(q,e);f.transactionCount++;e=q.oV?3:1;for(var F=0,E;!E;){F++;let y=Math.round((0,g.u)());try{var H=f.j.transaction(a,q.mode),C=T,A=!!q.commit;let J=new vlw(H),p=await D0w(J,C,A),B=Math.round((0,g.u)());Vd$(f,y,B,F,void 0,a.join(),q);return p}catch(J){C=Math.round((0,g.u)());let p=a$(J,f.j.name,a.join(),f.j.version);if(p instanceof g.kb&&!p.j||F>=e)Vd$(f,y,C,F,p,a.join(),
q),E=p}}return Promise.reject(E)};
  var ZXT = class{constructor(f,a){this.j=f;this.options=a;this.transactionCount=0;this.K=Math.round((0,g.u)());this.B=!1}add(f,a,e){return g.CW(this,[f],{mode:"readwrite",oV:!0,commit:H8()},T=>T.objectStore(f).add(a,e))}clear(f){return g.CW(this,[f],{mode:"readwrite",
oV:!0},a=>a.objectStore(f).clear())}close(){this.j.close();
this.options?.closed&&this.options.closed()}count(f,a){return g.CW(this,[f],{mode:"readonly",oV:!0,commit:H8()},e=>e.objectStore(f).count(a))}delete(f,a){return g.CW(this,[f],{mode:"readwrite",
oV:!0,commit:H8()&&!(a instanceof IDBKeyRange)},e=>e.objectStore(f).delete(a))}get(f,a){return g.CW(this,[f],{mode:"readonly",
oV:!0,commit:H8()},e=>e.objectStore(f).get(a))}getAll(f,a,e){return g.CW(this,[f],{mode:"readonly",
oV:!0},T=>T.objectStore(f).getAll(a,e))}put(f,a,e){return g.CW(this,[f],{mode:"readwrite",
oV:!0,commit:H8()},T=>T.objectStore(f).put(a,e))}objectStoreNames(){return Array.from(this.j.objectStoreNames)}getName(){return this.j.name}};
  $0o = function(f,a,e){return new Promise((T,q)=>{var F=a!==void 0?self.indexedDB.open(f,a):self.indexedDB.open(f);var E=e.blocked,H=e.blocking,C=e.QO,A=e.upgrade,y=e.closed,J,p=()=>{J||(J=new ZXT(F.result,{closed:y}));return J};
F.addEventListener("upgradeneeded",B=>{try{if(B.newVersion===null)throw Error("Invariant: newVersion on IDbVersionChangeEvent is null");if(F.transaction===null)throw Error("Invariant: transaction on IDbOpenDbRequest is null");B.dataLoss&&B.dataLoss!=="none"&&mU("IDB_DATA_CORRUPTED",{reason:B.dataLossMessage||"unknown reason",dbName:z5(f)});let w=p(),P=new vlw(F.transaction);A&&A(w,O=>B.oldVersion<O&&B.newVersion>=O,P);
P.done.catch(O=>{q(O)})}catch(w){q(w)}});
F.addEventListener("success",()=>{var B=F.result;H&&B.addEventListener("versionchange",()=>{H(p())});
B.addEventListener("close",()=>{mU("IDB_UNEXPECTEDLY_CLOSED",{dbName:z5(f),dbVersion:B.version});C&&C()});
T(p())});
F.addEventListener("error",()=>{q(F.error)});
E&&F.addEventListener("blocked",()=>{E()})})};
  c46 = function(f,a,e={}){return $0o(f,a,e)};
  K4N = function(f){return new Promise((a,e)=>{MdY(f,a,e)})};
  pW = async function(f,a={}){try{let e=self.indexedDB.deleteDatabase(f),T=a.blocked;T&&e.addEventListener("blocked",()=>{T()});
await K4N(e)}catch(e){throw a$(e,f,"",-1);}};
  m01 = function(f,a){return new g.kb("INCOMPATIBLE_DB_VERSION",{dbName:f.name,oldVersion:f.options.version,newVersion:a})};
  g.d6 = function(f,a){return Number(Hh(f,a)||0)};
  p5I = class extends g.kb{constructor(f,a){super("MISSING_OBJECT_STORES",{expectedObjectStores:a,foundObjectStores:f},ylG.MISSING_OBJECT_STORES);Object.setPrototypeOf(this,p5I.prototype)}};
  var NU9 = class{constructor(f,a){this.name=f;this.options=a;this.K=!0;this.S=this.A=0}B(f,a,e={}){return c46(f,a,e)}delete(f={}){return pW(this.name,f)}open(){if(!this.K)throw m01(this);if(this.j)return this.j;var f,a=()=>{this.j===f&&(this.j=void 0)},e={blocking:q=>{q.close()},
closed:a,QO:a,upgrade:this.options.upgrade},T=async()=>{var q=Error().stack??"";try{let H=await this.B(this.name,this.options.version,e);var F=H,E=this.options;let C=[];for(let A of Object.keys(E.CA)){let {Mj:y,yco:J=Number.MAX_VALUE}=E.CA[A];!(F.j.version>=y)||F.j.version>=J||F.j.objectStoreNames.contains(A)||C.push(A)}if(C.length!==0){let A=Object.keys(this.options.CA),y=H.objectStoreNames();if(this.S<g.d6("ytidb_reopen_db_retries",0))return this.S++,H.close(),cc(new g.kb("DB_REOPENED_BY_MISSING_OBJECT_STORES",
{dbName:this.name,expectedObjectStores:A,foundObjectStores:y})),T();if(this.A<g.d6("ytidb_remake_db_retries",1))return this.A++,await this.delete(),cc(new g.kb("DB_DELETED_BY_MISSING_OBJECT_STORES",{dbName:this.name,expectedObjectStores:A,foundObjectStores:y})),T();throw new p5I(y,A);}return H}catch(H){if(H instanceof DOMException?H.name==="VersionError":"DOMError"in self&&H instanceof DOMError?H.name==="VersionError":H instanceof Object&&"message"in H&&H.message==="An attempt was made to open a database using a lower version than the existing version."){q=
await this.B(this.name,void 0,{...e,upgrade:void 0});F=q.j.version;if(this.options.version!==void 0&&F>this.options.version+1)throw q.close(),this.K=!1,m01(this,F);return q}a();H instanceof Error&&!g.C2("ytidb_async_stack_killswitch")&&(H.stack=`${H.stack}\n${q.substring(q.indexOf("\n")+1)}`);throw a$(H,this.name,"",this.options.version??-1);}};
return this.j=f=T()}};
  var NZ = {};
  g.B8 = function(f,a){if(!a)throw g.eB("openWithToken",z5(f.name));return f.open()};
  tdY = async function(f,a){return g.CW(await g.B8(NZ,a),["databases"],{oV:!0,mode:"readwrite"},e=>{var T=e.objectStore("databases");return T.get(f.actualName).then(q=>{if(q?f.actualName!==q.actualName||f.publicName!==q.publicName||f.userIdentifier!==q.userIdentifier:1)return T.put(f).then(()=>{})})})};
  QS = async function(f,a){return f?(await g.B8(NZ,a)).delete("databases",f):void 0};
  jX0 = async function(){if(bl()?.hasSucceededOnce)return!0;var f;if(!(f=g.o$&&Xh()&&!g6()||g.wf)){try{f=self;var a=!!(f.indexedDB&&f.IDBIndex&&f.IDBKeyRange&&f.IDBObjectStore)}catch(e){a=!1}f=!a}if(f||!("IDBTransaction"in self&&"objectStoreNames"in IDBTransaction.prototype))return!1;try{return await tdY({actualName:"yt-idb-test-do-not-use",publicName:"yt-idb-test-do-not-use",userIdentifier:void 0},lG),await QS("yt-idb-test-do-not-use",lG),!0}catch(e){return!1}};
  fdo = function(){if(nW!==void 0)return nW;LQ=!0;return nW=jX0().then(f=>{LQ=!1;if(gD()?.B()){var a={hasSucceededOnce:bl()?.hasSucceededOnce||f};gD()?.set("LAST_RESULT_ENTRY_KEY",a,2592E3,!0)}return f})};
  g.iG = function(){var f=W8();return f?Promise.resolve(f):fdo().then(a=>{a?(g.x3("ytglobal.idbToken_",lG),a=lG):a=void 0;return a})};
  g.Pc = function(f="unknown"){if(g.gp("DATASYNC_ID")!==void 0)return g.gp("DATASYNC_ID");throw new g.vc("Datasync ID not set",f);};
  rD = function(){try{return g.Pc(),!0}catch(f){return!1}};
  eyY = function(f){if(!rD())throw f=new g.kb("AUTH_INVALID",{dbName:f}),cc(f),f;var a=g.Pc();return{actualName:`${f}:${a}`,publicName:f,userIdentifier:a}};
  sHT = async function(f,a,e,T){var q=Error().stack??"",F=await g.iG();if(!F)throw a=g.eB("openDbImpl",f,a),g.C2("ytidb_async_stack_killswitch")||(a.stack=`${a.stack}\n${q.substring(q.indexOf("\n")+1)}`),cc(a),a;tA(f);q=e?{actualName:f,publicName:f,userIdentifier:void 0}:eyY(f);try{return await tdY(q,F),await c46(q.actualName,a,T)}catch(E){try{await QS(q.actualName,F)}catch{}throw E;}};
  Tq7 = function(f,a,e={}){return sHT(f,a,!1,e)};
  qp0 = function(f,a,e={}){return sHT(f,a,!0,e)};
  Eo6 = async function(f,a={}){var e=await g.iG();e&&(tA(f),f=eyY(f),await pW(f.actualName,a),await QS(f.actualName,e))};
  dPw = async function(f,a={}){var e=await g.iG();e&&(tA(f),await pW(f,a),await QS(f,e))};
  var A1g = class extends NU9{constructor(f,a){super(f,a);this.options=a;tA(f)}B(f,a,e={}){return(this.options.shared?qp0:Tq7)(f,a,{...e})}delete(f={}){return(this.options.shared?dPw:Eo6)(this.name,f)}};
  SpY = function(f,a){var e;return()=>{e||(e=new A1g(f,a));return e}};
  I$ = function(f,a){return SpY(f,a)};
  var xP3 = undefined;
  MZ = function(f){return g.B8(xP3(),f)};
  pj7 = async function(f){f=await MZ(f);var a=void 0;await g.CW(f,["hotConfigStore"],{mode:"readwrite",oV:!0},e=>g.Gh(e.objectStore("hotConfigStore").index("hotTimestampIndex"),{direction:"prev"},T=>{a=T.getValue()}));
return a};
  now = function(f){Uo(f,g.gp("RAW_HOT_CONFIG_GROUP"));f.wl(g.gp("SERIALIZED_HOT_HASH_DATA"))};
  y1T = async function(f,a,e,T){f={config:f,hashData:a,timestamp:T!==void 0?T:(0,g.u)()};e=await MZ(e);await e.clear("hotConfigStore");return await e.put("hotConfigStore",f)};
  QHT = async function(f){if(f.B)return v8();if(!f.S)return f=g.eB("getHotConfig IDB not initialized"),ZH(f),Promise.reject(f);var a=W8(),e=g.gp("TIME_CREATED_MS");if(a){var T=await pj7(a);if(T&&T.timestamp>e)return Uo(f,T.config),f.wl(T.hashData),v8()}else T=g.eB("getHotConfig token error"),ZH(T);now(f);a&&f.B&&f.hotHashData&&await y1T(f.B,f.hotHashData,a,e);return f.B?v8():(f=new g.vc("Config not available in ytConfig"),ZH(f),Promise.reject(f))};
  Gu7 = async function(f){f=await MZ(f);var a=void 0;await g.CW(f,["coldConfigStore"],{mode:"readwrite",oV:!0},e=>g.Gh(e.objectStore("coldConfigStore").index("coldTimestampIndex"),{direction:"prev"},T=>{a=T.getValue()}));
return a};
  iI$ = function(f,a){f.configData=a;g.x3("yt.gcf.config.coldConfigData",f.configData||null)};
  DW = function(f,a){f.coldHashData=a;g.x3("yt.gcf.config.coldHashData",f.coldHashData||null)};
  ldo = function(f){P8(f,g.gp("RAW_COLD_CONFIG_GROUP"));DW(f,g.gp("SERIALIZED_COLD_HASH_DATA"));iI$(f,f.j?.configData)};
  J17 = async function(f,a,e,T,q){f={config:f,hashData:a,configData:e,timestamp:q!==void 0?q:(0,g.u)()};T=await MZ(T);await T.clear("coldConfigStore");return await T.put("coldConfigStore",f)};
  oow = async function(f){if(f.j)return rf();if(!f.S)return f=g.eB("getColdConfig IDB not initialized"),ZH(f),Promise.reject(f);var a=W8(),e=g.gp("TIME_CREATED_MS");if(a){var T=await Gu7(a);if(T&&T.timestamp>e)return P8(f,T.config),iI$(f,T.configData),DW(f,T.hashData),rf()}else T=g.eB("getColdConfig"),ZH(T);ldo(f);a&&f.j&&f.coldHashData&&f.configData&&await J17(f.j,f.coldHashData,f.configData,a,e);return f.j?rf():(f=new g.vc("Config not available in ytConfig"),ZH(f),Promise.reject(f))};
  g.Fh = function(f){window.clearTimeout(f)};
  var Lt = [];
  aEq = function(f){Lt.forEach(a=>{a(f)})};
  g.hC = function(f){eGw(f,"ERROR");aEq(f)};
  g.uj = function(f){var a=window;return f&&a.yterr?function(...e){try{return f.apply(this,e)}catch(T){g.hC(T instanceof Error?T:Error(String(T)))}}:f};
  g.Ty = function(f,a){typeof f==="function"&&(f=g.uj(f));return window.setTimeout(f,a)};
  DR = function(f,a,e,T){T!==void 0&&Number.isNaN(Number(T))&&(T=void 0);return(f=g.yY("yt.scheduler.instance.addJob"))?f(a,e,T):T===void 0?(a(),NaN):g.Ty(a,T||0)};
  var xgJ = class{constructor(){this.j=new WeakMap}jK(f,a){return DR(0,f,1,a)}oi(f){(f=this.j.get(f))&&f()}};
  O$ = class extends xgJ{Mg(f){if(f===void 0||!Number.isNaN(Number(f))){var a=g.yY("yt.scheduler.instance.cancelJob");a?a(f):g.Fh(f)}}start(){var f=g.yY("yt.scheduler.instance.start");f&&f()}pause(){var f=g.yY("yt.scheduler.instance.pause");f&&f()}};
  g.Rc = function(){O$.instance||(O$.instance=new O$);return O$.instance};
  g.tQ = undefined;
  wj1 = function(f){if(!f.B||!f.j){if(!W8()){let a=g.eB("scheduleGetConfigs");ZH(a)}f.A||(f.A=g.tQ.jK(async()=>{try{await QHT(f)}catch{}try{await oow(f)}catch{}f.A&&(f.A=0)},100))}};
  var KW = class{constructor(){this.S=!1;this.K=this.A=0;this.G=new QB_;this.FU={uPR:()=>{this.S=!0},
vxs:()=>this.j,
I1U:f=>{Uo(this,f)},
wl:f=>{this.wl(f)},
Z6H:f=>{P8(this,f)},
uU:()=>this.coldHashData,
Gd:()=>this.hotHashData,
uyi:()=>this.B,
K0R:()=>rf(),
wsU:()=>v8(),
zXZ:()=>g.yY("yt.gcf.config.coldHashData"),
A$i:()=>g.yY("yt.gcf.config.hotHashData"),
jes:()=>{wj1(this)},
qvh:()=>{this.wl(void 0);DW(this);delete KW.instance},
tGu:f=>{this.K=f},
jqi:()=>this.K}}h6(){return v8()??g.gp("RAW_HOT_CONFIG_GROUP")}wl(f){this.hotHashData=f;
g.x3("yt.gcf.config.hotHashData",this.hotHashData||null)}};
  var WH = class{constructor(f){this.key=f}};
  iA = function(f){return new WH(f)};
  hbY = function(f,a){var e=f.A.get(a);if(e)try{e.l2(f.resolve(a))}catch(T){e.Bt(T)}for(let T of f.children)T.B.has(a)||hbY(T,a)};
  Ik = function(f,a){f.B.set(a.yU,a);hbY(f,a.yU)};
  var I5d = class{constructor(){this.stack=[]}push(f,a){this.stack.push({key:f,f7:a})}pop(){this.stack.pop()}};
  LCq = function(f,a,e){return f.stack.some(T=>{if(T.key!==a)return!1;var q=Math.min(T.f7.length,e.length);for(let F=0;F<q;F++)if(T.f7[F]!==e[F])return!1;return!0})};
  var Mv = Symbol("injectionDeps");
  uDw = function(f,a){return a?a.map(e=>e instanceof WH?KK(f,e.key,!0):KK(f,e)):[]};
  KK = function(f,a,e=!1){if(LCq(f.K,a,f.f7))throw Error(`Deps cycle for: ${a}`);if(f.j.has(a))return f.j.get(a);if(f.B.has(a)){f.K.push(a,f.f7);try{let F=f.B.get(a);var T=F;if(T.s6!==void 0)var q=T.s6;else if(T.i_){let E=T[Mv]?uDw(f,T[Mv]):[];q=T.i_(...E)}else if(T.lG){let E=T.lG,H=E[Mv]?uDw(f,E[Mv]):[];q=new E(...H)}else{if(!e)throw Error(`Could not resolve providers for: ${a}`);q=void 0}F.ZY||f.j.set(a,q);return q}finally{f.K.pop()}}if(f.parent)return KK(f.parent,a,e);if(!e)throw Error(`No provider for: ${a}`);
};
  var $b7 = class{constructor(){this.B=new Map;this.A=new Map;this.j=new Map;this.children=new Set;this.FU={WN:()=>{var f=this.parent?this.parent.FU.WN():new Map;for(let [a,e]of this.B.entries())f.set(a,e);return f},
Fhi:f=>{var a=this.B.get(f.yU),e=this.j.get(f.yU);this.j.delete(f.yU);Ik(this,f);return()=>{this.B.delete(f.yU);this.j.delete(f.yU);a&&Ik(this,a);e&&this.j.set(f.yU,e)}}};
this.parent=null;this.f7=[this];this.K=new I5d;this.parent?.children.add(this)}resolve(f){return f instanceof WH?KK(this,f.key,!0):KK(this,f)}};
  ZPY = undefined;
  Us = undefined;
  PH = function(){Us||(Us=ZPY=new $b7);return Us};
  N90 = function(f){if(g.C2("enable_web_tiered_gel")){f=jt6[f||""];var a=PH().resolve(iA(KW))?.h6()?.loggingHotConfig?.eventLoggingConfig?.payloadPolicies;if(a)for(let e=0;e<a.length;e++)if(a[e].payloadNumber===f)return a[e]}};
  Qto = function(f){switch(f){case "DELAYED_EVENT_TIER_UNSPECIFIED":return 0;case "DELAYED_EVENT_TIER_DEFAULT":return 100;case "DELAYED_EVENT_TIER_DISPATCH_TO_EMPTY":return 200;case "DELAYED_EVENT_TIER_FAST":return 300;case "DELAYED_EVENT_TIER_IMMEDIATE":return 400;default:return 200}};
  bA = function(f){return[f.auth===void 0?"undefined":f.auth,f.isJspb===void 0?"undefined":f.isJspb,f.cttAuthInfo===void 0?"undefined":f.cttAuthInfo,f.tier===void 0?"undefined":f.tier].join("/")};
  LK = function(f,a){return f===void 0||f==="undefined"?!0:f===a};
  hi = function(f,a){var e=bA(a);if(f.B[e])return f.B[e];var T=Object.keys(f.store)||[];if(T.length<=1&&bA(a)===T[0])return T;var q=[];for(let E=0;E<T.length;E++){let H=T[E].split("/");if(LK(a.auth,H[0])){var F=a.isJspb;LK(F===void 0?"undefined":F?"true":"false",H[1])&&LK(a.cttAuthInfo,H[2])&&(F=a.tier,F=F===void 0?"undefined":JSON.stringify(F),LK(F,H[3])&&q.push(T[E]))}}return f.B[e]=q};
  var $J = class{constructor(){this.store={};this.j=0;this.B={};this.FU={iEh:()=>this.j}}storePayload(f,a){f=bA(f);
this.store[f]?this.store[f].push(a):(this.B={},this.store[f]=[a]);this.j++;g.C2("more_accurate_gel_parser")&&(a=new CustomEvent("TRANSPORTING_NEW_EVENT"),window.dispatchEvent(a));return f}smartExtractMatchingEntries(f){if(!f.keys.length)return[];var a=hi(this,f.keys.splice(0,1)[0]),e=[];for(let T=0;T<a.length;T++)this.store[a[T]]&&f.sizeLimit&&(this.store[a[T]].length<=f.sizeLimit?(e.push(...this.store[a[T]]),delete this.store[a[T]]):e.push(...this.store[a[T]].splice(0,f.sizeLimit)));this.j-=e.length;
f?.sizeLimit&&e.length<f?.sizeLimit&&(f.sizeLimit-=e.length,e.push(...this.smartExtractMatchingEntries(f)));return e}extractMatchingEntries(f){f=hi(this,f);var a=[];for(let e=0;e<f.length;e++)this.store[f[e]]&&(a.push(...this.store[f[e]]),delete this.store[f[e]]);this.j-=a.length;return a}getSequenceCount(f){f=hi(this,f);var a=0;for(let e=0;e<f.length;e++)a+=this.store[f[e]]?.length||0;return a}};
  cH = function(){var f=g.yY("yt.logging.ims");f||(f=new $J,g.x3("yt.logging.ims",f));return f};
  var x7$ = null;
  SAg = function(){return g.C2("html5_send_qoe_on_gel")||g.C2("web_send_vss3_isolated_payload")};
  var uA = void 0;
  Zn = function(f){x7$=f;SAg()&&(g.S6.ytLoggingTransportRegisteredClientCtor_=f);uA=new f};
  yQg = function(f){return f?f:SAg()?x7$||g.S6.ytLoggingTransportRegisteredClientCtor_||null:null};
  jG = function(f){return f==="gelDebuggingEvent"||f==="watchTimeSegment"};
  Ok6 = function(f=!1){return f&&g.C2("vss_through_gel_video_stats")?"video_stats":"log_event"};
  Ak = function(){return g.gp("EXPERIMENTS_TOKEN","")};
  xq = function(){var f=[],a=g.gp("EXPERIMENTS_FORCED_FLAGS",{});for(var e of Object.keys(a))f.push({key:e,value:String(a[e])});e=g.gp("EXPERIMENT_FLAGS",{});for(let T of Object.keys(e))T.startsWith("force_")&&a[T]===void 0&&f.push({key:T,value:String(e[T])});return f};
  nQ = function(){if(!g.S6.matchMedia)return"WEB_DISPLAY_MODE_UNKNOWN";try{return g.S6.matchMedia("(display-mode: standalone)").matches?"WEB_DISPLAY_MODE_STANDALONE":g.S6.matchMedia("(display-mode: minimal-ui)").matches?"WEB_DISPLAY_MODE_MINIMAL_UI":g.S6.matchMedia("(display-mode: fullscreen)").matches?"WEB_DISPLAY_MODE_FULLSCREEN":g.S6.matchMedia("(display-mode: browser)").matches?"WEB_DISPLAY_MODE_BROWSER":"WEB_DISPLAY_MODE_UNKNOWN"}catch(f){return"WEB_DISPLAY_MODE_UNKNOWN"}};
  var R$ = class extends Iq{constructor(f){super(f)}};
  Yf = function(f,a,e){if(f!=null&&f[Vg]===OC)return f;if(Array.isArray(f)){var T=f[ut]|0;e=T|e&32|e&2;e!==T&&(f[ut]=e);return new a(f)}};
  yG = function(f,a){a===void 0&&(a=f[ut]|0);a&32&&!(a&4096)&&(f[ut]=a|4096)};
  gL = function(f,a,e,T,q){var F=!1;T=Je(f,T,q,E=>{var H=Yf(E,e,a);F=H!==E&&H!=null;return H});
if(T!=null)return F&&!ZK(T)&&yG(f,a),T};
  Ae = function(f){var a=f.uN,e=a[ut]|0;return ZK(f,e)?FZ(f,a,e)?EG(f,a,!0):new f.constructor(qw(a,e,!1)):f};
  uX = function(f,a,e,T){var q=f.uN,F=q[ut]|0;a=gL(q,F,a,e,T);if(a==null)return a;F=q[ut]|0;if(!ZK(f,F)){let E=Ae(a);E!==a&&(SN(f)&&(q=f.uN,F=q[ut]|0),a=E,F=pq(q,F,e,a,T),yG(q,F))}return a};
  var RyN = {dRH:"WEB_DISPLAY_MODE_UNKNOWN",a7u:"WEB_DISPLAY_MODE_BROWSER",j8o:"WEB_DISPLAY_MODE_MINIMAL_UI",kW0:"WEB_DISPLAY_MODE_STANDALONE",bkU:"WEB_DISPLAY_MODE_FULLSCREEN"};
  Xj = function(f){f=Error(f);m2(f,"warning");return f};
  var JT = {};
  Bs = function(f,a,e){xL(f);var T=f.uN;pq(T,T[ut]|0,a,e);return f};
  H4 = function(f,a,e){if(e!=null){if(!JT(e))throw Xj("enum");e|=0}return Bs(f,a,e)};
  xf = function(f){return f.displayName||f.name||"unknown type name"};
  DT = function(f,a){if(!(f instanceof a))throw Error(`Expected instanceof ${xf(a)} but got ${f&&xf(f.constructor)}`);return f};
  mi = function(f,a){f!=null?DT(f,a):f=void 0;return f};
  te = function(f,a,e,T){T=mi(T,a);Bs(f,e,T);T&&!ZK(T)&&yG(f.uN);return f};
  Png = function(f,a,e){f=f.NH;if(f==="WEB"||f==="MWEB"||f===1||f===2)a?(e=uX(a,R$,96)||new R$,f=nQ(),f=Object.keys(RyN).indexOf(f),f=f===-1?null:f,f!==null&&H4(e,3,f),te(a,R$,96,e)):e&&(e.client.mainAppWebInfo=e.client.mainAppWebInfo??{},e.client.mainAppWebInfo.webDisplayMode=nQ())};
  Qg = function(f){if(f==null)return f;if(typeof f==="string"&&f)f=+f;else if(typeof f!=="number")return;return JT(f)?f>>>0:void 0};
  var Jdo = [];
  QG = undefined;
  Nw = function(f,a,e){f=Je(f,a,e);return Array.isArray(f)?f:QG};
  oD = function(f,a){2&a&&(f|=2);return f|1};
  nq = function(f){return!!(2&f)&&!!(4&f)||!!(256&f)};
  Ws = function(f,a){return f=(2&a?f|2:f&-3)&-273};
  wL = function(f,a,e,T,q,F,E,H,C){var A=a,y=nq(a);y&&E===2&&(f=[...f],A=0,a=Ws(a,T),T=pq(e,T,q,f,F),y=!1);y||(E===1||(E!==4?0:2&a||!(16&a)&&32&T)?(a|=!f.length||H&&!(4096&a)||32&T&&!(4096&a||16&a)?2:256,a!==A&&(f[ut]=a),Object.freeze(f)):(C||(a|=16),a!==A&&(f[ut]=a)));2&a||!(4096&a||16&a)||yG(e,T);return f};
  lX = function(f,a,e,T,q){var F=f.uN,E=F[ut]|0;T=T&&T!==4?T!==1&&ZK(f,E)?1:T:4;q=!!q||T===3;T===2&&SN(f)&&(F=f.uN,E=F[ut]|0);f=Nw(F,a);var H=f===QG?7:f[ut]|0,C=oD(H,E);var A=4&C?!1:!0;if(A){let y=0,J=0;for(;y<f.length;y++){let p=e(f[y]);p!=null&&(f[J++]=p)}J<y&&(f.length=J);e=(C|4)&-513;C=e&=-1025;C&=-4097}C!==H&&(f[ut]=C,2&C&&Object.freeze(f));return f=wL(f,C,F,E,a,void 0,T,A,q)};
  cV = function(f,a){if(typeof a!=="number"||a<0||a>=f.length)throw Error();};
  var YH = class extends Iq{constructor(f){super(f)}HY(f){var a=lX(this,5,Qg,3,!0);cV(a,f);return a[f]}};
  EV = function(f,a,e){return Bs(f,a,rG(e))};
  r1w = function(f,a){var e=g.yY("yt.embedded_player.embed_url");e&&(f?(a=uX(f,YH,7)||new YH,EV(a,4,e),te(f,YH,7,a)):a&&(a.thirdParty={embedUrl:e}))};
  var yG0 = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  Gx = function(f){switch(typeof f){case "bigint":return!0;case "number":return JT(f);case "string":return yG0.test(f);default:return!1}};
  var ir = {};
  var ku = undefined;
  var E8 = undefined;
  jX = function(f){if(E8(f)){if(!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(f))throw Error(String(f));}else if(ku(f)&&!Number.isSafeInteger(f))throw Error(String(f));return BigInt(f)};
  var lr = {};
  var wG = undefined;
  o1 = function(f){var a=ir(Number(f));if(lr(a))return jX(a);a=f.indexOf(".");a!==-1&&(f=f.substring(0,a));return jX(wG(64,BigInt(f)))};
  var fp = 0;
  var a1 = 0;
  e_ = function(f){var a=f>>>0;fp=a;a1=(f-a)/4294967296>>>0};
  sC = function(f){if(f<0){e_(0-f);f=fp;var a=a1;a=~a;f?f=~f+1:a+=1;let [e,T]=[f,a];fp=e>>>0;a1=T>>>0}else e_(f)};
  Tx = function(f,a){a>>>=0;f>>>=0;var e;a<=2097151?e=""+(4294967296*a+f):e=""+(BigInt(a)<<BigInt(32)|BigInt(f));return e};
  Cp = function(){var f=fp,a=a1,e;a&2147483648?e=""+(BigInt(a|0)<<BigInt(32)|BigInt(f>>>0)):e=Tx(f,a);return e};
  np = function(f){Gx(f);f=ir(f);lr(f)?f=String(f):(sC(f),f=Cp());return f};
  W6 = function(f){if(f!=null)a:{if(!Gx(f))throw Xj("int64");switch(typeof f){case "string":f=o1(f);break a;case "bigint":f=jX(wG(64,f));break a;default:f=jX(lr(f)?f:np(f))}}return f};
  voY = function(f,a){if(g.C2("web_log_memory_total_kbytes")&&g.S6.navigator?.deviceMemory){let e=g.S6.navigator?.deviceMemory;f?Bs(f,95,W6(e*1E6)):a&&(a.client.memoryTotalKbytes=`${e*1E6}`)}};
  eU = function(f,a,e="",T){return v6(GK(f,a,T))??e};
  var X$ = class extends Iq{constructor(f){super(f)}uU(){return eU(this,3)}Gd(){return eU(this,5)}wl(f){return EV(this,5,f)}};
  DPg = function(f,a,e){f.appInstallData&&(a?(e=uX(a,X$,62)??new X$,EV(e,6,f.appInstallData),te(a,X$,62,e)):e&&(e.client.configInfo=e.client.configInfo||{},e.client.configInfo.appInstallData=f.appInstallData))};
  GC3 = function(){var f=g.S6.navigator;return f?f.connection:void 0};
  var pZq = {bluetooth:"CONN_DISCO",cellular:"CONN_CELLULAR_UNKNOWN",ethernet:"CONN_WIFI",none:"CONN_NONE",wifi:"CONN_WIFI",wimax:"CONN_CELLULAR_4G",other:"CONN_UNKNOWN",unknown:"CONN_UNKNOWN","slow-2g":"CONN_CELLULAR_2G","2g":"CONN_CELLULAR_2G","3g":"CONN_CELLULAR_3G","4g":"CONN_CELLULAR_4G"};
  BZT = function(){var f=GC3();if(f){var a=pZq[f.type||"unknown"]||"CONN_UNKNOWN";f=pZq[f.effectiveType||"unknown"]||"CONN_UNKNOWN";a==="CONN_CELLULAR_UNKNOWN"&&f!=="CONN_UNKNOWN"&&(a=f);if(a!=="CONN_UNKNOWN")return a;if(f!=="CONN_UNKNOWN")return f}};
  var Ypq = {CONN_DEFAULT:0,CONN_UNKNOWN:1,CONN_NONE:2,CONN_WIFI:3,CONN_CELLULAR_2G:4,CONN_CELLULAR_3G:5,CONN_CELLULAR_4G:6,CONN_CELLULAR_UNKNOWN:7,CONN_DISCO:8,CONN_CELLULAR_5G:9,CONN_WIFI_METERED:10,CONN_CELLULAR_5G_SA:11,
CONN_CELLULAR_5G_NSA:12,CONN_WIRED:30,CONN_INVALID:31};
  var Xjw = {EFFECTIVE_CONNECTION_TYPE_UNKNOWN:0,EFFECTIVE_CONNECTION_TYPE_OFFLINE:1,EFFECTIVE_CONNECTION_TYPE_SLOW_2G:2,EFFECTIVE_CONNECTION_TYPE_2G:3,EFFECTIVE_CONNECTION_TYPE_3G:4,EFFECTIVE_CONNECTION_TYPE_4G:5};
  var NZN = {"slow-2g":"EFFECTIVE_CONNECTION_TYPE_SLOW_2G","2g":"EFFECTIVE_CONNECTION_TYPE_2G","3g":"EFFECTIVE_CONNECTION_TYPE_3G","4g":"EFFECTIVE_CONNECTION_TYPE_4G"};
  QXy = function(){var f=GC3();if(f?.effectiveType)return NZN.hasOwnProperty(f.effectiveType)?NZN[f.effectiveType]:"EFFECTIVE_CONNECTION_TYPE_UNKNOWN"};
  V8y = function(f,a){var e=BZT();e&&(f?H4(f,61,Ypq[e]):a&&(a.client.connectionType=e));g.C2("web_log_effective_connection_type")&&(e=QXy())&&(f?H4(f,94,Xjw[e]):a&&(a.client.effectiveConnectionType=e))};
  Nq0 = function(){if(!KW.instance){let f=new KW;KW.instance=f}return KW.instance};
  Ktw = function(){var f=Nq0(),a=(0,g.u)()-f.K;if(!(f.K!==0&&a<g.d6("send_config_hash_timer"))){a=g.yY("yt.gcf.config.coldConfigData");var e=g.yY("yt.gcf.config.hotHashData"),T=g.yY("yt.gcf.config.coldHashData");a&&e&&T&&(f.K=(0,g.u)());return{coldConfigData:a,hotHashData:e,coldHashData:T}}};
  OIY = function(f,a){var e=Ktw();if(e){var T=e.coldConfigData,q=e.coldHashData;e=e.hotHashData;f?(a=uX(f,X$,62)??new X$,T=EV(a,1,T),EV(T,3,q).wl(e),te(f,X$,62,a)):a&&(a.client.configInfo=a.client.configInfo||{},T&&(a.client.configInfo.coldConfigData=T),q&&(a.client.configInfo.coldHashData=q),e&&(a.client.configInfo.hotHashData=e))}};
  var Tb6 = String($g);
  var quY = {};
  ec = function(f){return decodeURIComponent(f.replace(/\+/g," "))};
  var EB0 = /^[\w.]*$/;
  szy = function(f){return f&&f.match(EB0)?f:ec(f)};
  Go = function(f){var a=typeof f;return a!="object"?a:f?Array.isArray(f)?"array":a:"null"};
  g.N6 = function(f){var a=Go(f);return a=="array"||a=="object"&&typeof f.length=="number"};
  g.Ch = function(f,a){for(let e=1;e<arguments.length;e++){let T=arguments[e];if(g.N6(T)){let q=f.length||0,F=T.length||0;f.length=q+F;for(let E=0;E<F;E++)f[q+E]=T[E]}else f.push(T)}};
  $g = function(f,a){a=f.split(a);var e={};for(let F=0,E=a.length;F<E;F++){let H=a[F].split("=");if(H.length===1&&H[0]||H.length===2)try{let C=szy(H[0]||""),A=szy(H[1]||"");if(C in e){let y=e[C];Array.isArray(y)?g.Ch(y,A):e[C]=[y,A]}else e[C]=A}catch(C){var T=C,q=H[0];let A=String($g);T.args=[{key:q,value:H[1],query:f,method:Tb6===A?"unchanged":A}];quY.hasOwnProperty(q)||ZH(T)}}return e};
  ct = function(f){f.charAt(0)==="?"&&(f=f.substring(1));return $g(f,"&")};
  g.Oo = function(f){var a={client:{hl:f.L_,gl:f.gi,clientName:f.NH,clientVersion:f.innertubeContextClientVersion,configInfo:f.It}};navigator.userAgent&&(a.client.userAgent=String(navigator.userAgent));var e=g.S6.devicePixelRatio;e&&e!=1&&(a.client.screenDensityFloat=String(e));e=Ak();e!==""&&(a.client.experimentsToken=e);e=xq();e.length>0&&(a.request={internalExperimentFlags:e});Png(f,void 0,a);r1w(void 0,a);voY(void 0,a);DPg(f,void 0,a);V8y(void 0,a);g.C2("start_client_gcf")&&OIY(void 0,a);g.gp("DELEGATED_SESSION_ID")&&
!g.C2("pageid_as_header_web")&&(a.user={onBehalfOfUser:g.gp("DELEGATED_SESSION_ID")});!g.C2("fill_delegate_context_in_gel_killswitch")&&(f=g.gp("INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT"))&&(a.user={...a.user,serializedDelegationContext:f});f=g.gp("INNERTUBE_CONTEXT");g.C2("enable_persistent_device_token")&&f?.client?.rolloutToken&&(a.client.rolloutToken=f?.client?.rolloutToken);f=Object;e=f.assign;var T=a.client,q=g.gp("DEVICE",""),F={};for(let [E,H]of Object.entries(ct(q))){q=E;let C=H;q===
"cbrand"?F.deviceMake=C:q==="cmodel"?F.deviceModel=C:q==="cbr"?F.browserName=C:q==="cbrver"?F.browserVersion=C:q==="cos"?F.osName=C:q==="cosver"?F.osVersion=C:q==="cplatform"&&(F.platform=C)}a.client=e.call(f,T,F);g.C2("web_attention_logging_enabled")&&(a.client.windowWidthPoints=window.innerWidth,a.client.windowHeightPoints=window.innerHeight);return a};
  g.Lh = function(f){if(!f||typeof f!=="object")return f;if(typeof f.clone==="function")return f.clone();if(typeof Map!=="undefined"&&f instanceof Map)return new Map(f);if(typeof Set!=="undefined"&&f instanceof Set)return new Set(f);if(f instanceof Date)return new Date(f.getTime());var a=Array.isArray(f)?[]:typeof ArrayBuffer!=="function"||typeof ArrayBuffer.isView!=="function"||!ArrayBuffer.isView(f)||f instanceof DataView?{}:new f.constructor(f.length);for(let e in f)a[e]=g.Lh(f[e]);return a};
  R9$ = function(f,a,e){if(e.videoId)var T="VIDEO";else if(e.playlistId)T="PLAYLIST";else return;f.credentialTransferTokenTargetId=e;f.context=f.context||{};f.context.user=f.context.user||{};f.context.user.credentialTransferTokens=[{token:a,scope:T}]};
  yv = function(){return g.C2("use_request_time_ms_header")};
  Zko = function(){var f=g.gp("BATCH_CLIENT_COUNTER")||0;f||(f=Math.floor(Math.random()*65535/2));f++;f>65535&&(f=1);X5("BATCH_CLIENT_COUNTER",f);return f};
  YAg = function(f,a,e){yv()||(f.requestTimeMs=String(a));g.C2("unsplit_gel_payloads_in_logs")&&(f.unsplitGelPayloadsInLogs=!0);!e&&(a=g.gp("EVENT_ID"))&&(e=Zko(),f.serializedClientEventId={serializedEventId:a,clientCounter:String(e)})};
  Xq3 = function(f){g.C2("always_send_and_write")&&(f.writeThenSend=!1)};
  g.fJ = class{constructor(f){this.name=f}};
  var cQT = {};
  g.Y = function(f,a){if(f)return f[a.name]};
  var m70 = {};
  Id3 = async function(f,a,e){if(g.C2("start_client_gcf")){e&&Uo(f,e);f.wl(a);let T=W8();T&&(e||(e=(await pj7(T))?.config),await y1T(e,a,T));if(e){f=f.G;for(let q of f.j)q(e)}}};
  M8q = async function(f,a,e){g.C2("start_client_gcf")&&(DW(f,a),f=W8())&&(e||(e=(await Gu7(f))?.config),e&&await J17(e,a,e.configData,f))};
  var pJ = class{constructor(f){this.name=f}toString(){return`InjectionToken(${this.name})`}};
  var tQN = {};
  gSq = async function(f){f=f?.responseContext?.globalConfigGroup;var a=g.Y(f,cQT),e=f?.hotHashData,T=g.Y(f,m70),q=f?.coldHashData,F=PH().resolve(iA(KW));F&&(e&&(a?await Id3(F,e,a):await Id3(F,e)),q&&(T?await M8q(F,q,T):await M8q(F,q)));a=f?.rawFinchStaticConfigGroup;(f=f?.finchStaticHashData)?(e=PH().resolve(iA(tQN)))?await e.B6Z({config:a||{},H$Z:f||""}):(a||f)&&ZH(new g.vc("FinchConfigManagerService is not present, but Finch config data is present.")):a&&ZH(new g.vc("Finch config data is present, but hash is missing."))};
  CR = function(f,a,e,T,q){f={retry:!0,onSuccess:e,onError:T,networklessOptions:f,dangerousLogToVisitorSession:a,oHi:!!q,headers:{},postBodyFormat:"",postBody:"",compress:g.C2("compress_gel")||g.C2("compress_gel_lr")};yv()&&(f.headers["X-Goog-Request-Time"]=JSON.stringify(Math.round((0,g.u)())));return f};
  var gf = {identityType:"UNAUTHENTICATED_IDENTITY_TYPE_UNKNOWN"};
  jBN = function(f){if(!f)return"";if(/^about:(?:blank|srcdoc)$/.test(f))return window.origin||"";f.indexOf("blob:")===0&&(f=f.substring(5));f=f.split("#")[0].split("?")[0];f=f.toLowerCase();f.indexOf("//")==0&&(f=window.location.protocol+f);/^[\w\-]*:\/\//.test(f)||(f=window.location.href);var a=f.substring(f.indexOf("://")+3),e=a.indexOf("/");e!=-1&&(a=a.substring(0,e));e=f.substring(0,f.indexOf("://"));if(!e)throw Error("URI is missing protocol: "+f);if(e!=="http"&&e!=="https"&&e!=="chrome-extension"&&
e!=="moz-extension"&&e!=="file"&&e!=="android-app"&&e!=="chrome-search"&&e!=="chrome-untrusted"&&e!=="chrome"&&e!=="app"&&e!=="devtools")throw Error("Invalid URI scheme in origin: "+e);f="";var T=a.indexOf(":");if(T!=-1){var q=a.substring(T+1);a=a.substring(0,T);if(e==="http"&&q!=="80"||e==="https"&&q!=="443")f=":"+q}return e+"://"+a+f};
  g.bw = function(f,a,e){Array.prototype.forEach.call(f,a,e)};
  fK6 = function(){function f(){q[0]=1732584193;q[1]=4023233417;q[2]=2562383102;q[3]=271733878;q[4]=3285377520;y=A=0}
function a(J){for(var p=E,B=0;B<64;B+=4)p[B/4]=J[B]<<24|J[B+1]<<16|J[B+2]<<8|J[B+3];for(B=16;B<80;B++)J=p[B-3]^p[B-8]^p[B-14]^p[B-16],p[B]=(J<<1|J>>>31)&4294967295;J=q[0];var w=q[1],P=q[2],O=q[3],R=q[4];for(B=0;B<80;B++){if(B<40)if(B<20){var h=O^w&(P^O);var X=1518500249}else h=w^P^O,X=1859775393;else B<60?(h=w&P|O&(w|P),X=2400959708):(h=w^P^O,X=3395469782);h=((J<<5|J>>>27)&4294967295)+h+R+X+p[B]&4294967295;R=O;O=P;P=(w<<30|w>>>2)&4294967295;w=J;J=h}q[0]=q[0]+J&4294967295;q[1]=q[1]+w&4294967295;q[2]=
q[2]+P&4294967295;q[3]=q[3]+O&4294967295;q[4]=q[4]+R&4294967295}
function e(J,p){if(typeof J==="string"){J=unescape(encodeURIComponent(J));for(var B=[],w=0,P=J.length;w<P;++w)B.push(J.charCodeAt(w));J=B}p||(p=J.length);B=0;if(A==0)for(;B+64<p;)a(J.slice(B,B+64)),B+=64,y+=64;for(;B<p;)if(F[A++]=J[B++],y++,A==64)for(A=0,a(F);B+64<p;)a(J.slice(B,B+64)),B+=64,y+=64}
function T(){var J=[],p=y*8;A<56?e(H,56-A):e(H,64-(A-56));for(var B=63;B>=56;B--)F[B]=p&255,p>>>=8;a(F);for(B=p=0;B<5;B++)for(var w=24;w>=0;w-=8)J[p++]=q[B]>>w&255;return J}
for(var q=[],F=[],E=[],H=[128],C=1;C<64;++C)H[C]=0;var A,y;f();return{reset:f,update:e,digest:T,Xw:function(){for(var J=T(),p="",B=0;B<J.length;B++)p+="0123456789ABCDEF".charAt(Math.floor(J[B]/16))+"0123456789ABCDEF".charAt(J[B]%16);return p}}};
  sE7 = function(f){var a=fK6();a.update(f);return a.Xw().toLowerCase()};
  aK6 = function(f,a,e){var T=[],q=[];if((Array.isArray(e)?2:1)==1)return q=[a,f],g.bw(T,function(H){q.push(H)}),sE7(q.join(" "));
var F=[],E=[];g.bw(e,function(H){E.push(H.key);F.push(H.value)});
e=Math.floor((new Date).getTime()/1E3);q=F.length==0?[e,a,f]:[F.join(":"),e,a,f];g.bw(T,function(H){q.push(H)});
f=sE7(q.join(" "));f=[e,f];E.length==0||f.push(E.join(""));return f.join("_")};
  e4q = function(f,a,e){var T=String(g.S6.location.href);return T&&f&&a?[a,aK6(jBN(T),f,e||null)].join(" "):null};
  q80 = function(f,a,e,T){(f=g.S6[f])||typeof document==="undefined"||(f=(new NP(document)).get(a));return f?e4q(f,e,T):null};
  Trq = function(){var f=g.S6.__SAPISID||g.S6.__APISID||g.S6.__3PSAPISID||g.S6.__1PSAPISID||g.S6.__OVERRIDE_SID;if(f)return!0;typeof document!=="undefined"&&(f=new NP(document),f=f.get("SAPISID")||f.get("APISID")||f.get("__Secure-3PAPISID")||f.get("__Secure-1PAPISID"));return!!f};
  Fxg = function(f){var a=jBN(g.S6?.location.href),e=[];if(Trq()){a=a.indexOf("https:")==0||a.indexOf("chrome-extension:")==0||a.indexOf("chrome-untrusted://new-tab-page")==0||a.indexOf("moz-extension:")==0;var T,q=(T=a)?g.S6.__SAPISID:g.S6.__APISID;q||typeof document==="undefined"||(q=new NP(document),q=q.get(T?"SAPISID":"APISID")||q.get("__Secure-3PAPISID"));(T=q?e4q(q,T?"SAPISIDHASH":"APISIDHASH",f):null)&&e.push(T);a&&((a=q80("__1PSAPISID","__Secure-1PAPISID","SAPISID1PHASH",f))&&e.push(a),(f=q80("__3PSAPISID",
"__Secure-3PAPISID","SAPISID3PHASH",f))&&e.push(f))}return e.length==0?null:e.join(" ")};
  var Wc = class{constructor(){this.iu=!0}UD(f,a){f={};var e=[];"USER_SESSION_ID"in Yg&&e.push({key:"u",value:g.gp("USER_SESSION_ID")});if(e=Fxg(e))f.Authorization=e,e=a=a?.sessionIndex,e===void 0&&(e=Number(g.gp("SESSION_INDEX",0)),e=isNaN(e)?0:e),g.C2("voice_search_auth_header_removal")||(f["X-Goog-AuthUser"]=e.toString()),"INNERTUBE_HOST_OVERRIDE"in Yg||(f["X-Origin"]=window.location.origin),a===void 0&&"DELEGATED_SESSION_ID"in Yg&&(f["X-Goog-PageId"]=g.gp("DELEGATED_SESSION_ID"));return f}};
  S11 = function(){Wc.instance||(Wc.instance=new Wc);return Wc.instance};
  goT = function(f,a,e={}){var T={};g.gp("EOM_VISITOR_DATA")?T={"X-Goog-EOM-Visitor-Id":g.gp("EOM_VISITOR_DATA")}:T={"X-Goog-Visitor-Id":e.visitorData||g.gp("VISITOR_DATA","")};if(a&&a.includes("www.youtube-nocookie.com"))return T;a=e.MQ||g.gp("AUTHORIZATION");a||(f?a=`Bearer ${g.yY("gapi.auth.getToken")().access_token}`:(f=S11().UD(gf),g.C2("pageid_as_header_web")||delete f["X-Goog-PageId"],T={...T,...f}));a&&(T.Authorization=a);return T};
  g.r_ = function(f,a){return f!==null&&a in f};
  g.aw = function(f){return encodeURIComponent(String(f))};
  Bx = function(f,a,e){if(Array.isArray(a))for(let T=0;T<a.length;T++)Bx(f,String(a[T]),e);else a!=null&&e.push(f+(a===""?"":"="+g.aw(a)))};
  g.Nr = function(f){var a=[];for(let e in f)Bx(e,f[e],a);return a.join("&")};
  px = function(f,a){if(!a)return f;var e=f.indexOf("#");e<0&&(e=f.length);var T=f.indexOf("?");if(T<0||T>e){T=e;var q=""}else q=f.substring(T+1,e);f=[f.slice(0,T),q,f.slice(e)];e=f[1];f[1]=a?e?e+"&"+a:a:e;return f[0]+(f[1]?"?"+f[1]:"")+f[2]};
  g.QU = function(f,a){a=g.Nr(a);return px(f,a)};
  F86 = function(f,a,e){var T=(f||"").split("#",2);f=T[0];T=T.length>1?"#"+T[1]:"";var q=f.indexOf("?"),F=q!==-1?f.substring(0,q):f;f=ct(q!==-1?f.substring(q+1):"");for(let E in a)if(e||!g.r_(f,E))f[E]=a[E];return g.QU(F,f)+T};
  zS = function(f,a){return F86(f,a||{},!0)};
  Qzg = function(f,a){a.includeDomain&&(f=document.location.protocol+"//"+document.location.hostname+(document.location.port?":"+document.location.port:"")+f);var e=g.gp("XSRF_FIELD_NAME");if(a=a.urlParams)a[e]&&delete a[e],f=zS(f,a);return f};
  var cG1 = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
  g.Sq = function(f){return f.match(cG1)};
  me6 = function(f){return f?decodeURI(f):f};
  g.xB = function(f){return me6(g.Sq(f)[3]||null)};
  var hG = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
  g.u0 = function(f,a){for(let q=1;q<arguments.length;q++){var e=arguments[q];for(T in e)f[T]=e[T];for(let F=0;F<hG.length;F++){var T=hG[F];Object.prototype.hasOwnProperty.call(e,T)&&(f[T]=e[T])}}};
  g.RA = function(f){for(let a in f)return!1;return!0};
  var IE1 = !1;
  oBw = function(f,a){var e=g.gp("XSRF_FIELD_NAME"),T=g.gp("XSRF_TOKEN"),q=a.postBody||"",F=a.postParams,E=g.gp("XSRF_FIELD_NAME"),H;a.headers&&(H=a.headers["Content-Type"]);a.excludeXsrf||g.xB(f)&&!a.withCredentials&&g.xB(f)!==document.location.hostname||a.method!=="POST"||H&&H!=="application/x-www-form-urlencoded"||a.postParams&&a.postParams[E]||(F||(F={}),F[e]=T);F&&typeof q==="string"&&(q=ct(q),g.u0(q,F),q=a.postBodyFormat&&a.postBodyFormat==="JSON"?JSON.stringify(q):g.Nr(q));F=q||F&&!g.RA(F);!IE1&&
F&&a.method!=="POST"&&(IE1=!0,g.hC(Error("AJAX request with postData should use POST")));return q};
  e4 = function(f){return f&&"status"in f?f.status:-1};
  g.sP = function(f){switch(e4(f)){case 200:case 201:case 202:case 203:case 204:case 205:case 206:case 304:return!0;default:return!1}};
  K8q = function(f){var a="";g.bw(f.childNodes,e=>{a+=e.nodeValue});
return a};
  Mq1 = function(f){return f?(f=("responseXML"in f?f.responseXML:f).getElementsByTagName("root"))&&f.length>0?f[0]:null:null};
  var NK = {};
  o3o = function(){var f=null;if(!NK)return f;try{let a=e=>e;
f=NK.createPolicy("goog#html",{createHTML:a,createScript:a,createScriptURL:a})}catch(a){}return f};
  Ql = undefined;
  w8 = function(){Ql===void 0&&(Ql=o3o());return Ql};
  var Ro = class{constructor(f){this.j=f}toString(){return this.j+""}};
  Yp = function(f){var a=w8();f=a?a.createHTML(f):f;return new Ro(f)};
  z4 = function(f,a){var e=f.length-a.length;return e>=0&&f.indexOf(a,e)==e};
  g.QY = function(f){var a=typeof f;return a=="object"&&f!=null||a=="function"};
  Urq = function(f){if(g.QY(f))for(let a in f)a==="html_content"||z4(a,"_html")?f[a]=Yp(f[a]):Urq(f[a])};
  W8w = function(f,a,e,T){var q=null;switch(a){case "JSON":let F;try{F=e.responseText}catch(E){throw T=Error("Error reading responseText"),T.params=f,ZH(T),E;}f=e.getResponseHeader("Content-Type")||"";if(F&&f.indexOf("json")>=0){F.substring(0,5)===")]}'\n"&&(F=F.substring(5));try{q=JSON.parse(F)}catch(E){}}break;case "XML":if(f=(f=e.responseXML)?Mq1(f):null)q={},g.bw(f.getElementsByTagName("*"),E=>{q[E.tagName]=K8q(E)})}T&&Urq(q);
return q};
  ixw = function(f,a,e){if(a&&a.status===204)return!0;switch(f){case "JSON":return!!e;case "XML":return Number(e&&e.return_code)===0;case "RAW":return!0;default:return!!e}};
  var Suw = undefined;
  xr$ = function(){if(!Suw)return null;var f=Suw();return"open"in f?f:null};
  jl = function(f){if(!a)var a=window.location.href;var e=g.Sq(f)[1]||null,T=g.xB(f);e&&T?(f=g.Sq(f),a=g.Sq(a),f=f[3]==a[3]&&f[1]==a[1]&&f[4]==a[4]):f=T?g.xB(a)===T&&(Number(g.Sq(a)[4]||null)||null)===(Number(g.Sq(f)[4]||null)||null):!0;return f};
  yU = function(f){return me6(g.Sq(f)[5]||null)};
  var f50 = "absolute_experiments client_dev_domain client_dev_expflag client_dev_regex_map client_dev_root_url client_rollout_override expflag forcedCapability jsfeat jsmode mods theme".split(" ");
  var PoT = [];
  kg = function(f,a){return F86(f,a||{},!1)};
  px6 = function(f){var a=window.location.search,e=g.xB(f);g.C2("debug_handle_relative_url_for_query_forward_killswitch")||!e&&jl(f)&&(e=document.location.hostname);var T=yU(f);T=(e=e&&(e.endsWith("youtube.com")||e.endsWith("youtube-nocookie.com")))&&T&&T.startsWith("/api/");if(!e||T)return f;var q=ct(a),F={};g.bw(PoT,E=>{q[E]&&(F[E]=q[E])});
return kg(f,F)};
  var Nbo = {Authorization:"AUTHORIZATION","X-Goog-EOM-Visitor-Id":"EOM_VISITOR_DATA","X-Goog-Visitor-Id":"SANDBOXED_VISITOR_ID","X-Youtube-Domain-Admin-State":"DOMAIN_ADMIN_STATE","X-Youtube-Chrome-Connected":"CHROME_CONNECTED_HEADER","X-YouTube-Client-Name":"INNERTUBE_CONTEXT_CLIENT_NAME","X-YouTube-Client-Version":"INNERTUBE_CONTEXT_CLIENT_VERSION","X-YouTube-Delegation-Context":"INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT","X-YouTube-Device":"DEVICE","X-Youtube-Identity-Token":"ID_TOKEN","X-YouTube-Page-CL":"PAGE_CL",
"X-YouTube-Page-Label":"PAGE_BUILD_LABEL","X-Goog-AuthUser":"SESSION_INDEX","X-Goog-PageId":"DELEGATED_SESSION_ID"};
  var dr1 = {};
  var Hxw = undefined;
  var Al = window;
  CoN = function(f){a:{let e;try{e=f.j.top.location.href}catch(T){f=2;break a}f=e?e===f.B.location.href?0:1:2}f={dt:Hxw,flash:"0",frm:f};try{f.u_tz=-(new Date).getTimezoneOffset();try{var a=Al.history.length}catch(e){a=0}f.u_his=a;f.u_h=Al.screen?.height;f.u_w=Al.screen?.width;f.u_ah=Al.screen?.availHeight;f.u_aw=Al.screen?.availWidth;f.u_cd=Al.screen?.colorDepth}catch(e){}return f};
  g.WN = function(f,a){this.width=f;this.height=a};
  g.U = g.WN.prototype;
  g.U.clone = function(){return new g.WN(this.width,this.height)};
  g.U.aspectRatio = function(){return this.width/this.height};
  Iw = function(f){return f.width*f.height};
  g.U.isEmpty = function(){return!Iw(this)};
  g.U.ceil = function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
  g.U.floor = function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
  g.U.round = function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};
  g.U.scale = function(f,a){a=typeof a==="number"?a:f;this.width*=f;this.height*=a;return this};
  Li = function(f){f=f.document;f=f.compatMode=="CSS1Compat"?f.documentElement:f.body;return new g.WN(f.clientWidth,f.clientHeight)};
  Ep1 = function(f,a,e=!1){if(f&&a!==null&&a!=a.top){if(!a.top)return new g.WN(-12245933,-12245933);a=a.top}try{return e?(new g.WN(a.innerWidth,a.innerHeight)).round():Li(a||window).round()}catch(T){return new g.WN(-12245933,-12245933)}};
  var AhY = class{constructor(){this.data=[];this.j=-1}set(f,a=!0){0<=f&&f<52&&Number.isInteger(f)&&this.data[f]!==a&&(this.data[f]=a,this.j=-1)}get(f){return!!this.data[f]}};
  dr = function(f,a=document){return a.createElement(String(f).toLowerCase())};
  var f43 = {Ef:"allow-forms",aO:"allow-modals",bm:"allow-orientation-lock",jc:"allow-pointer-lock",k5:"allow-popups",d_:"allow-popups-to-escape-sandbox",x5:"allow-presentation",im:"allow-same-origin",BF:"allow-scripts",KW:"allow-top-navigation",zl:"allow-top-navigation-by-user-activation"};
  s8 = function(f,a){if(f)for(let e in f)Object.prototype.hasOwnProperty.call(f,e)&&a(f[e],e,f)};
  a4Y = function(){var f=[];s8(f43,a=>{f.push(a)});
return f};
  B5 = function(f){var a=!1,e;return function(){a||(e=f(),a=!0);return e}};
  var FV6 = undefined;
  EdN = function(){var f=dr("IFRAME"),a={};g.bw(FV6(),e=>{f.sandbox&&f.sandbox.supports&&f.sandbox.supports(e)&&(a[e]=!0)});
return a};
  OvY = function(f){f.j===-1&&(f.j=f.data.reduce((a,e,T)=>a+(e?2**T:0),0));
return f.j};
  mF = function(f){return f.prerendering?3:{visible:1,hidden:2,prerender:3,preview:4,unloaded:5,"":0}[f.visibilityState||f.webkitVisibilityState||f.mozVisibilityState||""]??0};
  kew = function(){return g.yY("yt.ads.biscotti.lastId_")||""};
  Pt = function(f=kew()){var a=dr1,e=Object,T=e.assign,q=CoN(a);var F=a.j;try{var E=F.screenX;var H=F.screenY}catch(O){}try{var C=F.outerWidth;var A=F.outerHeight}catch(O){}try{var y=F.innerWidth;var J=F.innerHeight}catch(O){}try{var p=F.screenLeft;var B=F.screenTop}catch(O){}try{y=F.innerWidth,J=F.innerHeight}catch(O){}try{var w=F.screen.availWidth;var P=F.screen.availTop}catch(O){}F=[p,B,E,H,w,P,C,A,y,J];E=Ep1(!1,a.j.top);H=new AhY;"SVGElement"in g.S6&&"createElementNS"in g.S6.document&&H.set(0);C=
EdN();C["allow-top-navigation-by-user-activation"]&&H.set(1);C["allow-popups-to-escape-sandbox"]&&H.set(2);g.S6.crypto&&g.S6.crypto.subtle&&H.set(3);"TextDecoder"in g.S6&&"TextEncoder"in g.S6&&H.set(4);H=OvY(H);a=T.call(e,q,{bc:H,bih:E.height,biw:E.width,brdim:F.join(),vis:mF(a.B),wgl:!!Al.WebGLRenderingContext});a.ca_type="image";f&&(a.bid=f);return a};
  g.w_ = function(f,a,e){for(let T in f)a.call(e,f[T],T,f)};
  Uy = function(f){var a=[];g.w_(f,(e,T)=>{var q=g.aw(T);g.bw(Array.isArray(e)?e:[e],F=>{F==""?a.push(q):a.push(`${q}=${g.aw(F)}`)})});
return a.join("&")};
  BbT = function(f,a={}){var e=jl(f),T=g.gp("INNERTUBE_CLIENT_NAME"),q=g.C2("web_ajax_ignore_global_headers_if_set");for(let F in Nbo){let E=g.gp(Nbo[F]),H=F==="X-Goog-AuthUser"||F==="X-Goog-PageId";F!=="X-Goog-Visitor-Id"||E||(E=g.gp("VISITOR_DATA"));!E||!e&&g.xB(f)||q&&a[F]!==void 0||T==="TVHTML5_UNPLUGGED"&&H||(a[F]=E)}"X-Goog-EOM-Visitor-Id"in a&&"X-Goog-Visitor-Id"in a&&delete a["X-Goog-Visitor-Id"];if(e||!g.xB(f))a["X-YouTube-Utc-Offset"]=String(-(new Date).getTimezoneOffset());if(e||!g.xB(f)){let F;
try{F=(new Intl.DateTimeFormat).resolvedOptions().timeZone}catch{}F&&(a["X-YouTube-Time-Zone"]=F)}document.location.hostname.endsWith("youtubeeducation.com")||!e&&g.xB(f)||(a["X-YouTube-Ad-Signals"]=Uy(Pt()));return a};
  yP = function(f,a,e="GET",T="",q,F,E,H=!1,C){var A=xr$();if(!A)return null;var y=()=>{(A&&"readyState"in A?A.readyState:0)===4&&a&&g.uj(a)(A)};
"onloadend"in A?A.addEventListener("loadend",y,!1):A.onreadystatechange=y;g.C2("debug_forward_web_query_parameters")&&(f=px6(f));A.open(e,f,!0);F&&(A.responseType=F);E&&(A.withCredentials=!0);e=e==="POST"&&(window.FormData===void 0||!(T instanceof FormData));if(q=BbT(f,q))for(let J in q)A.setRequestHeader(J,q[J]),"content-type"===J.toLowerCase()&&(e=!1);e&&A.setRequestHeader("Content-Type","application/x-www-form-urlencoded");C&&"onprogress"in A&&(A.onprogress=()=>{C(A.responseText)});
if(H&&"setAttributionReporting"in XMLHttpRequest.prototype){f={eventSourceEligible:!0,triggerEligible:!1};try{A.setAttributionReporting(f)}catch(J){ZH(J)}}A.send(T);return A};
  var nB0 = yP;
  g.Jk = function(f,a){var e=a.format||"JSON";f=Qzg(f,a);var T=oBw(f,a),q=!1,F=nB0(f,H=>{if(!q){q=!0;E&&g.Fh(E);var C=g.sP(H),A=null,y=400<=H.status&&H.status<500,J=500<=H.status&&H.status<600;if(C||y||J)A=W8w(f,e,H,a.convertToSafeHtml);C&&(C=ixw(e,H,A));A=A||{};y=a.context||g.S6;C?a.onSuccess&&a.onSuccess.call(y,H,A):a.onError&&a.onError.call(y,H,A);a.onFinish&&a.onFinish.call(y,H,A)}},a.method,T,a.headers,a.responseType,a.withCredentials,!1,a.onProgress);
T=a.timeout||0;if(a.onTimeout&&T>0){let H=a.onTimeout;var E=g.Ty(()=>{q||(q=!0,F.abort(),g.Fh(E),H.call(a.context||g.S6,F))},T)}return F};
  Gy = function(f,a){a.method="POST";a.postParams||(a.postParams={});return g.Jk(f,a)};
  c10 = function(f){try{return(new Blob(f.split(""))).size}catch(a){return ZH(a),null}};
  g.Nq = function(f){var a=[],e=0;for(let T=0;T<f.length;T++){let q=f.charCodeAt(T);q<128?a[e++]=q:(q<2048?a[e++]=q>>6|192:((q&64512)==55296&&T+1<f.length&&(f.charCodeAt(T+1)&64512)==56320?(q=65536+((q&1023)<<10)+(f.charCodeAt(++T)&1023),a[e++]=q>>18|240,a[e++]=q>>12&63|128):a[e++]=q>>12|224,a[e++]=q>>6&63|128),a[e++]=q&63|128)}return a};
  var oy0 = undefined;
  var zyg = undefined;
  var Lg = {};
  var lNw = function(){this.input=null;this.TM=this.gt=this.N7=0;this.output=null;this.eI=this.RX=this.Tq=0;this.msg="";this.state=null;this.yz=2;this.gy=0};
  Ey = function(f){for(var a=f.length;--a>=0;)f[a]=0};
  oEN = function(){this.A0=null;this.status=0;this.PT=null;this.wrap=this.pending=this.dX=this.xf=0;this.sM=null;this.Pf=0;this.method=8;this.MD=-1;this.gW=this.MF=this.CY=0;this.window=null;this.tY=0;this.head=this.oR=null;this.j_=this.wV=this.strategy=this.level=this.Mx=this.YM=this.v9=this.Su=this.n5=this.Z6=this.XO=this.Qh=this.IX=this.M0=this.k6=this.jv=this.Xi=this.l4=this.yM=0;this.Jc=new Lg.lf(1146);this.Y8=new Lg.lf(122);this.Bb=new Lg.lf(78);Ey(this.Jc);Ey(this.Y8);Ey(this.Bb);this.gH=this.ew=
this.ot=null;this.NO=new Lg.lf(16);this.heap=new Lg.lf(573);Ey(this.heap);this.wI=this.dO=0;this.depth=new Lg.lf(573);Ey(this.depth);this.Yg=this.U9=this.my=this.matches=this.f8=this.J4=this.Xr=this.Hf=this.A6=this.xT=0};
  var qT = {2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"};
  F5 = function(f,a){f.msg=qT[a];return a};
  var z1 = Array(256);
  var kX = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var ju = Array(29);
  var ft = Array(512);
  var ae = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  var el = Array(30);
  var Ct = Array(576);
  EE7 = function(f,a){var e=0;do e|=f&1,f>>>=1,e<<=1;while(--a>0);return e>>>1};
  HzN = function(f,a,e){var T=Array(16),q=0,F;for(F=1;F<=15;F++)T[F]=q=q+e[F-1]<<1;for(e=0;e<=a;e++)q=f[e*2+1],q!==0&&(f[e*2]=EE7(T[q]++,q))};
  var Sl = Array(60);
  uv = function(f,a,e,T,q){this.I4=f;this.xE=a;this.dA=e;this.nU=T;this.Fp=q;this.IN=f&&f.length};
  WJy = undefined;
  izy = undefined;
  var MY1 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7];
  INy = undefined;
  var nEq = !1;
  Zp = function(f,a){this.WI=f;this.gI=0;this.GH=a};
  CqT = function(f){var a;for(a=0;a<286;a++)f.Jc[a*2]=0;for(a=0;a<30;a++)f.Y8[a*2]=0;for(a=0;a<19;a++)f.Bb[a*2]=0;f.Jc[512]=1;f.J4=f.f8=0;f.Hf=f.matches=0};
  var GS = function(f,a,e,T){var q=f&65535|0;f=f>>>16&65535|0;for(var F;e!==0;){F=e>2E3?2E3:e;e-=F;do q=q+a[T++]|0,f=f+q|0;while(--F);q%=65521;f%=65521}return q|f<<16|0};
  Bt = function(f){var a=f.CY,e;do{var T=f.tY-f.Su-f.Z6;if(f.Z6>=a+(a-262)){Lg.un(f.window,f.window,a,a,0);f.n5-=a;f.Z6-=a;f.M0-=a;var q=e=f.l4;do{var F=f.head[--q];f.head[q]=F>=a?F-a:0}while(--e);q=e=a;do F=f.oR[--q],f.oR[q]=F>=a?F-a:0;while(--e);T+=a}if(f.A0.gt===0)break;q=f.A0;e=f.window;F=f.Z6+f.Su;var E=q.gt;E>T&&(E=T);E===0?e=0:(q.gt-=E,Lg.un(e,q.input,q.N7,E,F),q.state.wrap===1?q.gy=GS(q.gy,e,E,F):q.state.wrap===2&&(q.gy=pt(q.gy,e,E,F)),q.N7+=E,q.TM+=E,e=E);f.Su+=e;if(f.Su+f.my>=3)for(T=f.Z6-f.my,
f.yM=f.window[T],f.yM=(f.yM<<f.k6^f.window[T+1])&f.jv;f.my&&!(f.yM=(f.yM<<f.k6^f.window[T+3-1])&f.jv,f.oR[T&f.gW]=f.head[f.yM],f.head[f.yM]=T,T++,f.my--,f.Su+f.my<3););}while(f.Su<262&&f.A0.gt!==0)};
  Ge3 = function(f){var a=4093624447,e;for(e=0;e<=31;e++,a>>>=1)if(a&1&&f.Jc[e*2]!==0)return 0;if(f.Jc[18]!==0||f.Jc[20]!==0||f.Jc[26]!==0)return 1;for(e=32;e<256;e++)if(f.Jc[e*2]!==0)return 1;return 0};
  S2o = function(f,a,e,T){var q=a*2,F=e*2;return f[q]<f[F]||f[q]===f[F]&&T[a]<=T[e]};
  tc = function(f,a,e){for(var T=f.heap[e],q=e<<1;q<=f.dO;){q<f.dO&&S2o(a,f.heap[q+1],f.heap[q],f.depth)&&q++;if(S2o(a,T,f.heap[q],f.depth))break;f.heap[e]=f.heap[q];e=q;q<<=1}f.heap[e]=T};
  sy = function(f,a){var e=a.WI,T=a.GH.I4,q=a.GH.IN,F=a.GH.nU,E,H=-1;f.dO=0;f.wI=573;for(E=0;E<F;E++)e[E*2]!==0?(f.heap[++f.dO]=H=E,f.depth[E]=0):e[E*2+1]=0;for(;f.dO<2;){var C=f.heap[++f.dO]=H<2?++H:0;e[C*2]=1;f.depth[C]=0;f.J4--;q&&(f.f8-=T[C*2+1])}a.gI=H;for(E=f.dO>>1;E>=1;E--)tc(f,e,E);C=F;do E=f.heap[1],f.heap[1]=f.heap[f.dO--],tc(f,e,1),T=f.heap[1],f.heap[--f.wI]=E,f.heap[--f.wI]=T,e[C*2]=e[E*2]+e[T*2],f.depth[C]=(f.depth[E]>=f.depth[T]?f.depth[E]:f.depth[T])+1,e[E*2+1]=e[T*2+1]=C,f.heap[1]=C++,
tc(f,e,1);while(f.dO>=2);f.heap[--f.wI]=f.heap[1];E=a.WI;C=a.gI;T=a.GH.I4;q=a.GH.IN;F=a.GH.xE;var A=a.GH.dA,y=a.GH.Fp,J,p=0;for(J=0;J<=15;J++)f.NO[J]=0;E[f.heap[f.wI]*2+1]=0;for(a=f.wI+1;a<573;a++){var B=f.heap[a];J=E[E[B*2+1]*2+1]+1;J>y&&(J=y,p++);E[B*2+1]=J;if(!(B>C)){f.NO[J]++;var w=0;B>=A&&(w=F[B-A]);var P=E[B*2];f.J4+=P*(J+w);q&&(f.f8+=P*(T[B*2+1]+w))}}if(p!==0){do{for(J=y-1;f.NO[J]===0;)J--;f.NO[J]--;f.NO[J+1]+=2;f.NO[y]--;p-=2}while(p>0);for(J=y;J!==0;J--)for(B=f.NO[J];B!==0;)T=f.heap[--a],
T>C||(E[T*2+1]!==J&&(f.J4+=(J-E[T*2+1])*E[T*2],E[T*2+1]=J),B--)}HzN(e,H,f.NO)};
  yK0 = function(f,a,e){var T,q=-1,F=a[1],E=0,H=7,C=4;F===0&&(H=138,C=3);a[(e+1)*2+1]=65535;for(T=0;T<=e;T++){var A=F;F=a[(T+1)*2+1];++E<H&&A===F||(E<C?f.Bb[A*2]+=E:A!==0?(A!==q&&f.Bb[A*2]++,f.Bb[32]++):E<=10?f.Bb[34]++:f.Bb[36]++,E=0,q=A,F===0?(H=138,C=3):A===F?(H=6,C=3):(H=7,C=4))}};
  var pY7 = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
  $X = function(f,a){f.PT[f.pending++]=a&255;f.PT[f.pending++]=a>>>8&255};
  cQ = function(f,a,e){f.Yg>16-e?(f.U9|=a<<f.Yg&65535,$X(f,f.U9),f.U9=a>>16-f.Yg,f.Yg+=e-16):(f.U9|=a<<f.Yg&65535,f.Yg+=e)};
  mO = function(f,a,e){cQ(f,e[a*2],e[a*2+1])};
  JKY = function(f,a,e){var T,q=-1,F=a[1],E=0,H=7,C=4;F===0&&(H=138,C=3);for(T=0;T<=e;T++){var A=F;F=a[(T+1)*2+1];if(!(++E<H&&A===F)){if(E<C){do mO(f,A,f.Bb);while(--E!==0)}else A!==0?(A!==q&&(mO(f,A,f.Bb),E--),mO(f,16,f.Bb),cQ(f,E-3,2)):E<=10?(mO(f,17,f.Bb),cQ(f,E-3,3)):(mO(f,18,f.Bb),cQ(f,E-11,7));E=0;q=A;F===0?(H=138,C=3):A===F?(H=6,C=3):(H=7,C=4)}}};
  xH1 = function(f,a,e){var T=0;if(f.Hf!==0){do{var q=f.PT[f.Xr+T*2]<<8|f.PT[f.Xr+T*2+1];var F=f.PT[f.xT+T];T++;if(q===0)mO(f,F,a);else{var E=z1[F];mO(f,E+256+1,a);var H=kX[E];H!==0&&(F-=ju[E],cQ(f,F,H));q--;E=q<256?ft[q]:ft[256+(q>>>7)];mO(f,E,e);H=ae[E];H!==0&&(q-=el[E],cQ(f,q,H))}}while(T<f.Hf)}mO(f,256,a)};
  dHY = function(f){f.Yg>8?$X(f,f.U9):f.Yg>0&&(f.PT[f.pending++]=f.U9);f.U9=0;f.Yg=0};
  AKw = function(f,a,e){dHY(f);$X(f,e);$X(f,~e);Lg.un(f.PT,f.window,a,e,f.pending);f.pending+=e};
  Ht = function(f){var a=f.state,e=a.pending;e>f.RX&&(e=f.RX);e!==0&&(Lg.un(f.output,a.PT,a.dX,e,f.Tq),f.Tq+=e,a.dX+=e,f.eI+=e,f.RX-=e,a.pending-=e,a.pending===0&&(a.dX=0))};
  xg = function(f,a){var e=f.M0>=0?f.M0:-1,T=f.Z6-f.M0,q=0;if(f.level>0){f.A0.yz===2&&(f.A0.yz=Ge3(f));sy(f,f.ot);sy(f,f.ew);yK0(f,f.Jc,f.ot.gI);yK0(f,f.Y8,f.ew.gI);sy(f,f.gH);for(q=18;q>=3&&f.Bb[pY7[q]*2+1]===0;q--);f.J4+=3*(q+1)+5+5+4;var F=f.J4+3+7>>>3;var E=f.f8+3+7>>>3;E<=F&&(F=E)}else F=E=T+5;if(T+4<=F&&e!==-1)cQ(f,a?1:0,3),AKw(f,e,T);else if(f.strategy===4||E===F)cQ(f,2+(a?1:0),3),xH1(f,Ct,Sl);else{cQ(f,4+(a?1:0),3);e=f.ot.gI+1;T=f.ew.gI+1;q+=1;cQ(f,e-257,5);cQ(f,T-1,5);cQ(f,q-4,4);for(F=0;F<q;F++)cQ(f,
f.Bb[pY7[F]*2+1],3);JKY(f,f.Jc,e-1);JKY(f,f.Y8,T-1);xH1(f,f.Jc,f.Y8)}CqT(f);a&&dHY(f);f.M0=f.Z6;Ht(f.A0)};
  oe = function(f,a,e,T,q){this.Nw=f;this.vE=a;this.qB=e;this.PE=T;this.func=q};
  BSg = function(f,a){var e=f.YM,T=f.Z6,q=f.v9,F=f.j_,E=f.Z6>f.CY-262?f.Z6-(f.CY-262):0,H=f.window,C=f.gW,A=f.oR,y=f.Z6+258,J=H[T+q-1],p=H[T+q];f.v9>=f.wV&&(e>>=2);F>f.Su&&(F=f.Su);do{var B=a;if(H[B+q]===p&&H[B+q-1]===J&&H[B]===H[T]&&H[++B]===H[T+1]){T+=2;for(B++;H[++T]===H[++B]&&H[++T]===H[++B]&&H[++T]===H[++B]&&H[++T]===H[++B]&&H[++T]===H[++B]&&H[++T]===H[++B]&&H[++T]===H[++B]&&H[++T]===H[++B]&&T<y;);B=258-(y-T);T=y-258;if(B>q){f.n5=a;q=B;if(B>=F)break;J=H[T+q-1];p=H[T+q]}}}while((a=A[a&C])>E&&--e!==
0);return q<=f.Su?q:f.Su};
  TS = function(f,a,e){f.PT[f.Xr+f.Hf*2]=a>>>8&255;f.PT[f.Xr+f.Hf*2+1]=a&255;f.PT[f.xT+f.Hf]=e&255;f.Hf++;a===0?f.Jc[e*2]++:(f.matches++,a--,f.Jc[(z1[e]+256+1)*2]++,f.Y8[(a<256?ft[a]:ft[256+(a>>>7)])*2]++);return f.Hf===f.A6-1};
  NT = function(f,a){for(var e;;){if(f.Su<262){Bt(f);if(f.Su<262&&a===0)return 1;if(f.Su===0)break}e=0;f.Su>=3&&(f.yM=(f.yM<<f.k6^f.window[f.Z6+3-1])&f.jv,e=f.oR[f.Z6&f.gW]=f.head[f.yM],f.head[f.yM]=f.Z6);e!==0&&f.Z6-e<=f.CY-262&&(f.IX=BSg(f,e));if(f.IX>=3)if(e=TS(f,f.Z6-f.n5,f.IX-3),f.Su-=f.IX,f.IX<=f.Mx&&f.Su>=3){f.IX--;do f.Z6++,f.yM=(f.yM<<f.k6^f.window[f.Z6+3-1])&f.jv,f.oR[f.Z6&f.gW]=f.head[f.yM],f.head[f.yM]=f.Z6;while(--f.IX!==0);f.Z6++}else f.Z6+=f.IX,f.IX=0,f.yM=f.window[f.Z6],f.yM=(f.yM<<f.k6^
f.window[f.Z6+1])&f.jv;else e=TS(f,0,f.window[f.Z6]),f.Su--,f.Z6++;if(e&&(xg(f,!1),f.A0.RX===0))return 1}f.my=f.Z6<2?f.Z6:2;return a===4?(xg(f,!0),f.A0.RX===0?3:4):f.Hf&&(xg(f,!1),f.A0.RX===0)?1:2};
  QM = function(f,a){for(var e,T;;){if(f.Su<262){Bt(f);if(f.Su<262&&a===0)return 1;if(f.Su===0)break}e=0;f.Su>=3&&(f.yM=(f.yM<<f.k6^f.window[f.Z6+3-1])&f.jv,e=f.oR[f.Z6&f.gW]=f.head[f.yM],f.head[f.yM]=f.Z6);f.v9=f.IX;f.Qh=f.n5;f.IX=2;e!==0&&f.v9<f.Mx&&f.Z6-e<=f.CY-262&&(f.IX=BSg(f,e),f.IX<=5&&(f.strategy===1||f.IX===3&&f.Z6-f.n5>4096)&&(f.IX=2));if(f.v9>=3&&f.IX<=f.v9){T=f.Z6+f.Su-3;e=TS(f,f.Z6-1-f.Qh,f.v9-3);f.Su-=f.v9-1;f.v9-=2;do++f.Z6<=T&&(f.yM=(f.yM<<f.k6^f.window[f.Z6+3-1])&f.jv,f.oR[f.Z6&f.gW]=
f.head[f.yM],f.head[f.yM]=f.Z6);while(--f.v9!==0);f.XO=0;f.IX=2;f.Z6++;if(e&&(xg(f,!1),f.A0.RX===0))return 1}else if(f.XO){if((e=TS(f,0,f.window[f.Z6-1]))&&xg(f,!1),f.Z6++,f.Su--,f.A0.RX===0)return 1}else f.XO=1,f.Z6++,f.Su--}f.XO&&(TS(f,0,f.window[f.Z6-1]),f.XO=0);f.my=f.Z6<2?f.Z6:2;return a===4?(xg(f,!0),f.A0.RX===0?3:4):f.Hf&&(xg(f,!1),f.A0.RX===0)?1:2};
  wp = [];
  var KJw = {};
  FJq = function(f){var a,e,T=f.length,q=0;for(a=0;a<T;a++){var F=f.charCodeAt(a);if((F&64512)===55296&&a+1<T){var E=f.charCodeAt(a+1);(E&64512)===56320&&(F=65536+(F-55296<<10)+(E-56320),a++)}q+=F<128?1:F<2048?2:F<65536?3:4}var H=new Lg.a5(q);for(a=e=0;e<q;a++)F=f.charCodeAt(a),(F&64512)===55296&&a+1<T&&(E=f.charCodeAt(a+1),(E&64512)===56320&&(F=65536+(F-55296<<10)+(E-56320),a++)),F<128?H[e++]=F:(F<2048?H[e++]=192|F>>>6:(F<65536?H[e++]=224|F>>>12:(H[e++]=240|F>>>18,H[e++]=128|F>>>12&63),H[e++]=128|F>>>
6&63),H[e++]=128|F&63);return H};
  lj = function(f){if(!(this instanceof lj))return new lj(f);f=this.options=Lg.assign({level:-1,method:8,chunkSize:16384,U6:15,iY:8,strategy:0,to:""},f||{});f.raw&&f.U6>0?f.U6=-f.U6:f.gA&&f.U6>0&&f.U6<16&&(f.U6+=16);this.err=0;this.msg="";this.ended=!1;this.chunks=[];this.A0=new lNw;this.A0.RX=0;var a=this.A0;var e=f.level,T=f.method,q=f.U6,F=f.iY,E=f.strategy;if(a){var H=1;e===-1&&(e=6);q<0?(H=0,q=-q):q>15&&(H=2,q-=16);if(F<1||F>9||T!==8||q<8||q>15||e<0||e>9||E<0||E>4)a=F5(a,-2);else{q===8&&(q=9);var C=
new oEN;a.state=C;C.A0=a;C.wrap=H;C.sM=null;C.MF=q;C.CY=1<<C.MF;C.gW=C.CY-1;C.Xi=F+7;C.l4=1<<C.Xi;C.jv=C.l4-1;C.k6=~~((C.Xi+3-1)/3);C.window=new Lg.a5(C.CY*2);C.head=new Lg.lf(C.l4);C.oR=new Lg.lf(C.CY);C.A6=1<<F+6;C.xf=C.A6*4;C.PT=new Lg.a5(C.xf);C.Xr=1*C.A6;C.xT=3*C.A6;C.level=e;C.strategy=E;C.method=T;if(a&&a.state){a.TM=a.eI=0;a.yz=2;e=a.state;e.pending=0;e.dX=0;e.wrap<0&&(e.wrap=-e.wrap);e.status=e.wrap?42:113;a.gy=e.wrap===2?0:1;e.MD=0;if(!nEq){T=Array(16);for(F=E=0;F<28;F++)for(ju[F]=E,q=0;q<
1<<kX[F];q++)z1[E++]=F;z1[E-1]=F;for(F=E=0;F<16;F++)for(el[F]=E,q=0;q<1<<ae[F];q++)ft[E++]=F;for(E>>=7;F<30;F++)for(el[F]=E<<7,q=0;q<1<<ae[F]-7;q++)ft[256+E++]=F;for(q=0;q<=15;q++)T[q]=0;for(q=0;q<=143;)Ct[q*2+1]=8,q++,T[8]++;for(;q<=255;)Ct[q*2+1]=9,q++,T[9]++;for(;q<=279;)Ct[q*2+1]=7,q++,T[7]++;for(;q<=287;)Ct[q*2+1]=8,q++,T[8]++;HzN(Ct,287,T);for(q=0;q<30;q++)Sl[q*2+1]=5,Sl[q*2]=EE7(q,5);WJy=new uv(Ct,kX,257,286,15);izy=new uv(Sl,ae,0,30,15);INy=new uv([],MY1,0,19,7);nEq=!0}e.ot=new Zp(e.Jc,WJy);
e.ew=new Zp(e.Y8,izy);e.gH=new Zp(e.Bb,INy);e.U9=0;e.Yg=0;CqT(e);e=0}else e=F5(a,-2);e===0&&(a=a.state,a.tY=2*a.CY,Ey(a.head),a.Mx=wp[a.level].vE,a.wV=wp[a.level].Nw,a.j_=wp[a.level].qB,a.YM=wp[a.level].PE,a.Z6=0,a.M0=0,a.Su=0,a.my=0,a.IX=a.v9=2,a.XO=0,a.yM=0);a=e}}else a=-2;if(a!==0)throw Error(qT[a]);f.header&&(a=this.A0)&&a.state&&a.state.wrap===2&&(a.state.sM=f.header);if(f.YU){var A;typeof f.YU==="string"?A=FJq(f.YU):KJw.call(f.YU)==="[object ArrayBuffer]"?A=new Uint8Array(f.YU):A=f.YU;f=this.A0;
F=A;E=F.length;if(f&&f.state)if(A=f.state,a=A.wrap,a===2||a===1&&A.status!==42||A.Su)a=-2;else{a===1&&(f.gy=GS(f.gy,F,E,0));A.wrap=0;E>=A.CY&&(a===0&&(Ey(A.head),A.Z6=0,A.M0=0,A.my=0),e=new Lg.a5(A.CY),Lg.un(e,F,E-A.CY,A.CY,0),F=e,E=A.CY);e=f.gt;T=f.N7;q=f.input;f.gt=E;f.N7=0;f.input=F;for(Bt(A);A.Su>=3;){F=A.Z6;E=A.Su-2;do A.yM=(A.yM<<A.k6^A.window[F+3-1])&A.jv,A.oR[F&A.gW]=A.head[A.yM],A.head[A.yM]=F,F++;while(--E);A.Z6=F;A.Su=2;Bt(A)}A.Z6+=A.Su;A.M0=A.Z6;A.my=A.Su;A.Su=0;A.IX=A.v9=2;A.XO=0;f.N7=
T;f.input=q;f.gt=e;A.wrap=a;a=0}else a=-2;if(a!==0)throw Error(qT[a]);this.cmT=!0}};
  UH1 = function(f){var a=a||{};a.gA=!0;a=new lj(a);a.push(f,!0);if(a.err)throw a.msg||qT[a.err];return a.result};
  var kuw = 0;
  h2 = function(){return g.yY("ytPubsub2Pubsub2Instance")};
  uG = function(f,a){var e=h2();e&&e.publish.call(e,f.toString(),f,a)};
  c8 = function(f,a,e={sampleRate:.1}){Math.random()<Math.min(.02,e.sampleRate/100)&&uG("meta_logging_csi_event",{timerName:f,timelineData:a})};
  var t8T = undefined;
  var mP3 = undefined;
  mr = function(f,a,e,T){var q={startTime:(0,g.u)(),ticks:{},infos:{}};try{let E=c10(a);if(E==null||!(E>mP3||E<t8T)){var F=UH1(zyg(a));let H=(0,g.u)();q.ticks.gelc=H;kuw++;g.C2("gel_compression_csi_killswitch")||!g.C2("log_gel_compression_latency")&&!g.C2("log_gel_compression_latency_lr")||c8("gel_compression",q,{sampleRate:.1});e.headers||(e.headers={});e.headers["Content-Encoding"]="gzip";e.postBody=F;e.postParams=void 0}T(f,e)}catch(E){ZH(E),T(f,e)}};
  kS = function(f,a){return f.K?f.K:f.K=new Promise(async e=>{var T=window.AbortController?new window.AbortController:void 0,q=T?.signal,F=!1;try{T&&(f.j=f.z4.jK(()=>{T.abort()},a||2E4)),await fetch("/generate_204",{method:"HEAD",
signal:q}),F=!0}catch{F=!1}finally{f.K=void 0,f.j&&(f.z4.Mg(f.j),f.j=0),F!==f.isOnline&&(f.isOnline=F,f.isOnline?f.dispatchEvent("networkstatus-online"):f.dispatchEvent("networkstatus-offline")),e(F)}})};
  RH = function(f){this.src=f;this.listeners={};this.j=0};
  g.U = RH.prototype;
  XP = function(f,a,e,T){for(let q=0;q<f.length;++q){let F=f[q];if(!F.removed&&F.listener==a&&F.capture==!!e&&F.handler==T)return q}return-1};
  var rLq = 0;
  vu1 = function(f,a,e,T,q){this.listener=f;this.proxy=null;this.src=a;this.type=e;this.capture=!!T;this.handler=q;this.key=++rLq;this.removed=this.JD=!1};
  g.U.add = function(f,a,e,T,q){var F=f.toString();f=this.listeners[F];f||(f=this.listeners[F]=[],this.j++);var E=XP(f,a,T,q);E>-1?(a=f[E],e||(a.JD=!1)):(a=new vu1(a,this.src,F,!!T,q),a.JD=e,f.push(a));return a};
  Op = function(f){f.removed=!0;f.listener=null;f.proxy=null;f.src=null;f.handler=null};
  g.U.remove = function(f,a,e,T){f=f.toString();if(!(f in this.listeners))return!1;var q=this.listeners[f];a=XP(q,a,e,T);return a>-1?(Op(q[a]),g.sI(q,a),q.length==0&&(delete this.listeners[f],this.j--),!0):!1};
  g.U.removeAll = function(f){f=f&&f.toString();var a=0;for(let e in this.listeners)if(!f||e==f){let T=this.listeners[e];for(let q=0;q<T.length;q++)++a,Op(T[q]);delete this.listeners[e];this.j--}return a};
  g.U.Sh = function(f,a,e,T){f=this.listeners[f.toString()];var q=-1;f&&(q=XP(f,a,e,T));return q>-1?f[q]:null};
  g.i0 = function(f,a,e){for(let T in f)if(a.call(e,f[T],T,f))return!0;return!1};
  g.U.hasListener = function(f,a){var e=f!==void 0,T=e?f.toString():"",q=a!==void 0;return g.i0(this.listeners,function(F){for(let E=0;E<F.length;++E)if(!(e&&F[E].type!=T||q&&F[E].capture!=a))return!0;return!1})};
  g.mt = function(){g.th.call(this);this.Ys=new RH(this);this.uk=this;this.n4=null};
  g.U = g.mt.prototype;
  var cj = undefined;
  LI = function(f){if(typeof f==="function")return f;f[cj]||(f[cj]=function(a){return f.handleEvent(a)});
return f[cj]};
  var un = undefined;
  h1 = function(f){f=f[un];return f instanceof RH?f:null};
  g.vj = function(f,a){this.type=f;this.currentTarget=this.target=a;this.defaultPrevented=this.B=!1};
  Dd = function(f,a){g.vj.call(this,f?f.type:"");this.relatedTarget=this.currentTarget=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.key="";this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.j=null;f&&this.init(f,a)};
  var $o = {};
  OUT = function(f){return f in $o?$o[f]:$o[f]="on"+f};
  var R46 = 0;
  g.Yo = function(f,a){var e=a.type;e in f.listeners&&g.T4(f.listeners[e],a)&&(Op(a),f.listeners[e].length==0&&(delete f.listeners[e],f.j--))};
  var Pty = undefined;
  Vw = function(f){return!(!f||!f[Pty])};
  Zd = function(f){if(typeof f!=="number"&&f&&!f.removed){var a=f.src;if(Vw(a))g.Yo(a.Ys,f);else{var e=f.type,T=f.proxy;a.removeEventListener?a.removeEventListener(e,T,f.capture):a.detachEvent?a.detachEvent(OUT(e),T):a.addListener&&a.removeListener&&a.removeListener(T);R46--;(e=h1(a))?(g.Yo(e,f),e.j==0&&(e.src=null,a[un]=null)):Op(f)}}};
  Y83 = function(f,a){if(f.removed)f=!0;else{a=new Dd(a,this);let e=f.listener,T=f.handler||f.src;f.JD&&Zd(f);f=e.call(T,a)}return f};
  VX3 = function(){function f(e){return a.call(f.src,f.listener,e)}
var a=Y83;return f};
  Dq0 = function(f,a,e,T,q,F){if(!a)throw Error("Invalid event type");var E=g.QY(q)?!!q.capture:!!q,H=h1(f);H||(f[un]=H=new RH(f));e=H.add(a,e,T,E,F);if(e.proxy)return e;T=VX3();e.proxy=T;T.src=f;T.listener=e;if(f.addEventListener)q===void 0&&(q=!1),f.addEventListener(a.toString(),T,q);else if(f.attachEvent)f.attachEvent(OUT(a.toString()),T);else if(f.addListener&&f.removeListener)f.addListener(T);else throw Error("addEventListener and attachEvent are unavailable.");R46++;return e};
  gq = function(f,a,e,T,q){if(Array.isArray(a)){for(let F=0;F<a.length;F++)gq(f,a[F],e,T,q);return null}e=LI(e);return Vw(f)?f.dc(a,e,g.QY(T)?!!T.capture:!!T,q):Dq0(f,a,e,!0,T,q)};
  g.bn = function(f,a,e,T,q){if(T&&T.once)return gq(f,a,e,T,q);if(Array.isArray(a)){for(let F=0;F<a.length;F++)g.bn(f,a[F],e,T,q);return null}e=LI(e);return Vw(f)?f.listen(a,e,g.QY(T)?!!T.capture:!!T,q):Dq0(f,a,e,!1,T,q)};
  g.U.addEventListener = function(f,a,e,T){g.bn(this,f,a,e,T)};
  XVg = function(f,a,e,T,q){if(Array.isArray(a))for(let F=0;F<a.length;F++)XVg(f,a[F],e,T,q);else T=g.QY(T)?!!T.capture:!!T,e=LI(e),Vw(f)?f.NU(a,e,T,q):f&&(f=h1(f))&&(a=f.Sh(a,e,T,q))&&Zd(a)};
  g.U.removeEventListener = function(f,a,e,T){XVg(this,f,a,e,T)};
  t1 = function(f,a,e,T){a=f.Ys.listeners[String(a)];if(!a)return!0;a=a.concat();var q=!0;for(let F=0;F<a.length;++F){let E=a[F];if(E&&!E.removed&&E.capture==e){let H=E.listener,C=E.handler||E.src;E.JD&&g.Yo(f.Ys,E);q=H.call(C,T)!==!1&&q}}return q&&!T.defaultPrevented};
  g.U.dispatchEvent = function(f){var a=this.n4;if(a){var e=[];for(var T=1;a;a=a.n4)e.push(a),++T}a=this.uk;T=f.type||f;if(typeof f==="string")f=new g.vj(f,a);else if(f instanceof g.vj)f.target=f.target||a;else{var q=f;f=new g.vj(T,a);g.u0(f,q)}q=!0;var F;if(e)for(F=e.length-1;!f.B&&F>=0;F--){var E=f.currentTarget=e[F];q=t1(E,T,!0,f)&&q}f.B||(E=f.currentTarget=a,q=t1(E,T,!0,f)&&q,f.B||(q=t1(E,T,!1,f)&&q));if(e)for(F=0;!f.B&&F<e.length;F++)E=f.currentTarget=e[F],q=t1(E,T,!1,f)&&q;return q};
  g.U.Bi = function(){g.mt.lF.Bi.call(this);this.Ys&&this.Ys.removeAll(void 0);this.n4=null};
  g.U.listen = function(f,a,e,T){return this.Ys.add(String(f),a,!1,e,T)};
  g.U.dc = function(f,a,e,T){return this.Ys.add(String(f),a,!0,e,T)};
  g.U.NU = function(f,a,e,T){this.Ys.remove(String(f),a,e,T)};
  g.U.Sh = function(f,a,e,T){return this.Ys.Sh(String(f),a,e,T)};
  g.U.hasListener = function(f,a){return this.Ys.hasListener(f!==void 0?String(f):void 0,a)};
  var zj = class extends g.mt{constructor(f){super();this.A=this.j=0;this.z4=f??{jK:(a,e)=>setTimeout(a,e),
Mg:a=>{clearTimeout(a)}};
this.isOnline=window.navigator?.onLine??!0;this.B=async()=>{await kS(this)};
window.addEventListener("offline",this.B);window.addEventListener("online",this.B);this.A||this.s0()}dispose(){window.removeEventListener("offline",this.B);window.removeEventListener("online",this.B);this.z4.Mg(this.A);delete zj.instance}Xh(){return this.isOnline}s0(){this.A=this.z4.jK(async()=>{this.isOnline?window.navigator?.onLine||await kS(this):await kS(this);this.s0()},3E4)}};
  VUy = function(){var f=g.tQ;zj.instance||(zj.instance=new zj(f));return zj.instance};
  eG = undefined;
  qv = function(){eG||(eG=new TJ("yt.offline"));return eG};
  var Es = class extends g.mt{constructor(){super();this.B=!1;this.j=VUy();this.j.listen("networkstatus-online",()=>{if(this.B&&g.C2("offline_error_handling")){var f=qv().get("errors",!0);if(f){for(let a in f)if(f[a]){let e=new g.vc(a,"sent via offline_errors");e.name=f[a].name;e.stack=f[a].stack;e.level=f[a].level;g.hC(e)}qv().set("errors",{},2592E3,!0)}}})}Xh(){return this.j.Xh()}cG(f){this.j.isOnline=f}nR(){var f=window.navigator.onLine;
return f===void 0?!0:f}LU(){this.B=!0}listen(f,a){return this.j.listen(f,a)}Qa(f){return kS(this.j,f)}};
  WCg = function(){if(!Es.instance){let f=g.yY("yt.networkStatusManager.instance")||new Es;g.x3("yt.networkStatusManager.instance",f);Es.instance=f}return Es.instance};
  iPy = function(f,a){f.rateLimit?f.j?(g.tQ.Mg(f.A),f.A=g.tQ.jK(()=>{f.K!==a&&(f.dispatchEvent(a),f.K=a,f.j=(0,g.u)())},f.rateLimit-((0,g.u)()-f.j))):(f.dispatchEvent(a),f.K=a,f.j=(0,g.u)()):f.dispatchEvent(a)};
  var FY = class{constructor(){this.j=new Map;this.B=!1}requestComplete(f,a){a&&(this.B=!0);f=this.removeParams(f);this.j.get(f)||this.j.set(f,a)}isEndpointCFR(f){f=this.removeParams(f);return(f=this.j.get(f))?!1:f===!1&&this.B?!0:null}removeParams(f){return f.split("?")[0]}};
  nZT = function(){if(!FY.instance){let f=g.yY("yt.networkRequestMonitor.instance")||new FY;g.x3("yt.networkRequestMonitor.instance",f);FY.instance=f}return FY.instance};
  g.y2 = class extends g.mt{constructor(f={}){super();this.j=this.A=0;this.B=WCg();var a=g.yY("yt.networkStatusManager.instance.listen").bind(this.B);a&&(f.rateLimit?(this.rateLimit=f.rateLimit,a("networkstatus-online",()=>{iPy(this,"publicytnetworkstatus-online")}),a("networkstatus-offline",()=>{iPy(this,"publicytnetworkstatus-offline")})):(a("networkstatus-online",()=>{this.dispatchEvent("publicytnetworkstatus-online")}),a("networkstatus-offline",()=>{this.dispatchEvent("publicytnetworkstatus-offline")})))}Xh(){var f=
g.yY("yt.networkStatusManager.instance.isNetworkAvailable");
return f?f.bind(this.B)():!0}cG(f){var a=g.yY("yt.networkStatusManager.instance.networkStatusHint").bind(this.B);a&&a(f)}async Qa(f){var a=g.yY("yt.networkStatusManager.instance.sendNetworkCheckRequest").bind(this.B);return g.C2("skip_network_check_if_cfr")&&nZT().isEndpointCFR("generate_204")?new Promise(e=>{this.cG(window.navigator?.onLine||!0);e(this.Xh())}):a?a(f):!0}};
  JZ = undefined;
  kH = undefined;
  A2 = function(f,a){f.j.objectStoreNames.contains(a)&&f.j.deleteObjectStore(a)};
  Tug = function(){if(kH)return kH();kH=I$("LogsDatabaseV2",{CA:{LogsRequestsStore:{Mj:2}},shared:!1,upgrade(f,a,e){a(2)&&df(f,"LogsRequestsStore",{keyPath:"id",autoIncrement:!0});a(3);a(5)&&(e=e.objectStore("LogsRequestsStore"),e.j.indexNames.contains("newRequest")&&e.j.deleteIndex("newRequest"),SB(e,"newRequestV2",["status","interface","timestamp"]));a(7)&&A2(f,"sapisid");a(9)&&A2(f,"SWHealthLog")},version:9});return kH()};
  jB = function(f){return g.B8(Tug(),f)};
  Ax6 = async function(f){f=await jB(f);var a=(0,g.u)()-2592E6;await g.CW(f,["LogsRequestsStore"],{mode:"readwrite",oV:!0},e=>g.yS(e.objectStore("LogsRequestsStore"),{},T=>{if(T.getValue().timestamp<=a)return T.delete().then(()=>g.J2(T))}))};
  dby = async function(f,a){return(await jB(a)).delete("LogsRequestsStore",f)};
  qa6 = function(f){g.C2("nwl_csi_killswitch")||c8("networkless_performance",f,{sampleRate:1})};
  EZY = async function(f,a){var e={startTime:(0,g.u)(),infos:{transactionType:"YT_IDB_TRANSACTION_TYPE_READ"},ticks:{}};a=await jB(a);var T=g.gp("INNERTUBE_CONTEXT_CLIENT_NAME",0),q=[f,T,0];T=[f,T,(0,g.u)()];var F=IDBKeyRange.bound(q,T),E="prev";g.C2("use_fifo_for_networkless")&&(E="next");var H=void 0;q=f==="NEW"?"readwrite":"readonly";g.C2("use_readonly_for_get_most_recent_by_status_killswitch")&&(q="readwrite");await g.CW(a,["LogsRequestsStore"],{mode:q,oV:!0},C=>g.Gh(C.objectStore("LogsRequestsStore").index("newRequestV2"),
{query:F,direction:E},A=>{A.getValue()&&(H=A.getValue(),f==="NEW"&&(H.status="QUEUED",A.update(H)))}));
e.ticks.tc=(0,g.u)();qa6(e);return H};
  HPo = async function(f,a){return g.CW(await jB(a),["LogsRequestsStore"],{mode:"readwrite",oV:!0},e=>{var T=e.objectStore("LogsRequestsStore");return T.get(f).then(q=>{if(q)return q.status="QUEUED",T.put(q).then(()=>q)})})};
  C17 = async function(f,a,e=!0,T){return g.CW(await jB(a),["LogsRequestsStore"],{mode:"readwrite",oV:!0},q=>{var F=q.objectStore("LogsRequestsStore");return F.get(f).then(E=>E?(E.status="NEW",e&&(E.sendCount+=1),T!==void 0&&(E.options.compress=T),F.put(E).then(()=>E)):g.so.resolve(void 0))})};
  FC6 = async function(f,a){var e={startTime:(0,g.u)(),infos:{transactionType:"YT_IDB_TRANSACTION_TYPE_WRITE"},ticks:{}};a=await jB(a);f={...f,options:JSON.parse(JSON.stringify(f.options)),interface:g.gp("INNERTUBE_CONTEXT_CLIENT_NAME",0)};f=await a.put("LogsRequestsStore",f);e.ticks.tc=(0,g.u)();qa6(e);return f};
  var oZT = 0;
  var ak = {};
  Nu0 = function(f,a,e={}){var T=new Image,q=`${oZT++}`;ak[q]=T;T.onload=T.onerror=()=>{a&&ak[q]&&a();delete ak[q]};
e.scrubReferrer&&(T.referrerPolicy="no-referrer");T.src=f};
  var p_w = class{constructor({url:f,d0T:a}){this.B=f;this.A=a;this.K=(new Date).getTime()-17040672E5;this.j={};for(var e=/[?&]([^&=]+)=([^&]*)/g;a=e.exec(f);)this.j[a[1]]=a[2]}};
  dq = function(f,a){return a?"&"+f+"="+encodeURIComponent(a):""};
  Dg0 = function(f){f=f.A;if(!f)return"";var a=dq("uap",f.platform)+dq("uapv",f.platformVersion)+dq("uafv",f.uaFullVersion)+dq("uaa",f.architecture)+dq("uam",f.model)+dq("uab",f.bitness);f.fullVersionList&&(a+="&uafvl="+encodeURIComponent(f.fullVersionList.map(e=>encodeURIComponent(e.brand)+";"+encodeURIComponent(e.version)).join("|")));
f.wow64!=null&&(a+="&uaw="+Number(f.wow64));return a.slice(1)};
  CI = function(f,...a){a=a.filter(Boolean).join("&");if(!a)return f;var e=f.match(/[?&]adurl=/);return e?f.slice(0,e.index+1)+a+"&"+f.slice(e.index+1):f+(f.indexOf("?")<0?"?":"&")+a};
  var lo = /#|$/;
  wb = function(f,a,e,T){for(var q=e.length;(a=f.indexOf(e,a))>=0&&a<T;){var F=f.charCodeAt(a-1);if(F==38||F==63)if(F=f.charCodeAt(a+q),!F||F==61||F==38||F==35)return a;a+=q+1}return-1};
  nx = function(f,a){var e=f.search(lo),T=wb(f,0,a,e);if(T<0)return null;var q=f.indexOf("&",T);if(q<0||q>e)q=e;T+=a.length+1;return ec(f.slice(T,q!==-1?q:0))};
  BuY = function(f,a=""){try{if(window.navigator&&window.navigator.sendBeacon&&window.navigator.sendBeacon(f,a))return!0}catch(e){}return!1};
  g.D7 = function(f){var a=g.sg();return a?a.toLowerCase().indexOf(f)>=0:!1};
  g.OP = function(){return g.D7("cobalt")};
  g.fK = function(f,a,e,T,q="",F=!1,E=!1){if(f)if(!e||g.OP()||g.C2("web_ping_disable_scrub_referrer"))if(q)yP(f,a,"POST",q,T);else if(g.gp("USE_NET_AJAX_FOR_PING_TRANSPORT",!1)||T||E)yP(f,a,"GET","",T,void 0,F,E);else{b:{try{c:{var H=new p_w({url:f});if(H.j.dsh==="1")var C=null;else{var A=H.j.ae;if(A==="1"){let J=H.j.adurl;if(J)try{C={version:3,tC:decodeURIComponent(J),YW:CI(H.B,"act=1","ri=1",Dg0(H))};break c}catch(p){}}C=A==="2"?{version:4,tC:CI(H.B,"dct=1","suid="+H.K,"ri=1"),YW:CI(H.B,"act=1","ri=1",
"suid="+H.K)}:null}}if(C){let J=yU(f);var y=!(!J||!J.endsWith("/aclk")||nx(f,"ri")!=="1");break b}}catch(J){}y=!1}y?BuY(f)?(a&&a(),e=!0):e=!1:e=!1;e||Nu0(f,a)}else ZH(new g.vc("Legacy referrer-scrubbed ping detected")),f&&Nu0(f,void 0,{scrubReferrer:!0})};
  KCg = function(f,a,e){a=g.C2("web_fp_via_jspb")?Object.assign({},a):a;g.C2("use_request_time_ms_header")?a.headers&&jl(f)&&(a.headers["X-Goog-Request-Time"]=JSON.stringify(Math.round((0,g.u)()))):a.postParams?.requestTimeMs&&(a.postParams.requestTimeMs=Math.round((0,g.u)()));e&&Object.keys(a).length===0?g.fK(f):a.compress?a.postBody?(typeof a.postBody!=="string"&&(a.postBody=JSON.stringify(a.postBody)),mr(f,a.postBody,a,g.Jk)):mr(f,JSON.stringify(a.postParams),a,Gy):g.Jk(f,a)};
  lto = function(f){if(g.C2("offline_error_handling")){var a=qv().get("errors",!0)||{};a[f.message]={name:f.name,stack:f.stack};f.level&&(a[f.message].level=f.level);qv().set("errors",a,2592E3,!0)}};
  g.sA = class{constructor(){this.promise=new Promise((f,a)=>{this.resolve=f;this.reject=a})}};
  zzN = async function(f,a){var e=[];a=await g.B8(NZ,a);await g.CW(a,["databases"],{oV:!0,mode:"readonly"},T=>{e.length=0;return g.yS(T.objectStore("databases"),{},q=>{f(q.getValue())&&e.push(q.getValue());return g.J2(q)})});
return e};
  kCw = function(f,a){return zzN(e=>e.publicName===f&&e.userIdentifier!==void 0,a)};
  HIy = function(f,a,e){f=f.map(async T=>{await pW(T.actualName,a);await QS(T.actualName,e)});
return Promise.all(f).then(()=>{})};
  Cn6 = async function(f){var a={},e=await g.iG();e&&(tA(f),f=await kCw(f,e),await HIy(f,a,e))};
  Sa1 = async function(){await Cn6("LogsDatabaseV2")};
  CK = function(f,a){g.C2("use_event_time_ms_header")&&jl(f)&&(a.headers||(a.headers={}),a.headers["X-Goog-Event-Time"]=JSON.stringify(Math.round((0,g.u)())));return a};
  t2 = function(f){return!!f.Sp||f.L3};
  ft7 = function(f){t2(f)&&!f.CP&&(f.j=!0,f.mX&&Math.random()<=f.aJ&&f.M8.fF(f.Sp),f.s3(),f.Lk.Xh()&&f.K(),f.Lk.listen(f.ZH,f.K.bind(f)),f.Lk.listen(f.P2,f.A.bind(f)))};
  zh = function(f,a){f.MC&&!f.Lk.Xh()?f.MC(a):f.handleError(a)};
  at$ = function(f){return(f=f?.error?.code)&&f>=400&&f<=599?!1:!0};
  ebw = function(f){f=f?.error?.code;return!(f!==400&&f!==415)};
  s56 = function(f,a){if(!t2(f))throw Error("IndexedDB is not supported: updateRequestHandlers");var e=a.options.onError?a.options.onError:()=>{};
a.options.onError=async(q,F)=>{var E=at$(F),H=ebw(F);H&&f.JU&&f.JU("web_enable_error_204")&&f.handleError(Error("Request failed due to compression"),a.url,F);if(f.JU&&f.JU("nwl_consider_error_code")&&E||f.JU&&!f.JU("nwl_consider_error_code")&&f.potentialEsfErrorCounter<=f.S4)if(f.Lk.Qa&&await f.Lk.Qa(),!f.Lk.Xh()){e(q,F);f.JU&&f.JU("nwl_consider_error_code")&&a?.id!==void 0&&await f.M8.yk(a.id,f.Sp,!1);return}f.JU&&f.JU("nwl_consider_error_code")&&!E&&f.potentialEsfErrorCounter>f.S4||(f.potentialEsfErrorCounter++,
a?.id!==void 0&&(a.sendCount<f.dE?(await f.M8.yk(a.id,f.Sp,!0,H?!1:void 0),f.z4.jK(()=>{f.Lk.Xh()&&f.K()},f.kG)):await f.M8.LZ(a.id,f.Sp)),e(q,F))};
var T=a.options.onSuccess?a.options.onSuccess:()=>{};
a.options.onSuccess=async(q,F)=>{a?.id!==void 0&&await f.M8.LZ(a.id,f.Sp);f.Lk.cG&&f.JU&&f.JU("vss_network_hint")&&f.Lk.cG(!0);T(q,F)};
return a};
  var l59 = class{constructor(f){this.L3=this.j=!1;this.potentialEsfErrorCounter=this.B=0;this.handleError=()=>{};
this.K5=()=>{};
this.now=Date.now;this.CP=!1;this.FU={XKo:a=>{this.Sp=a},
kFz:()=>{this.K()},
oi:()=>{this.A()},
Oj:async a=>{await this.Oj(a)},
Mq:(a,e)=>this.Mq(a,e),
s3:()=>{this.s3()}};
this.rE=f.rE??100;this.dE=f.dE??1;this.vn=f.vn??2592E6;this.TB=f.TB??12E4;this.kG=f.kG??5E3;this.Sp=f.Sp??void 0;this.mX=!!f.mX;this.aJ=f.aJ??.1;this.S4=f.S4??10;f.handleError&&(this.handleError=f.handleError);f.K5&&(this.K5=f.K5);f.CP&&(this.CP=f.CP);f.L3&&(this.L3=f.L3);this.JU=f.JU;this.z4=f.z4;this.M8=f.M8;this.Lk=f.Lk;this.KM=f.KM;this.ZH=f.ZH;this.P2=f.P2;t2(this)&&(!this.JU||this.JU("networkless_logging"))&&ft7(this)}writeThenSend(f,a={}){if(t2(this)&&this.j){let e={url:f,options:a,timestamp:this.now(),
status:"NEW",sendCount:0};this.M8.set(e,this.Sp).then(T=>{e.id=T;this.Lk.Xh()&&this.Oj(e)}).catch(T=>{this.Oj(e);
zh(this,T)})}else this.KM(f,a)}sendThenWrite(f,a={},e){if(t2(this)&&this.j){let T={url:f,
options:a,timestamp:this.now(),status:"NEW",sendCount:0};this.JU&&this.JU("nwl_skip_retry")&&(T.skipRetry=e);if(this.Lk.Xh()||this.JU&&this.JU("nwl_aggressive_send_then_write")&&!T.skipRetry){if(!T.skipRetry){let q=a.onError?a.onError:()=>{};
a.onError=async(F,E)=>{await this.M8.set(T,this.Sp).catch(H=>{zh(this,H)});
q(F,E)}}this.KM(f,a,T.skipRetry)}else this.M8.set(T,this.Sp).catch(q=>{this.KM(f,a,T.skipRetry);
zh(this,q)})}else e=this.JU&&this.JU("nwl_skip_retry")&&e,this.KM(f,a,e)}sendAndWrite(f,a={}){if(t2(this)&&this.j){let e={url:f,
options:a,timestamp:this.now(),status:"NEW",sendCount:0},T=!1,q=a.onSuccess?a.onSuccess:()=>{};
e.options.onSuccess=(F,E)=>{e.id!==void 0?this.M8.LZ(e.id,this.Sp):T=!0;this.Lk.cG&&this.JU&&this.JU("vss_network_hint")&&this.Lk.cG(!0);q(F,E)};
this.KM(e.url,e.options,void 0,!0);this.M8.set(e,this.Sp).then(F=>{e.id=F;T&&this.M8.LZ(e.id,this.Sp)}).catch(F=>{zh(this,F)})}else this.KM(f,a,void 0,!0)}K(){if(!t2(this))throw Error("IndexedDB is not supported: throttleSend");
this.B||(this.B=this.z4.jK(async()=>{var f=await this.M8.kD("NEW",this.Sp);f?(await this.Oj(f),this.B&&(this.B=0,this.K())):this.A()},this.rE))}A(){this.z4.Mg(this.B);
this.B=0}async Oj(f){if(!t2(this))throw Error("IndexedDB is not supported: immediateSend");f.id!==void 0&&(await this.M8.TE(f.id,this.Sp)||this.K5(Error("The request cannot be found in the database.")));this.Mq(f,this.vn)?(f.skipRetry||(f=s56(this,f)),f&&(f.skipRetry&&f.id!==void 0&&await this.M8.LZ(f.id,this.Sp),this.KM(f.url,f.options,!!f.skipRetry))):(this.K5(Error("Networkless Logging: Stored logs request expired age limit")),f.id!==void 0&&await this.M8.LZ(f.id,this.Sp))}Mq(f,a){f=f.timestamp;
return this.now()-f>=a?!1:!0}s3(){if(!t2(this))throw Error("IndexedDB is not supported: retryQueuedRequests");this.M8.kD("QUEUED",this.Sp).then(f=>{f&&!this.Mq(f,this.TB)?this.z4.jK(async()=>{f.id!==void 0&&await this.M8.yk(f.id,this.Sp);this.s3()}):this.Lk.Xh()&&this.K()})}};
  var It6 = class extends l59{constructor(){JZ||(JZ=new g.y2({MKH:!0,ApH:!0}));super({M8:{fF:Ax6,LZ:dby,kD:EZY,TE:HPo,yk:C17,set:FC6},Lk:JZ,handleError:(f,a,e)=>{var T=e?.error?.code;T===400||T===415?(f=new g.vc(f.message,a,e?.error?.code),ZH(f,void 0,void 0,void 0,!0)):g.hC(f)},
K5:ZH,KM:KCg,now:g.u,MC:lto,z4:g.Rc(),ZH:"publicytnetworkstatus-online",P2:"publicytnetworkstatus-offline",mX:!0,aJ:.1,S4:g.d6("potential_esf_error_limit",10),JU:g.C2,CP:!(rD()&&g.xB(document.location.toString())!=="www.youtube-nocookie.com")});this.S=new g.sA;g.C2("networkless_immediately_drop_all_requests")&&Sa1();dPw("LogsDatabaseV2")}writeThenSend(f,a){a||(a={});a=CK(f,a);rD()||(this.j=!1);super.writeThenSend(f,a)}sendThenWrite(f,a,e){a||(a={});a=CK(f,a);rD()||(this.j=!1);super.sendThenWrite(f,
a,e)}sendAndWrite(f,a){a||(a={});a=CK(f,a);rD()||(this.j=!1);super.sendAndWrite(f,a)}awaitInitialization(){return this.S.promise}};
  var xbY = undefined;
  yxT = function(f){return g.B8(xbY(),f)};
  Jxo = async function(f){f=await yxT(f);var a=(0,g.u)()-2592E6;await g.CW(f,["SWHealthLog"],{mode:"readwrite",oV:!0},e=>g.yS(e.objectStore("SWHealthLog"),{},T=>{if(T.getValue().timestamp<=a)return T.delete().then(()=>g.J2(T))}))};
  Gs6 = async function(f){await (await yxT(f)).clear("SWHealthLog")};
  M3w = async function(f){if(!f.Sp)throw g.eB("clearSWHealthLogsDb");Gs6(f.Sp).catch(a=>{f.handleError(a)})};
  HH = function(){var f=g.yY("yt.networklessRequestController.instance");f||(f=new It6,g.x3("yt.networklessRequestController.instance",f),g.C2("networkless_logging")&&g.iG().then(a=>{f.Sp=a;ft7(f);f.S.resolve();f.mX&&Math.random()<=f.aJ&&f.Sp&&Jxo(f.Sp);g.C2("networkless_immediately_drop_sw_health_store")&&M3w(f)}));
return f};
  var Uby = {};
  g.dH = function(f,a,e,T){!g.gp("VISITOR_DATA")&&a!=="visitor_id"&&Math.random()<.01&&ZH(new g.vc("Missing VISITOR_DATA when sending innertube request.",a,e,T));if(!f.isReady())throw f=new g.vc("innertube xhrclient not ready",a,e,T),g.hC(f),f;var q={headers:T.headers||{},method:"POST",postParams:e,postBody:T.postBody,postBodyFormat:T.postBodyFormat||"JSON",onTimeout:()=>{T.onTimeout()},
onFetchTimeout:T.onTimeout,onSuccess:(A,y)=>{if(T.onSuccess)T.onSuccess(y)},
onFetchSuccess:A=>{if(T.onSuccess)T.onSuccess(A)},
onProgress:A=>{if(T.onProgress)T.onProgress(A)},
onError:(A,y)=>{if(T.onError)T.onError(y)},
onFetchError:A=>{if(T.onError)T.onError(A)},
timeout:T.timeout,withCredentials:!0,compress:T.compress};q.headers["Content-Type"]||(q.headers["Content-Type"]="application/json");e="";var F=f.config_.Pv;F&&(e=F);F=f.config_.vv||!1;var E=goT(F,e,T);Object.assign(q.headers,E);q.headers.Authorization&&!e&&F&&(q.headers["x-origin"]=window.location.origin);var H=zS(`${e}${`/youtubei/${f.config_.innertubeApiVersion}/${a}`}`,{alt:"json"}),C=(A=!1)=>{try{if(A&&T.retry&&!T.networklessOptions.bypassNetworkless)q.method="POST",T.networklessOptions.writeThenSend?
HH().writeThenSend(H,q):HH().sendAndWrite(H,q);else if(T.compress)if(q.postBody){let y=q.postBody;typeof y!=="string"&&(y=JSON.stringify(q.postBody));mr(H,y,q,g.Jk)}else mr(H,JSON.stringify(q.postParams),q,Gy);else Gy(H,q)}catch(y){if(y.name==="InvalidAccessError")ZH(Error("An extension is blocking network request."));else throw y;}};
g.yY("ytNetworklessLoggingInitializationOptions")&&Uby.isNwlInitialized?fdo().then(A=>{C(A)}):C(!1)};
  var HO = !0;
  Ia3 = function(f,a,e,T,q={},F,E){if(f.size===0)e();else{var H=Math.round((0,g.u)()),C=f.size,A=Ok6(E);for(let [y,J]of f){f=y;E=J;let p=g.Lh({context:g.Oo(a.config_||g.VS())});if(!g.N6(E)&&!g.C2("throw_err_when_logevent_malformed_killswitch")){T();break}p.events=E;(E=Fc[f])&&R9$(p,f,E);delete Fc[f];let B=f==="visitorOnlyApprovedKey";YAg(p,H,B);Xq3(q);let w=R=>{g.C2("start_client_gcf")&&g.tQ.jK(async()=>{await gSq(R)});
C--;C||e()},P=0,O=()=>{P++;
if(q.bypassNetworkless&&P===1)try{g.dH(a,A,p,CR({writeThenSend:!0},B,w,O,F)),HO=!1}catch(R){g.hC(R),T()}C--;C||e()};
try{g.dH(a,A,p,CR(q,B,w,O,F)),HO=!1}catch(R){g.hC(R),T()}}}};
  fT$ = function(f){f.G||(f.G=!0,g.FD(f.bU,f))};
  var qCw = pU;
  ek$ = function(f,a){f.S=!0;g.FD(function(){f.S&&qCw.call(null,a)})};
  XT = function(f,a){if(Error.captureStackTrace)Error.captureStackTrace(this,XT);else{let e=Error().stack;e&&(this.stack=e)}f&&(this.message=String(f));a!==void 0&&(this.cause=a)};
  CP = function(f){XT.call(this,f)};
  g.pB = function(){};
  ujw = function(){this.next=this.context=this.B=this.K=this.j=null;this.A=!1};
  var ZUw = {};
  sa = function(f,a,e){var T=ZUw.get();T.K=f;T.B=a;T.context=e;return T};
  Ea = function(f,a){f.B||f.j!=2&&f.j!=3||fT$(f);f.A?f.A.next=a:f.B=a;f.A=a};
  tX6 = function(f,a,e,T){Ea(f,sa(a||g.pB,e||null,T))};
  s1w = function(f,a,e,T,q){function F(C){H||(H=!0,T.call(q,C))}
function E(C){H||(H=!0,e.call(q,C))}
var H=!1;try{a.call(f,E,F)}catch(C){F(C)}};
  $q6 = function(f,a,e,T){if(f instanceof g.e3)return tX6(f,a,e,T),!0;if(f)try{var q=!!f.$goog_Thenable}catch(F){q=!1}else q=!1;if(q)return f.then(a,e,T),!0;if(g.QY(f))try{let F=f.then;if(typeof F==="function")return s1w(f,F,a,e,T),!0}catch(F){return e.call(T,F),!0}return!1};
  a5 = function(f,a,e){f.j==0&&(f===e&&(a=3,e=new TypeError("Promise cannot resolve to itself")),f.j=1,$q6(e,f.xn,f.iM,f)||(f.W=e,f.j=a,f.K=null,fT$(f),a!=3||e instanceof CP||ek$(f,e)))};
  g.e3 = function(f,a){this.j=0;this.W=void 0;this.A=this.B=this.K=null;this.S=this.G=!1;if(f!=g.pB)try{let e=this;f.call(a,function(T){a5(e,2,T)},function(T){a5(e,3,T)})}catch(e){a5(this,3,e)}};
  g.U = g.e3.prototype;
  var zu = undefined;
  g.U.finally = function(f){f=zu(f);return new g.e3((a,e)=>{tX6(this,T=>{f();a(T)},T=>{f();
e(T)})})};
  aT3 = function(f,a,e,T){var q=sa(null,null,null);q.j=new g.e3(function(F,E){q.K=a?function(H){try{let C=a.call(T,H);F(C)}catch(C){E(C)}}:F;
q.B=e?function(H){try{let C=e.call(T,H);C===void 0&&H instanceof CP?E(H):F(C)}catch(C){E(C)}}:E});
q.j.K=f;Ea(f,q);return q.j};
  g.U.cK = function(f,a){return aT3(this,null,zu(f),a)};
  g.U.catch = {};
  kiq = function(f){var a=null;f.B&&(a=f.B,f.B=a.next,a.next=null);f.B||(f.A=null);return a};
  TGT = function(f,a,e){a==2?f.K.call(f.context,e):f.B&&f.B.call(f.context,e)};
  jE$ = function(f,a,e,T){if(e==3&&a.B&&!a.A)for(;f&&f.S;f=f.K)f.S=!1;if(a.j)a.j.K=null,TGT(a,e,T);else try{a.A?a.K.call(a.context):TGT(a,e,T)}catch(q){qCw.call(null,q)}ZUw.put(a)};
  z4q = function(f,a){if(f.j==0)if(f.K){var e=f.K;if(e.B){var T=0,q=null,F=null;for(let E=e.B;E&&(E.A||(T++,E.j==f&&(q=E),!(q&&T>1)));E=E.next)q||(F=E);q&&(e.j==0&&T==1?z4q(e,a):(F?(T=F,T.next==e.A&&(e.A=T),T.next=T.next.next):kiq(e),jE$(e,q,3,a)))}f.K=null}else a5(f,3,a)};
  g.U.cancel = function(f){if(this.j==0){let a=new CP(f);g.FD(function(){z4q(this,a)},this)}};
  g.U.xn = function(f){this.j=0;a5(this,2,f)};
  g.U.iM = function(f){this.j=0;a5(this,3,f)};
  g.U.bU = function(){for(var f;f=kiq(this);)jE$(this,f,this.j,this.W);this.G=!1};
  oST = function(f,a){if(f.endpoint==="log_event"){g.C2("more_accurate_gel_parser")&&cH().storePayload({isJspb:!1},f.payload);ti(f);var e=zJ(f),T=new Map;T.set(e,[f.payload]);var q=B9o(f.payload)||"";(f=yQg(a))&&Zn(f);return new g.e3((F,E)=>{uA&&uA.isReady()?Ia3(T,uA,F,E,{bypassNetworkless:!0},!0,jG(q)):F()})}};
  var kJ = {};
  var Bz = class{constructor(){this.A=this.B=this.K=0;this.j=!1}};
  var kj1 = {};
  var rQ6 = {};
  var z9T = {};
  var Pe1 = {};
  fR = function(f,a=200){return f?a===300?Pe1:z9T:a===300?rQ6:kj1};
  Ej = function(f){g.C2("transport_use_scheduler")?g.tQ.Mg(f):g.Fh(f)};
  g.dI = class extends Iq{constructor(f){super(f)}};
  NU = function(f){if(f==null)return f;if(typeof f==="string"&&f)f=+f;else if(typeof f!=="number")return;return JT(f)?f|0:void 0};
  sV = function(f,a){f=GK(f,a);return(f==null?f:JT(f)?f|0:void 0)??0};
  var EdG = class extends Iq{constructor(f){super(f)}};
  var bkN = class extends Iq{constructor(f){super(f)}getDeviceId(){return eU(this,6)}HY(f){var a=lX(this,9,NU,3,!0);cV(a,f);return a[f]}getPlayerType(){return sV(this,36)}setHomeGroupInfo(f){return te(this,EdG,81,f)}clearLocationPlayabilityToken(){return Bs(this,89)}};
  var AR = class extends Iq{constructor(f){super(f)}K(f){return te(this,bkN,1,f)}};
  AT = function(f){if(f!=null&&typeof f!=="number")throw Error(`Value of float/double field must be a number, found ${typeof f}: ${f}`);return f};
  var LHw = class extends Iq{constructor(f){super(f)}};
  var Sx = [2,3,4,5,6];
  var h93 = class extends Iq{constructor(f){super(f)}getValue(){return eU(this,RD(this,Sx,2))}clearValue(){return VG(this,2,Sx)}};
  Zb = function(f,a,e,T,q,F,E,H,C){F=F&&F!==4?F!==1&&ZK(f,e)?1:F:4;H=!!H||F===3;var A=!!C&&!ZK(f,e);(F===2||A)&&SN(f)&&(a=f.uN,e=a[ut]|0);f=Nw(a,q,E);var y=f===QG?7:f[ut]|0,J=oD(y,e);if(C=!(4&J)){var p=f,B=e;let w=!!(2&J);w&&(B|=2);let P=!w,O=!0,R=0,h=0;for(;R<p.length;R++){let X=Yf(p[R],T,B);if(X instanceof T){if(!w){let c=ZK(X);P&&(P=!c);O&&(O=c)}p[h++]=X}}h<R&&(p.length=h);J|=4;J=O?J&-4097:J|4096;J=P?J|8:J&-9}J!==y&&(f[ut]=J,2&J&&Object.freeze(f));if(A&&!(8&J||!f.length&&(F===1||(F!==4?0:2&J||!(16&
J)&&32&e)))){nq(J)&&(f=[...f],J=Ws(J,e),e=pq(a,e,q,f,E));T=f;A=J;for(y=0;y<T.length;y++)p=T[y],J=Ae(p),p!==J&&(T[y]=J);A|=8;J=A=T.length?A|4096:A&-4097;f[ut]=J}return f=wL(f,J,a,e,q,E,F,C,H)};
  jN = function(f,a,e,T){var q=T;xL(f);T=f.uN;f=Zb(f,T,T[ut]|0,e,a,2,void 0,!0);q=q!=null?DT(q,e):new e;f.push(q);a=e=f===QG?7:f[ut]|0;(q=ZK(q))?(e&=-9,f.length===1&&(e&=-4097)):e|=4096;e!==a&&(f[ut]=e);q||yG(T)};
  var xv = class extends Iq{constructor(f){super(f)}setSafetyMode(f){return H4(this,5,f)}};
  x00 = function(f){switch(f){case "DESKTOP":return 1;case "UNKNOWN_PLATFORM":return 0;case "TV":return 2;case "GAME_CONSOLE":return 3;case "MOBILE":return 4;case "TABLET":return 5}};
  pp = function(f){if(typeof f!=="number")throw Xj("int32");if(!JT(f))throw Xj("int32");return f|0};
  B6 = function(f){return f==null?f:pp(f)};
  var u7$ = class extends Iq{constructor(f){super(f)}getToken(){return q2(this,2)}setToken(f){return EV(this,2,f)}};
  FL = function(f,a,e){return Bs(f,a,W6(e))};
  var $76 = class extends Iq{constructor(f){super(f)}};
  var JR = 1;
  var mo = new Map;
  var la = class{constructor(f){this.j=f}toString(){return this.j+""}};
  nw = function(f){var a=w8();f=a?a.createScriptURL(f):f;return new la(f)};
  ij = function(f){return f?(f=f.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue)?nw(f):null:null};
  var XY = void 0;
  d7w = function(){XY||(XY=ij(g.gp("WORKER_SERIALIZATION_URL")));return XY||void 0};
  Wl = function(f){if(f instanceof la)return f.j;throw Error("");};
  var gH = void 0;
  AQN = function(){var f=d7w();gH||f===void 0||(gH=new Worker(Wl(f),void 0));return gH};
  var G_ = class extends Iq{constructor(f){super(f,500)}};
  Gjg = function(f,a,e,T={},q,F,E,H={value:0}){F=Ok6(F);T=CR(T,E,C=>{g.C2("start_client_gcf")&&g.tQ.jK(async()=>{await gSq(C)});
H.value--;H.value||e()},()=>{H.value--;
H.value||e()},q);
T.headers["Content-Type"]="application/json+protobuf";T.postBodyFormat="JSPB";T.postBody=f;g.dH(a,F,"",T);HO=!1};
  MQq = function(f,a,e,T={},q,F){if(f.size===0)e();else{var E=Math.round((0,g.u)()),H={value:f.size},C=new Map([...f]);for(let [O]of C){var A=O,y=f.get(A);C=new g.dI;var J=a.config_||g.VS(),p=new AR,B=new bkN;EV(B,1,J.L_);EV(B,2,J.gi);H4(B,16,J.TK);EV(B,17,J.innertubeContextClientVersion);if(J.It){var w=J.It,P=new X$;w.coldConfigData&&EV(P,1,w.coldConfigData);w.appInstallData&&EV(P,6,w.appInstallData);w.coldHashData&&EV(P,3,w.coldHashData);w.hotHashData&&P.wl(w.hotHashData);te(B,X$,62,P)}(w=g.S6.devicePixelRatio)&&
w!=1&&Bs(B,65,AT(w));w=Ak();w!==""&&EV(B,54,w);w=xq();if(w.length>0){P=new LHw;for(let R=0;R<w.length;R++){let h=new h93;EV(h,1,w[R].key);VG(h,2,Sx,rG(w[R].value));jN(P,15,h93,h)}te(p,LHw,5,P)}Png(J,B);r1w(p);voY(B);DPg(J,B);V8y(B);g.C2("start_client_gcf")&&OIY(B);g.gp("DELEGATED_SESSION_ID")&&!g.C2("pageid_as_header_web")&&(J=new xv,EV(J,3,g.gp("DELEGATED_SESSION_ID")));!g.C2("fill_delegate_context_in_gel_killswitch")&&(w=g.gp("INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT"))&&(P=uX(p,xv,3)||new xv,
J=p,w=EV(P,18,w),te(J,xv,3,w));J=B;w=g.gp("DEVICE","");for(let [R,h]of Object.entries(ct(w)))w=R,P=h,w==="cbrand"?EV(J,12,P):w==="cmodel"?EV(J,13,P):w==="cbr"?EV(J,87,P):w==="cbrver"?EV(J,88,P):w==="cos"?EV(J,18,P):w==="cosver"?EV(J,19,P):w==="cplatform"&&H4(J,42,x00(P));g.C2("web_attention_logging_enabled")&&(Bs(B,55,B6(window.innerWidth)),Bs(B,56,B6(window.innerHeight)));p.K(B);te(C,AR,1,p);if(B=qd[A])a:{if(B.x0())p=1;else if(B.getPlaylistId())p=2;else break a;te(C,KHy,4,B);B=uX(C,AR,1)||new AR;
J=uX(B,xv,3)||new xv;w=new u7$;w.setToken(A);H4(w,1,p);jN(J,12,u7$,w);te(B,xv,3,J)}delete qd[A];A=A==="visitorOnlyApprovedKey";yv()||FL(C,2,E);!A&&(p=g.gp("EVENT_ID"))&&(B=Zko(),J=new $76,EV(J,1,p),FL(J,2,B),te(C,$76,5,J));Xq3(T);if(g.C2("jspb_serialize_with_worker")&&(p=AQN())&&T.writeThenSend){mo.set(JR,{client:a,resolve:e,networklessOptions:T,isIsolated:q,useVSSEndpoint:F,dangerousLogToVisitorSession:A,requestsOutstanding:H});p.postMessage({op:"gelBatchToSerialize",batchRequest:j_(C),clientEvents:y,
key:JR});JR++;break}if(y){p=[];for(B=0;B<y.length;B++)try{p.push(new G_(y[B]))}catch{g.hC(new g.vc("Transport failed to deserialize "+String(y[B])))}y=p}else y=[];for(let R of y)jN(C,3,G_,R);y={startTime:(0,g.u)(),ticks:{},infos:{}};C=C.TW();y.ticks.geljspc=(0,g.u)();g.C2("log_jspb_serialize_latency")&&c8("gel_jspb_serialize",y,{sampleRate:.1});Gjg(C,a,e,T,q,F,A,H)}}};
  U7y = function(f,a,e={},T=!1,q=200,F=!1){var E=uA,H=new Map,C=new Map,A={isJspb:T,cttAuthInfo:void 0,tier:q},y={isJspb:T,cttAuthInfo:void 0};if(T){for(let J of Object.keys(kJ))a=g.C2("enable_web_tiered_gel")?cH().smartExtractMatchingEntries({keys:[A,y],sizeLimit:1E3}):cH().extractMatchingEntries({isJspb:!0,cttAuthInfo:J}),a.length>0&&H.set(J,a),(g.C2("web_fp_via_jspb_and_json")&&e.writeThenSend||!g.C2("web_fp_via_jspb_and_json"))&&delete kJ[J];MQq(H,E,f,e,!1,F)}else{for(let J of Object.keys(kJ))H=g.C2("enable_web_tiered_gel")?
cH().smartExtractMatchingEntries({keys:[{isJspb:!1,cttAuthInfo:J,tier:q},{isJspb:!1,cttAuthInfo:J}],sizeLimit:1E3}):cH().extractMatchingEntries({isJspb:!1,cttAuthInfo:J}),H.length>0&&C.set(J,H),(g.C2("web_fp_via_jspb_and_json")&&e.writeThenSend||!g.C2("web_fp_via_jspb_and_json"))&&delete kJ[J];Ia3(C,E,f,a,e,!1,F)}};
  af = function(f={},a=!1,e){new g.e3((T,q)=>{var F=fR(a,e),E=F.j;F.j=!1;if(g.C2("enable_web_tiered_gel")&&g.C2("web_vss_routing_check_all_tier_policies")){let H=fR(a,300),C=fR(a,200);E=E||H.j||C.j;H.j=!1;C.j=!1}Ej(F.K);Ej(F.B);F.B=0;uA&&uA.isReady()?e===void 0&&g.C2("enable_web_tiered_gel")?U7y(T,q,f,a,300,E):U7y(T,q,f,a,e,E):(ik7(a,e),T())})};
  var vS$ = undefined;
  g.Vr = function(f,a,e){return DR(0,a,0,e)};
  var rH = window;
  vH = function(){return"h5vcc"in rH&&rH.h5vcc.traceEvent?.traceBegin&&rH.h5vcc.traceEvent?.traceEnd?1:"performance"in rH&&rH.performance.mark&&rH.performance.measure?2:0};
  Og = function(f,a=`unexpected value ${f}!`){throw Error(a);};
  Dn = function(f){var a=vH();switch(a){case 1:rH.h5vcc.traceEvent.traceBegin("YTLR",f);break;case 2:rH.performance.mark(`${f}-start`);break;case 0:break;default:Og(a,"unknown trace type")}};
  var Rk = {};
  t30 = function(f){var a=vH();switch(a){case 1:rH.h5vcc.traceEvent.traceEnd("YTLR",f);break;case 2:a=`${f}-start`;let e=`${f}-end`;rH.performance.mark(e);rH.performance.measure(f,a,e);break;case 0:break;default:Og(a,"unknown trace type")}};
  zbw = function(f){var a=Array.from(f.j.keys()).sort((e,T)=>(f.j[T].priority??0)-(f.j[e].priority??0));
for(let e of a)a=f.j[e],a.jobId===void 0||a.h3||(f.scheduler.Mg(a.jobId),DR(0,a.kT,10))};
  var ks6 = undefined;
  j56 = function(f,a,e){ks6&&console.groupCollapsed&&console.groupEnd&&(console.groupCollapsed(`[${f.constructor.name}] '${f.state}' to '${a}'`),console.log("with message: ",e),console.groupEnd())};
  T9q = function(f){Rk&&f&&Dn(f)};
  qA$ = function(f){if(g.C2("web_lifecycle_error_handling_killswitch"))return f();try{return f()}catch(a){window.onerror?.(a.message,"",0,0,a)}};
  Os = function(f){Rk&&f&&t30(f)};
  FHq = function(f,...a){return()=>{T9q(f.name);qA$(()=>f.callback(...a));
Os(f.name)}};
  wZ0 = function(f){var a=g.yY("yt.scheduler.instance.addImmediateJob");a?a(f):f()};
  e9$ = function(f,...a){g.Rc();for(let e of f)f=FHq(e,...a),wZ0(f)};
  var ESY = class{constructor(f){this.scheduler=g.Rc();this.B=new g.sA;this.j=f;for(let a=0;a<this.j.length;a++){let e=this.j[a];f=()=>{e.kT();this.j[a].h3=!0;this.j.every(q=>q.h3===!0)&&this.B.resolve()};
let T=DR(0,f,e.priority??0);this.j[a]={...e,kT:f,jobId:T}}}cancel(){for(let f of this.j)f.jobId===void 0||f.h3||this.scheduler.Mg(f.jobId),f.h3=!0;this.B.resolve()}};
  aaw = function(f,a,...e){a=a.map(T=>{var q=f.B??T.priority??0;return{kT:FHq(T,...e),priority:q}});
a.length&&(f.K=new ESY(a))};
  var Vn = undefined;
  faN = async function(f,...a){g.Rc();for(let e of f){let T;wZ0(()=>{T9q(e.name);var q=qA$(()=>e.callback(...a));
Vn(q)?T=g.C2("web_lifecycle_error_handling_killswitch")?q.then(()=>{Os(e.name)}):q.then(()=>{Os(e.name)},F=>{window.onerror?.(F.message,"",0,0,F);
Os(e.name)}):Os(e.name)});
T&&await T}};
  stw = function(f,a){var e=a.filter(q=>(f.B??q.priority??0)===10),T=a.filter(q=>(f.B??q.priority??0)!==10);
return f.S.Qxk?async(...q)=>{await faN(e,...q);aaw(f,T,...q)}:(...q)=>{e9$(e,...q);
aaw(f,T,...q)}};
  var Mn0 = class{constructor(){this.state="none";this.plugins=[];this.B=void 0;this.A=[];this.S={};Rk&&Dn(this.state)}get currentState(){return this.state}install(f){this.plugins.push(f);return this}uninstall(...f){f.forEach(a=>{a=this.plugins.indexOf(a);a>-1&&this.plugins.splice(a,1)})}transition(f,a){Rk&&t30(this.state);
var e=this.transitions.find(T=>Array.isArray(T.from)?T.from.find(q=>q===this.state&&T.to===f):T.from===this.state&&T.to===f);
if(e){this.K&&(zbw(this.K),this.K=void 0);g.C2("kevlar_startup_split")&&this.A.length&&(this.A.forEach(q=>{zbw(q)}),this.A=[]);
j56(this,f,a);this.state=f;Rk&&Dn(this.state);e=e.action.bind(this);let T=this.plugins.filter(q=>q[f]).map(q=>q[f]);
e(stw(this,T),a)}else throw Error(`no transition specified from ${this.state} to ${f}`);}};
  var Hk0 = class extends Mn0{constructor(){super();this.j=null;this.B=10;this.transitions=[{from:"none",to:"application_navigating",action:this.G},{from:"application_navigating",to:"none",action:this.W},{from:"application_navigating",to:"application_navigating",action:()=>{}},
{from:"none",to:"none",action:()=>{}}]}G(f,a){this.j=g.Vr(0,()=>{this.currentState==="application_navigating"&&this.transition("none")},5E3);
f(a?.event)}W(f,a){this.j&&(g.tQ.Mg(this.j),this.j=null);f(a?.event)}};
  YJ = undefined;
  Ce6 = function(){YJ||(YJ=new Hk0);return YJ};
  sj = function(f,a){return g.C2("transport_use_scheduler")===!1?g.Ty(f,a):g.C2("logging_avoid_blocking_during_navigation")||g.C2("lr_logging_avoid_blocking_during_navigation")?g.Vr(0,()=>{Ce6().currentState==="none"?f():Ce6().install({none:{callback:f}})},a):g.Vr(0,f,a)};
  var D76 = undefined;
  var VQ7 = undefined;
  ik7 = function(f=!1,a=200){var e=()=>{af({writeThenSend:!0},f,a)},T=fR(f,a),q=T===Pe1||T===rQ6?5E3:vS$;
g.C2("web_gel_timeout_cap")&&!T.B&&(q=sj(()=>{e()},q),T.B=q);
Ej(T.K);q=g.gp("LOGGING_BATCH_TIMEOUT",g.d6("web_gel_debounce_ms",1E4));g.C2("shorten_initial_gel_batch_timeout")&&HO&&(q=D76);q=sj(()=>{g.d6("gel_min_batch_size")>0?cH().getSequenceCount({cttAuthInfo:void 0,isJspb:f,tier:a})>=VQ7&&e():e()},q);
T.K=q};
  ex = undefined;
  wqw = function(f,a=!1,e,T=!1){f&&Zn(f);f=g.d6("tvhtml5_logging_max_batch_ads_fork")||g.d6("tvhtml5_logging_max_batch")||g.d6("web_logging_max_batch")||100;var q=(0,g.u)(),F=fR(a,e.tier),E=F.A;T&&(F.j=!0);T=0;e&&(T=cH().getSequenceCount(e));T>=1E3?af({writeThenSend:!0},a,e.tier):T>=f?ex||(ex=sj(()=>{af({writeThenSend:!0},a,e.tier);ex=void 0},0)):q-E>=10&&(ik7(a,e.tier),F.A=q)};
  lay = function(f,a){if(f.endpoint==="log_event"){ti(f);var e=zJ(f),T=B9o(f.payload)||"",q=N90(T),F=200;if(q){if(q.enabled===!1&&!g.C2("web_payload_policy_disabled_killswitch"))return;F=Qto(q.tier);if(F===400){oST(f,a);return}}kJ[e]=!0;e={cttAuthInfo:e,isJspb:!1,tier:F};cH().storePayload(e,f.payload);wqw(a,!1,e,jG(T))}};
  Nd = function(f,a,e,T={}){var q={},F=Math.round(T.timestamp||(0,g.u)());q.eventTimeMs=F<Number.MAX_SAFE_INTEGER?F:0;q[f]=a;f=du();q.context={lastActivityMs:String(T.timestamp||!isFinite(f)?-1:f)};T.sequenceGroup&&!g.C2("web_gel_sequence_info_killswitch")&&(f=q.context,a=T.sequenceGroup,a={index:fpN(a),groupKey:a},f.sequence=a,T.endOfSequence&&delete BO[T.sequenceGroup]);g.C2("web_tag_automated_log_events")&&(q.context.automatedLogEventSource=T.automatedLogEventSource);(T.sendIsolatedPayload?oST:lay)({endpoint:"log_event",
payload:q,cttAuthInfo:T.cttAuthInfo,dangerousLogToVisitorSession:T.dangerousLogToVisitorSession},e)};
  g.of = function(f,a,e={}){var T=g.Qv;g.gp("ytLoggingEventsDefaultDisabled",!1)&&g.Qv===g.Qv&&(T=null);Nd(f,a,T,e)};
  var Pv1 = 0;
  var rc3 = ["PhantomJS","Googlebot","TO STOP THIS SECURITY SCAN go/scan"];
  bj = function(f){var a=Yg.EXPERIMENT_FLAGS;return a?a[f]:void 0};
  var vXY = [];
  apw = function(f=!1){af(void 0,f)};
  var Mu0 = {};
  var nX0 = 0;
  KO7 = function(f,a="ERROR"){if(a==="ERROR"){Rf.publish("handleError",f);if(g.C2("record_app_crashed_web")&&UV0===0&&f.sampleWeight===1){UV0++;var e={appCrashType:"APP_CRASH_TYPE_BREAKPAD"};g.C2("report_client_error_with_app_crash_ks")||(e.systemHealth={crashData:{clientError:{logMessage:{message:f.message}}}});g.of("appCrashed",e)}Pv1++}else a==="WARNING"&&Rf.publish("handleWarning",f);if(g.C2("kevlar_gel_error_routing")){e={};b:{for(T of rc3)if(g.D7(T.toLowerCase())){var T=!0;break b}T=!1}if(T)e=void 0;
else{var q={stackTrace:f.stack};f.fileName&&(q.filename=f.fileName);T=f.lineNumber&&f.lineNumber.split?f.lineNumber.split(":"):[];T.length!==0&&(T.length!==1||isNaN(Number(T[0]))?T.length!==2||isNaN(Number(T[0]))||isNaN(Number(T[1]))||(q.lineNumber=Number(T[0]),q.columnNumber=Number(T[1])):q.lineNumber=Number(T[0]));T={level:"ERROR_LEVEL_UNKNOWN",message:f.message,errorClassName:f.name,sampleWeight:f.sampleWeight};a==="ERROR"?T.level="ERROR_LEVEL_ERROR":a==="WARNING"&&(T.level="ERROR_LEVEL_WARNNING");
q={isObfuscated:!0,browserStackInfo:q};e.pageUrl=window.location.href;e.kvPairs=[];g.gp("FEXP_EXPERIMENTS")&&(e.experimentIds=g.gp("FEXP_EXPERIMENTS"));var F=g.gp("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS");if(!bj("web_disable_gel_stp_ecatcher_killswitch")&&F)for(var E of Object.keys(F))e.kvPairs.push({key:E,value:String(F[E])});if(E=f.params)for(var H of Object.keys(E))e.kvPairs.push({key:`client.${H}`,value:String(E[H])});if(H=f.params?.sessionReplayId)e.sessionReplayId=String(H);H=g.gp("SERVER_NAME");
E=g.gp("SERVER_VERSION");H&&E&&(e.kvPairs.push({key:"server.name",value:H}),e.kvPairs.push({key:"server.version",value:E}));(H=g.gp("PLAYER_CLIENT_VERSION"))&&e.kvPairs.push({key:"client.player.version",value:H});e={errorMetadata:e,stackTrace:q,logMessage:T}}if(e&&(g.of("clientError",e),a==="ERROR"||g.C2("errors_flush_gel_always_killswitch")))a:{if(g.C2("web_fp_via_jspb")){e=vXY;vXY=[];if(e)for(var C of e)Nd(C.payloadName,C.payload,g.Qv,C.options);apw(!0);if(!g.C2("web_fp_via_jspb_and_json"))break a}apw()}}if(!g.C2("suppress_error_204_logging")){C=
f.params||{};a={urlParams:{a:"logerror",t:"jserror",type:f.name,msg:f.message.substr(0,250),line:f.lineNumber,level:a,"client.name":C.name},postParams:{url:g.gp("PAGE_NAME",window.location.href),file:f.fileName},method:"POST"};C.version&&(a["client.version"]=C.version);if(a.postParams){f.stack&&(a.postParams.stack=f.stack);for(var A of Object.keys(C))a.postParams[`client.${A}`]=C[A];if(A=g.gp("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS"))for(var y of Object.keys(A))a.postParams[y]=A[y];(y=g.gp("LAVA_VERSION"))&&
(a.postParams["lava.version"]=y);y=g.gp("SERVER_NAME");A=g.gp("SERVER_VERSION");y&&A&&(a.postParams["server.name"]=y,a.postParams["server.version"]=A);(y=g.gp("PLAYER_CLIENT_VERSION"))&&(a.postParams["client.player.version"]=y)}g.Jk(`${g.gp("ECATCHER_REPORT_HOST","")}/error_204`,a)}try{Mu0.add(f.message)}catch(J){}nX0++};
  lp3 = function(f,a,e="ERROR"){if(f){f.hasOwnProperty("level")&&f.level&&(e=f.level);if(g.C2("wiz_enable_metadata_extraction_killswitch")){var T=a;if(!T?.componentStack){var q=f.Yw?.Hl;q&&(T||(T={}),T.componentStack=q)}a=T||a}else a=wQw(f,a),T=f.Yw?.I2,T!==void 0&&e!=="IGNORED"&&(e=T>=3?"ERROR":"WARNING");if(g.C2("console_log_js_exceptions")||["test","dev","autopush","staging"].includes(g.gp("SERVER_VERSION")))T=[],T.push(`Name: ${f.name}`),T.push(`Message: ${f.message}`),f.hasOwnProperty("params")&&
T.push(`Error Params: ${JSON.stringify(f.params)}`),f.hasOwnProperty("args")&&T.push(`Error args: ${JSON.stringify(f.args,null,2)}`),T.push(`File name: ${f.fileName}`),T.push(`Stacktrace: ${f.stack}`),window.console.log(T.join("\n"),f);if(!(nX0>=5)){T=[];for(F of WO1)try{F()&&T.push(F())}catch(w){}var F=T;F=[...ig$,...F];var E=Igg(f);T=E.message||"Unknown Error";q=E.name||"UnknownError";var H=E.stack||f.v3U||"Not available";if(H.startsWith(`${q}: ${T}`)){var C=H.split("\n");C.shift();H=C.join("\n")}C=
E.lineNumber||"Not available";E=E.fileName||"Not available";let B=0;if(f.hasOwnProperty("args")&&f.args&&f.args.length)for(var A=0;A<f.args.length&&!(B=oXT(f.args[A],`params.${A}`,a,B),B>=500);A++);else if(f.hasOwnProperty("params")&&f.params){let w=f.params;if(typeof f.params==="object")for(A in w){if(!w[A])continue;let P=`params.${A}`,O=Dz(w[A]);a[P]=O;B+=P.length+O.length;if(B>500)break}else a.params=Dz(w)}if(F.length)for(A=0;A<F.length&&!(B=oXT(F[A],`params.context.${A}`,a,B),B>=500);A++);navigator.vendor&&
!a.hasOwnProperty("vendor")&&(a["device.vendor"]=navigator.vendor);A={message:T,name:q,lineNumber:C,fileName:E,stack:H,params:a,sampleWeight:1};a=Number(f.columnNumber);isNaN(a)||(A.lineNumber=`${A.lineNumber}:${a}`);if(f.level==="IGNORED")var y=0;else a:{f=PO();for(y of f.mT)if(A.message&&A.message.match(y.YI)){y=y.weight;break a}for(var J of f.Lv)if(J.callback(A)){y=J.weight;break a}y=1}A.sampleWeight=y;y=A;for(var p of Ip0){if(!p.dP[y.name])continue;J=p.dP[y.name];for(let w of J){J=y.message.match(w.Vi);
if(!J)continue;y.params["params.error.original"]=J[0];f=w.groups;A={};for(a=0;a<f.length;a++)A[f[a]]=J[a+1],y.params[`params.error.${f[a]}`]=J[a+1];y.message=p.Nx(A);break}}y.params||(y.params={});p=PO();y.params["params.errorServiceSignature"]=`msg=${p.mT.length}&cb=${p.Lv.length}`;y.params["params.serviceWorker"]="false";g.S6.document&&g.S6.document.querySelectorAll&&(y.params["params.fscripts"]=String(document.querySelectorAll("script:not([nonce])").length));window.yterr&&typeof window.yterr===
"function"&&window.yterr(y);y.sampleWeight===0||Mu0.has(y.message)||KO7(y,e)}}};
  g.Vv = function(f,a="ERROR"){var e={};e.name=g.gp("INNERTUBE_CONTEXT_CLIENT_NAME",1);e.version=g.gp("INNERTUBE_CONTEXT_CLIENT_VERSION");lp3(f,e,a)};
  g.S3 = function(f){g.Vv(f,"WARNING")};
  s9 = function(f,a,e=!1,T=""){!f&&e&&g.S3(Error(`Player URL validator detects invalid url. ${T}: ${a}`));return f};
  jd = function(f){return s9(T8(f,pO6,BIY),f,!1,"Trusted Stream URL")};
  M7 = function(f,a){this.B=this.j=null;this.K=f||null;this.A=!!a};
  g.U = M7.prototype;
  Gb = function(f,a){if(f){f=f.split("&");for(let e=0;e<f.length;e++){let T=f[e].indexOf("="),q,F=null;T>=0?(q=f[e].substring(0,T),F=f[e].substring(T+1)):q=f[e];a(q,F?ec(F):"")}}};
  r9 = function(f){f.j||(f.j=new Map,f.B=0,f.K&&Gb(f.K,function(a,e){f.add(ec(a),e)}))};
  vq = function(f,a){a=String(a);f.A&&(a=a.toLowerCase());return a};
  g.U.add = function(f,a){r9(this);this.K=null;f=vq(this,f);var e=this.j.get(f);e||this.j.set(f,e=[]);e.push(a);this.B=this.B+1;return this};
  g.U.remove = function(f){r9(this);f=vq(this,f);return this.j.has(f)?(this.K=null,this.B=this.B-this.j.get(f).length,this.j.delete(f)):!1};
  g.U.clear = function(){this.j=this.K=null;this.B=0};
  g.U.isEmpty = function(){r9(this);return this.B==0};
  g.U.forEach = function(f,a){r9(this);this.j.forEach(function(e,T){e.forEach(function(q){f.call(a,q,T,this)},this)},this)};
  g.U.ge = function(){r9(this);var f=Array.from(this.j.values()),a=Array.from(this.j.keys()),e=[];for(let T=0;T<a.length;T++){let q=f[T];for(let F=0;F<q.length;F++)e.push(a[T])}return e};
  EA0 = function(f,a){r9(f);a=vq(f,a);return f.j.has(a)};
  g.U.Ow = function(f){r9(this);var a=[];if(typeof f==="string")EA0(this,f)&&(a=a.concat(this.j.get(vq(this,f))));else{f=Array.from(this.j.values());for(let e=0;e<f.length;e++)a=a.concat(f[e])}return a};
  g.U.set = function(f,a){r9(this);this.K=null;f=vq(this,f);EA0(this,f)&&(this.B=this.B-this.j.get(f).length);this.j.set(f,[a]);this.B=this.B+1;return this};
  g.U.get = function(f,a){if(!f)return a;f=this.Ow(f);return f.length>0?String(f[0]):a};
  g.U.toString = function(){if(this.K)return this.K;if(!this.j)return"";var f=[],a=Array.from(this.j.keys());for(let T=0;T<a.length;T++){var e=a[T];let q=g.aw(e);e=this.Ow(e);for(let F=0;F<e.length;F++){let E=q;e[F]!==""&&(E+="="+g.aw(e[F]));f.push(E)}}return this.K=f.join("&")};
  g.U.clone = function(){var f=new M7;f.K=this.K;this.j&&(f.j=new Map(this.j),f.B=this.B);return f};
  g.PJ = function(f){var a=[],e=0;for(let T in f)a[e++]=T;return a};
  elY = function(f){if(f.ge&&typeof f.ge=="function")return f.ge();if(!f.Ow||typeof f.Ow!="function"){if(typeof Map!=="undefined"&&f instanceof Map)return Array.from(f.keys());if(!(typeof Set!=="undefined"&&f instanceof Set)){if(g.N6(f)||typeof f==="string"){let a=[];f=f.length;for(let e=0;e<f;e++)a.push(e);return a}return g.PJ(f)}}};
  UI = function(f){var a=[],e=0;for(let T in f)a[e++]=f[T];return a};
  aX0 = function(f){if(f.Ow&&typeof f.Ow=="function")return f.Ow();if(typeof Map!=="undefined"&&f instanceof Map||typeof Set!=="undefined"&&f instanceof Set)return Array.from(f.values());if(typeof f==="string")return f.split("");if(g.N6(f)){let a=[],e=f.length;for(let T=0;T<e;T++)a.push(f[T]);return a}return UI(f)};
  s_3 = function(f,a,e){if(f.forEach&&typeof f.forEach=="function")f.forEach(a,e);else if(g.N6(f)||typeof f==="string")Array.prototype.forEach.call(f,a,e);else{let T=elY(f),q=aX0(f),F=q.length;for(let E=0;E<F;E++)a.call(e,q[E],T&&T[E],f)}};
  g.U.extend = function(f){for(let a=0;a<arguments.length;a++)s_3(arguments[a],function(e,T){this.add(T,e)},this)};
  It = function(f,a){return f?a?decodeURI(f.replace(/%25/g,"%2525")):decodeURIComponent(f):""};
  g.nk = function(f,a,e){f.S=e?It(a,!0):a;f.S&&(f.S=f.S.replace(/:$/,""))};
  g.kl = function(f,a,e){f.j=e?It(a,!0):a};
  g.Wq = function(f,a){if(a){a=Number(a);if(isNaN(a)||a<0)throw Error("Bad port number "+a);f.K=a}else f.K=null};
  var qV7 = /[#\?@]/g;
  F01 = function(f){f=f.charCodeAt(0);return"%"+(f>>4&15).toString(16)+(f&15).toString(16)};
  Kk = function(f,a,e){return typeof f==="string"?(f=encodeURI(f).replace(a,F01),e&&(f=f.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f):null};
  g.HJ = function(f){var a=f.length;if(a>0){let e=Array(a);for(let T=0;T<a;T++)e[T]=f[T];return e}return[]};
  g.Hvg = function(f,a,e){f.remove(a);e.length>0&&(f.K=null,f.j.set(vq(f,a),g.HJ(e)),f.B=f.B+e.length)};
  T17 = function(f,a){a&&!f.A&&(r9(f),f.K=null,f.j.forEach(function(e,T){var q=T.toLowerCase();T!=q&&(this.remove(T),g.Hvg(this,q,e))},f));
f.A=a};
  ie = function(f,a,e){a instanceof M7?(f.A=a,T17(f.A,f.W)):(e||(a=Kk(a,qV7)),f.A=new M7(a,f.W))};
  g.t4 = function(f){this.j=this.C=this.S="";this.K=null;this.G=this.B="";this.W=!1;var a;f instanceof g.t4?(this.W=f.W,g.nk(this,f.S),this.C=f.C,g.kl(this,f.j),g.Wq(this,f.K),this.B=f.B,ie(this,f.A.clone()),this.G=f.G):f&&(a=g.Sq(String(f)))?(this.W=!1,g.nk(this,a[1]||"",!0),this.C=It(a[2]||""),g.kl(this,a[3]||"",!0),g.Wq(this,a[4]),this.B=It(a[5]||"",!0),ie(this,a[6]||"",!0),this.G=It(a[7]||"")):(this.W=!1,this.A=new M7(null,this.W))};
  g.Pq = function(f){return f instanceof g.t4?f.clone():new g.t4(f)};
  RL$ = function(f,a,e,T){var q=a^f;if(f-3>>3==1){let E=e[Q[q^3692]](Q[q^3669],q^3699),H=e[Q[q^3692]](Q[q^3669],E+1);E>0&&H>0?(T[Q[q^3702]]=e[Q[q^3689]](0,H),e=e[Q[q^3689]](H+1)):(T[Q[q^3702]]=e,e=Q[3]);var F=[e]}f-8<<2<f&&(f-6|27)>=f&&(F=e!==null);return F};
  GbN = function(f){return RL$[Q[6]](this,6,3272,f)};
  Lgq = function(){return m4[Q[6]](this,24,8692)};
  uk = function(f,a,e,T,q,F,E,H,C,A,y){var J=a^f,p;if(f-4>>3==2){var B=q[Q[5]];T[Q[J^3353]](function(w,P,O){this[Q[J^3386]](O[P]=q[(q[Q[J^3365]](w)-q[Q[J^3365]](this[P])+P+B--)%q[Q[5]]])},e[Q[J^3387]](Q[3]))}((f|8)&23)==4&&(p=T(q,F,E,H,C,A));
(f<<2&23)==4&&T[Q[5]]!=0&&(e=(e%T[Q[5]]+T[Q[5]])%T[Q[5]],T[Q[0]](0,1,T[Q[0]](e,1,T[0])[0]));f<<2>=17&&f+9<24&&(p=q(F,E,H,C,A,y));if(!(f>>1&14)){m4(J^7989,J^3142,e);let w=zC(1,J^549,e[Q[J^8023]](Q[J^7979])||Q[3])[Q[J^7964]](Q[J^7966]);p=e[Q[J^7960]]===Q[J^7975]&&w[Q[5]]>1&&!!w[1]}return p};
  aS1 = function(f,a){return uk[Q[6]](this,17,4551,f,a)};
  hQ = function(f,a,e,T,q){var F=a^f;if((f&88)==f){var E=e[T];let C=E[Q[F^5494]](Q[F^5408]);C>0?zC(F^5446,F^14309,q,E[Q[F^5491]](0,C),E[Q[F^5491]](C+1)):E&&(q[E]=Q[3]);var H=[]}if((f>>2&15)==3)for(e=(e%T[Q[5]]+T[Q[5]])%T[Q[5]];e--;)T[Q[F^3360]](T[Q[F^3337]]());f>>1&14||e[Q[5]]==0||(E=F2(64,172,T,e),T=E[0]);(f-9&11)==2&&e[Q[0]](e[Q[5]],0,T);(f|48)==f&&(e[4]!=(F^5718)&&(e[F^5704]<-(F^5721)?(0,e[F^5721])(e[F^5752],e[F^5724]):(0,e[F^5711])(e[F^5725])),e[F^5737]<=-3&&((0,e[F^5753])(((0,e[F^5699])(e[F^5633],
e[F^5722]),(0,e[F^5731])(e[F^5700],e[F^5725]),(0,e[F^5699])(e[F^5649],e[F^5734]),e[F^5721])(e[F^5739],e[F^5725]),e[F^5721],e[F^5652],e[F^5724]),Q[F^5738])||(0,e[F^5758])(((0,e[F^5701])(e[3],e[F^5725],(0,e[2])()),e[F^5701])(e[3],e[F^5729],(0,e[2])()),e[F^5710],(0,e[F^5701])(e[3],e[F^5649],(0,e[F^5742])()),e[F^5711],(0,e[F^5711])(e[F^5724]),e[new Date(Q[F^5754])/(F^5561)]),e[F^5743]>=(F^5720)&&(0,e[F^5721])(e[F^5698],e[F^5657]),e[F^5650]!=-(F^5720)&&(e[F^5702]<=4||((0,e[F^5731])(e[F^5743],e[F^5657]),
0))&&(0,e[F^5735])(e[F^5727]),e[F^5752]!=(F^5718)&&(e[F^5658]>-(F^5718)||(((0,e[F^5745])(e[F^5658],e[F^5749]),e[F^5731])(e[F^5650],e[F^5749]),0))&&(0,e[F^5649])((0,e[F^5757])(e[F^5706],e[F^5749],(0,e[5])()),e[F^5757],e[F^5706],e[F^5749],(0,e[F^5743])()),(e[F^5759]!=6||((0,e[F^5649])((0,e[F^5757])(e[F^5706],e[6],(0,e[F^5723])()),e[F^5757],e[F^5706],e[F^5657],(0,e[F^5723])()),0))&&(0,e[F^5649])((0,e[2])(e[F^5703],e[F^5724]),e[F^5757],e[F^5706],e[F^5657],(0,e[5])()),e[F^5736]!==4?(0,e[F^5734])((0,e[2])(e[F^
5727],e[F^5711])^(0,e[F^5649])((0,e[F^5659])(e[F^5721],e[F^5749]),e[F^5755],e[F^5749],e[F^5738]),e[F^5755],(0,e[new Date(Q[F^5633])/(F^5561)])(e[F^5748],e[new Date(Q[F^5649])/(F^5561)]),e[F^5749],e[F^5635]):(0,e[F^5734])((0,e[F^5702])(e[6]),e[F^5745],(0,e[F^5649])((0,e[F^5649])((0,e[F^5755])(e[F^5657],e[F^5726]),e[F^5659],e[F^5698],e[F^5703]),e[F^5725],e[F^5749],e[1]),e[F^5655],e[new Date(Q[F^5757])/(F^5561)]),e[F^5728]<=(F^5718)&&(e[F^5754]>-6?(0,e[F^5731])(e[F^5744],e[F^5727]):(0,e[F^5725])(e[F^
5657],e[F^5708])),e[F^5632]>new Date(Q[F^5659])/(F^5561)&&(e[F^5662]>3&&((0,e[F^5755])(e[6],e[F^5711]),[])||(0,e[new Date(Q[F^5656])/(F^5561)])(e[F^5705],e[F^5703])),e[F^5635]<-(F^5718)&&(e[F^5650]>=3&&((0,e[F^5649])(((0,e[F^5734])((0,e[F^5725])(e[6],e[F^5704]),e[F^5745],(0,e[F^5757])(e[F^5706],e[F^5657],(0,e[5])()),e[F^5740],e[F^5727]),e[F^5735])(e[F^5703]),e[F^5757],e[F^5706],e[F^5657],(0,e[F^5707])()),1)||((0,e[F^5649])((0,e[F^5755])(e[F^5657],e[F^5753]),e[F^5755],e[F^5748],e[F^5632]),((0,e[F^
5731])(e[F^5733],e[F^5748]),e[F^5759])(e[F^5738]),e[F^5648])(e[F^5741],e[F^5711])),e[F^5706]>-(F^5718)?(0,e[F^5663])((0,e[F^5663])(((0,e[F^5724])(e[F^5633],e[F^5708]),e[F^5734])(e[F^5652],e[F^5708]),e[F^5656],(0,e[F^5734])(e[F^5657],e[F^5756]),e[F^5743],e[F^5756]),e[F^5751],(0,e[F^5663])(e[F^5657],e[F^5723]),e[F^5698],e[F^5708]):((0,e[F^5759])(((0,e[F^5727])(e[F^5635],e[F^5657]),e[5])(e[F^5735]),e[F^5663],e[F^5699],e[F^5746]),(0,e[F^5707])(e[F^5720],e[F^5657],(0,e[F^5721])()),(0,e[F^5727])(e[F^5743],
e[F^5735]),e[F^5663])(e[F^5699],e[3]),H=[]);(f|104)==f&&e[Q[0]](e[Q[5]],0,T);return H};
  e7o = function(f,a){return hQ[Q[6]](this,1,7466,f,a)};
  Diw = function(f,a,e){return uk[Q[6]](this,20,3362,f,a,e)};
  y0T = function(f,a){return hQ[Q[6]](this,12,3382,f,a)};
  yhN = function(f,a,e){var T=a^f;if((f-7^19)>=f&&f+5>>1<f){for(var q=T^2025,F=[];++q-F[Q[5]]-(T^1929);)switch(q){case T^1927:q=T^2038;default:F[Q[T^1957]](String[Q[T^1977]](q));case T^2039:case T^2038:case T^1993:break;case T^2002:q-=T^2021;case T^2037:case T^2036:continue;case T^1939:q=T^1925;case T^2034:}var E=F}if(f+5>=-47&&(f>>1&8)<7)for(q=e[Q[5]];q;)e[Q[T^1007]](e[Q[0]](--q,1)[0]);return E};
  g_T = function(f){return yhN[Q[6]](this,1,994,f)};
  nyq = function(f,a,e,T,q,F){return zC[Q[6]](this,7,989,f,a,e,T,q,F)};
  Vp0 = function(f,a){return S4[Q[6]](this,94,6368,f,a)};
  SZq = function(f,a,e,T,q,F,E,H,C){return uk[Q[6]](this,5,4499,f,a,e,T,q,F,E,H,C)};
  Jhw = function(){return yhN[Q[6]](this,16,1977)};
  gS = function(f,a,e,T,q,F,E){var H=a^f;if((f+1&15)>=3&&(f<<2&7)<4){for(var C=H^2626,A=[];++C-A[Q[5]]-(H^2594);){switch(C){case H^2649:C=H^2606;continue;case H^2681:C=H^2627;break;case H^2627:C-=H^2576;continue;case H^2616:C=H^2658;continue;case H^2604:C=H^2653}A[Q[H^2574]](String[Q[H^2578]](C))}var y=A}(f&123)==f&&(y=encodeURIComponent(e));(f|8)==f&&(y=T(q,F,E));return y};
  FtT = function(f,a,e,T,q){return gS[Q[6]](this,13,3050,f,a,e,T,q)};
  KMq = function(f,a,e,T,q,F,E,H){return uk[Q[6]](this,4,6702,f,a,e,T,q,F,E,H)};
  adg = function(f,a){return jY[Q[6]](this,4,7885,f,a)};
  XJN = function(){return gS[Q[6]](this,4,2566)};
  ZVN = function(f,a,e,T,q,F,E){return F2[Q[6]](this,1,8112,f,a,e,T,q,F,E)};
  r2w = function(f,a){return hQ[Q[6]](this,11,6488,f,a)};
  OZY = function(f,a){return hQ[Q[6]](this,104,6746,f,a)};
  gd$ = function(){return jY[Q[6]](this,64,589)};
  olq = function(){return S4[Q[6]](this,17,5768)};
  uQT = function(f,a){return F2[Q[6]](this,20,2174,f,a)};
  Hj = function(f,a,e){var T;((f|1)&5)==1&&e[Q[17]]();(f-9&8)<7&&(f|6)>=-66&&(T=e[Q[11]]?e[Q[11]][Q[31]](Q[33]):e[Q[18]]===Q[33]);return T};
  DuT = function(f){return Hj[Q[6]](this,1,1287,f)};
  var RQ6 = -1857625759;
  var YD7 = {};
  jY = function(f,a,e,T){var q=a^f;if((f|3)>>4==4){for(var F=q^589,E=[];++F-E[Q[5]]-(q^557);)switch(F){case q^567:F=q^621;continue;case q^598:F=q^545;break;case q^588:F=q^546;continue;case q^547:F=q^660;case q^630:F-=q^567;default:E[Q[q^513]](String[Q[q^541]](F))}var H=E}f-8<<2<f&&(f-4|64)>=f&&(e=(e%T[Q[5]]+T[Q[5]])%T[Q[5]],T[Q[0]](-e)[Q[q^7896]]()[Q[q^7910]](function(A){T[Q[q^7891]](A)}));
if((f|48)==f)a:{F=e[Q[q^7984]](Q[3]);E=[q^1920152728,-(q^499314009),Lgq,Q[q^7985],-(q^1286203158),q^557693005,-(q^1658690353),q^673054969,aS1,q^1937056082,q^1387315964,-(q^1117830414),F,null,q^1667614073,-(q^1070826148),-(q^760278111),-(q^224224581),e7o,-(q^733352420),Diw,q^1387315964,q^1122614800,q^1773736149,q^178137575,q^949533420,y0T,-(q^264386453),q^1952753806,-(q^510742047),g_T,nyq,Vp0,q^1332059218,SZq,-(q^276603761),-(q^1000383259),q^654210841,Jhw,Q[q^7987],FtT,-(q^292831059),/(\/(,)[\)[},/]}\/)/,
-(q^1654706374),q^629765501,q^1969778742,q^418926840,KMq,F,-(q^714041236),adg,-(q^377239354),XJN,ZVN,q^1268572875,-(q^1433501119),-(q^2055401103),q^374925330,-(q^1006431799),-(q^92520202),r2w,OZY,q^1924726161,gd$,F,-(q^551617757),q^1551097197,-(q^1263320326),olq,q^888480494,uQT,-(q^1187146089),null,-(q^835137928),-(q^889855007),q^673054969,q^277524160,-(q^1358227255),-(q^655903793),-(q^1244328302),null,DuT];E[q^7984]=E;E[q^8053]=E;E[q^8045]=E;if(typeof RQ6===Q[q^7974]){H=e;break a}try{try{E[q^7940]!=
(q^7988)&&(E[q^7978]<=(q^7994)&&((0,E[q^7951])(E[q^7947],E[q^8053])===((0,E[q^7983])(E[q^8061],E[q^7948]),E[q^7977])(E[3],E[q^7985],(0,E[q^7945])()),/",/)||(0,E[q^7957])(((0,E[q^7983])(E[q^8045],E[q^7980]),E[q^7983])(E[q^7949],E[q^7953]),E[q^7975],E[q^7978],E[q^7949]))}catch(A){(0,E[q^7951])(E[q^7974],E[q^8045])}finally{var C=hQ(q^7949,q^2396,E)}try{E[q^7977]>-(q^7989)&&(E[q^7974]<(q^7988)||((0,E[q^7960])((0,E[q^7955])((0,E[q^7941])(E[q^8054],E[q^8045]),E[q^7961],E[q^7949],E[q^7968]),E[q^7961],(0,E[q^
7989])((0,E[q^8062])(E[q^7944],E[q^8058]),(0,E[q^7987])((0,E[q^7955])(E[q^8058],E[q^8046]),E[q^8062],E[q^7946],E[q^7949]),E[q^7987],(0,E[q^7973])(E[q^8052],E[q^7940]),E[q^7959],E[q^7969],E[4]),E[q^8061],E[q^7980]),Q[3]))&&(0,E[q^7958])(E[q^7988],(0,E[q^7988])(E[q^8051],E[1],(0,E[q^8048])()),(0,E[q^7939])(E[2],E[q^7951]),(0,E[q^7971])((0,E[q^7977])(E[2]),E[q^7988],E[q^8051],E[q^7963],(0,E[q^8048])()),E[q^8051],E[1],(0,E[q^7937])())%(0,E[q^7971])((0,E[q^7971])((0,E[q^7988])(E[q^8051],E[q^7963],(0,E[q^
7946])()),E[q^8055],E[2]),E[q^7988],E[q^8051],E[q^7963],(0,E[q^7946])())}catch(A){(0,E[q^7988])(E[q^8051],E[q^7963],(0,E[q^7946])())}}catch(A){H=Q[q^8048]+e;break a}H=F[Q[q^7960]](Q[3])}(f&42)==f&&(F=jY(q^7791,q^338,e),T[Q[q^7765]](Q[q^7768],F),H=[]);if((f>>2&31)>=13&&(f-9&16)<6)a:{E=g.Y(e,YD7)||e[Q[q^3738]];F={hA:!1,eN:Q[3],yR:Q[3],s:Q[3]};if(!E){H=F;break a}E=ct(E);F[Q[q^3718]]=!0;F[Q[q^3721]]=E[Q[q^3747]];F[Q[q^3836]]=E[Q[q^3828]];F[Q[q^3755]]=E[Q[q^3755]];H=F}return H};
  S4 = function(f,a,e,T){var q=a^f;f-8<<2>=f&&(f-6|91)<f&&e[Q[12]](T);if(((f^99)&15)>=3&&f<<1<16){m4(q^7803,q^3336,e);var F=e[Q[1]]}if(f-1>>3==2){for(var E=q^5849,H=[];++E-H[Q[5]]-(q^5817);){switch(E){case q^5826:E=q^5813;continue;case q^5858:E=q^5848;break;case q^5848:E-=q^5771;continue;case q^5795:E=q^5881;continue;case q^5815:E=q^5830}H[Q[q^5781]](String[Q[q^5769]](E))}F=H}(f^78)>>3||(m4(q^973,q^4286,e),F=g.i0(e[Q[q^974]],GbN));(f|56)==f&&(m4(q^3869,q^7278,e),(E=e[Q[q^3890]][Q[q^3862]]||null)&&(E=
jY(2,q^4428,E,e)),F=[]);return F};
  var E6 = {il:function(f,a){var e=f[0];f[0]=f[a%f[Q[5]]];f[a%f[Q[5]]]=e},
UA:function(f,a){f[Q[0]](0,a)},
Jj:function(f){f[Q[17]]()}};
  zC = function(f,a,e,T,q,F,E,H){var C=a^f,A;(f&69)==f&&(A=decodeURIComponent(e));if((f&122)==f){m4(C^2658,C^6417,e);var y=e[Q[C^2680]]+(e[Q[C^2680]]?Q[2]:Q[C^2596])+e[Q[1]]+e[Q[C^2659]];if(S4(C^2594,C^2511,e)){let J=[];g.w_(e[Q[C^2633]],(p,B)=>{p!==null&&J[Q[C^2662]](`${B}=${p}`)});
y+=`?${J[Q[C^2639]](Q[C^2653])}`}A=y}f-4<<2>=f&&(f-2^32)<f&&(T===Q[C^8943]&&((y=q[Q[C^8880]](Q[C^8934]))>=0?(T=`cmo=${q[Q[C^8885]](0,y)}`,q=q[Q[C^8885]](y+1)):(y=q[Q[C^8880]](Q[C^8842]))>=0&&(T=`cmo=${q[Q[C^8885]](0,y)}`,q=q[Q[C^8885]](y+3))),e[T]=q);(f-2^16)<f&&(f-4^11)>=f&&(y=e[Q[C^8043]](Q[3]),E6[Q[C^8059]](y,C^8027),E6[Q[C^8014]](y,C^8046),E6[Q[C^8062]](y,2),E6[Q[C^8014]](y,C^8051),E6[Q[C^8062]](y,3),E6[Q[C^8059]](y,C^8010),E6[Q[C^8014]](y,C^7975),E6[Q[C^8062]](y,2),E6[Q[C^8014]](y,C^8013),A=
y[Q[C^8003]](Q[3]));(f|7)>=5&&(f+9&8)<2&&(A=T(F,E,H));return A};
  F2 = function(f,a,e,T,q,F,E,H,C){var A=a^f,y;(f^15)>>4||(y=e(E,H,C));if((f|64)==f){e=(e%T[Q[5]]+T[Q[5]])%T[Q[5]];var J=T[0];T[0]=T[e];T[e]=J;y=[e]}if((f|48)==f){J=e[Q[A^4393]](Q[A^4366]);let p=0;J[0]||p++;let B={};for(;p<J[Q[5]];p+=2)J[p]&&zC(A^4352,A^13219,B,J[p],J[p+1]);y=B}(f+4^9)<f&&(f-5^16)>=f&&(T=(T%e[Q[5]]+e[Q[5]])%e[Q[5]],e[Q[0]](T,1));return y};
  zp = function(f,a,e){var T=a^f;if((f&122)==f){if(!(jd(e[Q[T^5934]])||e[Q[T^5934]][Q[T^5946]](Q[T^5892])||e[Q[T^5934]][Q[T^5946]](Q[T^6001])||e[Q[T^5934]][Q[T^5946]](Q[T^6006])))throw new g.vc(Q[T^6007],e[Q[T^5934]]);var q=g.Pq(e[Q[T^5934]]);e[Q[T^5943]]=q[Q[T^5895]];e[Q[1]]=q[Q[T^5894]]+(q[Q[1]]!=null?`:${q[Q[1]]}`:Q[3]);var F=q[Q[T^5934]];F[Q[T^5946]](Q[T^5907])?(e[Q[T^5932]]=Q[T^5907],F=F[Q[T^5939]](T^5931)):F[Q[T^5946]](Q[T^5911])?(e[Q[T^5932]]=Q[T^5911],F=F[Q[T^5939]](T^5928)):F[Q[T^5946]](Q[T^
5913])?(F=RL$(T^5934,T^6481,F,e),F=F[0]):(e[Q[T^5932]]=F,F=Q[3]);var E=e[Q[T^5894]];e[Q[T^5894]]=F2(T^5909,T^1585,F);Object[Q[T^5985]](e[Q[T^5894]],zp(T^5948,T^7579,q[Q[T^5986]][Q[T^5912]]()));Object[Q[T^5985]](e[Q[T^5894]],E);e[Q[T^5894]][Q[T^5914]]===Q[T^5917]&&(delete e[Q[T^5894]][Q[T^5914]],e[Q[T^5932]]+=Q[T^6004]);e[Q[T^5934]]=Q[3];e[Q[T^5937]]=Q[3];e[Q[T^5986]]&&(q=S4(T^5917,T^6156,e));var H=[]}if((f^23)>>3==1){q=e[Q[T^2730]](Q[T^2704]);F={};for(E=0;E<q[Q[5]];E++)var C=hQ(T^2735,T^8138,q,E,
F);H=F}return H};
  m4 = function(f,a,e){var T=a^f;if((f&44)==f&&e[Q[11]])var q=zp(2,5927,e);if((f|24)==f){q=T^8620;for(var F=[];++q-F[Q[5]]-(T^8652);){switch(q){case T^8662:q-=T^8674;case T^8631:case T^8624:case T^8625:continue;case T^8599:q=T^8643;case T^8626:case T^8627:case T^8588:continue;case T^8642:q=T^8627}F[Q[T^8672]](String[Q[T^8700]](q))}var E=F}return E};
  g.b0 = function(f){var a={};for(let e in f)a[e]=f[e];return a};
  g.Te = class{constructor(f,a=!1){this[Q[11]]=f;this[Q[71]]=a;this[Q[18]]=Q[3];this[Q[9]]=Q[3];this[Q[1]]=Q[3];this[Q[35]]={};this[Q[20]]=Q[3]}set(f,a){this[Q[35]][f]!==a&&(this[Q[35]][f]=a,this[Q[20]]=Q[3])}get(f){m4(4,4983,this);return this[Q[35]][f]||null}dN(){this[Q[20]]||(this[Q[20]]=zC(2,2664,this));return this[Q[20]]}clone(){var f=new g.Te(this[Q[11]],this[Q[71]]);f[Q[18]]=this[Q[18]];f[Q[9]]=this[Q[9]];f[Q[1]]=this[Q[1]];f[Q[35]]=g.b0(this[Q[35]]);f[Q[20]]=this[Q[20]];return f}};
  Xx = function(f,a="",e=""){f=new g.Te(f,!0);f.set("alr","yes");e&&(e=zC(20,8050,zC(5,7472,e)),f[Q[10]](a,gS(1,1150,e)));return f};
  //#endregion --- end [nsigFunction] ---

  function nsigFunction(f, a, e) {
    return Xx(f, a, e);
  }

  const rawValues = {
    "nsigFunction": "Xx",
    "signatureTimestampVar": "20740"
  };

  return { nsigFunction, rawValues };
})({});

function process(n = "", sp = "", s = "") {
  const mockStreamingURL = "https://ytjs.googlevideo.com/videoplayback?expire=1234567890&"+"n="+encodeURIComponent(n);
  const urlCtorFunction = exportedVars.nsigFunction || (() => { throw new Error('No n/sig decipher function extracted') });
  const urlCtor = urlCtorFunction(mockStreamingURL, sp, s);

  const proto = Object.getPrototypeOf(urlCtor);
  const properties = Object.getOwnPropertyNames(proto);
  const methodBlacklist = ['constructor', 'clone', 'set', 'get'];

  for (const prop of properties) {
    if (methodBlacklist.includes(prop))
      continue;

    if (typeof urlCtor[prop] === 'function')
      urlCtor[prop]();
  }

  const sigResult = urlCtor.get(sp);
  const nResult = urlCtor.get('n');

  return {
    sig: sigResult ? decodeURIComponent(sigResult) : undefined,
    n: nResult ? decodeURIComponent(nResult) : undefined
  };
}


const request=JSON.parse(std.in.getline());
print(JSON.stringify(process(request.n||"",request.sp||"",request.sig||"")));

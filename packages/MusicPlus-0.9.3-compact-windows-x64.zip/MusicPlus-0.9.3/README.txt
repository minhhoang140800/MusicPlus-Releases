Music Plus 0.9.3 — Windows x64

Fix Album / Plays columns and numeric K/M/B sorting.
Selectable playing artist; triple click selects complete text. No title hover background/tooltip.
Underline only hovered artist; cursor Arrow on hover, I-beam while selecting.
Single artist/album link click waits briefly to distinguish double/triple selection clicks.

Update via Settings > Check for updates, or close the app completely and overwrite with this ZIP.
Data remains in %LOCALAPPDATA%\MusicPlus8.
Build and 43 fixture/policy checks passed. Live Windows interaction still needs real-device testing.

# Music Plus 1.0.6

Windows x64, .NET Framework 4.8 và WebView2 Runtime. Source chỉ ở GitHub private;
repo public MusicPlus-Releases chỉ chứa gói chạy, checksum, manifest và release notes.

## Cài một lần

1. Thoát Music Plus cũ, kể cả khay hệ thống.
2. Giải nén toàn bộ ZIP vào thư mục bạn có quyền ghi, ví dụ `D:\MusicPlus`.
3. Luôn mở `MusicPlus.exe` ở thư mục ngoài cùng. Có thể tạo shortcut tới file này.

Giữ nguyên thư mục `versions` và `current.json`; không chỉ chép riêng exe bên trong ra ngoài.
Không dùng thư mục Program Files cần quyền admin. Không xoá `%LOCALAPPDATA%\MusicPlus8`:
đăng nhập, settings, metadata, thứ tự Library vẫn ở đó. Không gửi dữ liệu đăng nhập cho người khác.
Từ các bản <=1.0.1 cần cài gói này một lần vì đổi cấu trúc cài đặt.

## Cập nhật qua GitHub

Trong Settings bấm **Check for updates**. App kiểm tra stable `update.json`, tải ZIP và kiểm
SHA-256, đủ dependencies, từng file, đường dẫn và version. Nếu có bản mới, app chuẩn bị nó
trong `versions/<version>` rồi khởi động lại. Không cần tải/giải nén thủ công mỗi bản nữa.
Không có tiến trình updater chạy nền thường trực hoặc GitHub token trên máy người dùng.

File ngoài cùng là launcher cố định cho layout `versioned-v1`. Khi cài bản mới, launcher chờ
app cũ đóng và chờ bản mới báo giao diện đã khởi tạo. Chỉ sau đó mới đổi `current.json`
atomic và giữ Previous. Nếu bản mới lỗi lúc khởi động, launcher mở lại bản cũ. Nếu mất điện
sau khi chuẩn bị, lần mở tiếp theo xử lý transaction đang dở. Không chép đè file app đang chạy.
Cơ chế này kiểm tra khởi tạo, không bảo đảm phát hiện mọi lỗi xảy ra sau khi app đã mở.
Các bản app/dependencies tương thích layout v1 dùng được cùng launcher; thay runtime hoặc
protocol launcher ngoài v1 có thể cần gói cài mới.

Manifest dùng TLS và checksum trên GitHub. SHA-256 bảo vệ tính toàn vẹn, không thay thế
chữ ký nhà phát hành. Chưa có Authenticode. Source/build recipe native audio engine còn thiếu.

## Clear unused cache

Settings có nút xoá cache không dùng: ảnh cache, audio không được bảo vệ cho bài đang phát/
chuẩn bị, phiên bản cũ hơn bản dùng để rollback, staging thất bại và ZIP updater cũ.
Không xoá sign-in, settings, metadata, ảnh cover tự sửa, file tải đang dở, phiên bản hiện tại,
Previous hoặc pending version. File bị Windows khoá sẽ được bỏ qua. Clear không chạy lúc update.
Giữ Previous giúp cập nhật lỗi có thể quay về; vì vậy nút này không xoá toàn bộ dữ liệu trên đĩa.

## Tính năng được giữ

Copy/select title/artist/album và Lyrics; flyout giữ metadata khi pause. Ctrl/Shift nhiều bài,
Add picker có ảnh một click, cảnh báo trùng, link search, Back search, Lyrics, Library order,
Views/Artist/Album theo màn hình. Các sửa queue, session và mutation từ 1.0.0 được giữ.

## Build / kiểm chứng

`global.json` ghim SDK. Windows: `./Build.ps1` tạo ZIP versioned và checksum.
Portable: `dotnet run --project tests/tests.csproj -f net8.0 -c Release`.
Framework thật: build tests/tests.csproj -f net48 rồi chạy tests.exe trên Windows.
Windows storage/WPF: tests-windows/windows.csproj.
Launcher: `dotnet build launcher/launcher.csproj -f net48 -c Release`.
Process recovery test: build launcher -f net8.0, chạy tests/installer-process-test.py với dotnet
và đường dẫn output net8. Test dùng executable giả; không dùng tài khoản hoặc mạng.

118 portable checks và 14 launcher process checks đạt trên Linux; app, launcher và Windows
tests cross-build được. Chưa chạy vòng restart/update WPF net48 thật trên Windows.
Chưa benchmark RAM/latency; cold audio vẫn tải/remux toàn bài. Giữ các giới hạn Free/native
engine và đồng bộ playlist đã ghi ở CHANGELOG-1.0.0.md. Nguồn runtime: DEPENDENCIES.md.

## 1.0.3

Clear cache chỉ báo “Cleared … MB of unused cache.” với icon thông tin. Nút X Settings dùng icon vector căn giữa, không phụ thuộc glyph/font hoặc padding của theme. Cập nhật từ 1.0.2 qua Settings. Build/portable checks đạt; giao diện chưa chạy thực tế trên Windows trong môi trường build.

## 1.0.4

Update check dùng GitHub API với no-cache, fallback raw khi API không truy cập được. Hiển thị phiên bản được kiểm tra, ghi log source/installed/offered/HTTP/age. Metadata thấp hơn bản đang dùng không được báo latest; nếu chỉ dùng raw, trạng thái nói rõ phiên bản GitHub trả về thay vì khẳng định mới nhất. API không cần token, chỉ gọi khi bấm nút; có thể chịu rate limit GitHub.

Kiểm chứng 1.0.4: 130 portable checks gồm API success, API rate-limit fallback, no-cache headers, decode manifest, so sánh 1.0.2→1.0.3/1.0.4 và từ chối metadata cũ. Chưa chạy kiểm tra mạng/updater từ máy Windows của người dùng trong môi trường này.

## 1.0.5 — phục hồi lỗi chuyển bài

401/403 trong luồng audio được làm mới link, player configuration và playback HTTP transport rồi thử lại đúng một lần. Không xoá session hoặc tự retry thao tác playlist. Cả next thủ công, auto-next và prefetch dùng chung luồng; task prefetch lỗi không bị giữ để dùng lại. Link cache theo expire của URL (trừ 30 giây), client config RAM/disk hết hiệu lực sau 30 phút. Cache audio đã chuẩn bị vẫn dùng đường nhanh. Ghi log stage/status/attempt, không ghi signed URL/cookies.

150 portable checks đạt, gồm retry thành công, chặn retry vô hạn, cancellation/account change, client lifetime, transport lease retirement và HTTP 403 từ downloader thật với fake server handler. Framework/Windows test projects build được; chưa tái hiện 403 bằng tài khoản thật hoặc chạy WPF playback trên Windows. Không khẳng định mọi 403 đều do cache hoặc mọi giới hạn server đều được giải quyết.

## 1.0.6 — loading latency regression

Play/Space trong lúc chuẩn bị không còn huỷ bài; nút hiển thị dấu đang tải và tạm khoá,
chọn bài khác/Next vẫn dùng được. Bỏ semaphore chung toàn bộ pipeline giữa foreground và
prefetch; từng resolver giữ lane riêng, recovery chỉ reset resolver của chính nó. Giữ config
vừa refresh khi có thêm recovery trong một phút, trừ khi config thiếu/hết hiệu lực.
Request range phụ có hạn chờ/idle 2 giây; nếu kẹt thì tiếp tục đọc response chính. Có tiến
triển thì gia hạn, không giới hạn toàn bộ một lượt tải khỏe mạnh ở 2 giây. Logs thêm thời gian
chờ lane, header và fallback range. Không tăng timeout chung hoặc thay engine/native remux.

162 portable checks đạt, app/framework/Windows test projects build được. Windows smoke
checks có ca Play lúc đang tải không huỷ CTS nhưng chưa chạy ở Linux. Chưa benchmark tốc độ
live Windows; cold audio vẫn phải tải toàn bài. Source/data cá nhân giữ nguyên.

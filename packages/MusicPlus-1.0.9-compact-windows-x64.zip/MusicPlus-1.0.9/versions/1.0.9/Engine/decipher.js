const __jsExtractorGlobal = typeof globalThis !== 'undefined' ? globalThis :
  typeof self !== 'undefined' ? self :
  typeof window !== 'undefined' ? window :
  typeof global !== 'undefined' ? global : {};

const exportedVars = (function(g) {
  const window = typeof __jsExtractorGlobal.window !== 'undefined' ? __jsExtractorGlobal.window : Object.create(null);
  const document = typeof __jsExtractorGlobal.document !== 'undefined' ? __jsExtractorGlobal.document : {};
  const self = typeof __jsExtractorGlobal.self !== 'undefined' ? __jsExtractorGlobal.self : window;

  var mI, w, ay, by, cy, Jz, Iz, Kqa, Jqa, Bp, Baa, fd, hd, Os, lpa, Ns, kpa, Ms, Ls, Ks, fpa, gpa, ipa, Qqa, daa, Na, Nka, hdb, Hha, qf, Fha, xl, g_, Pna, Xt, I_, $s, Hqa, dqa, Bt, Ct, gh, bh, Nf, dh, Rg, Pg, sh, Qg, sg, rg, eh, Ng, Rf, Mg, Jg, Vba, Lg, Kg, Jf, If, Cf, oba, Eg, Xa, Kba, Mf, ed, zg, wg, Dg, Iba, yg, Zg, Rba, Ja, Tba, Hg, Gg, Lba, qe, Dt, $pa, Sr, Tr, Ur, Vr, Hna, cr, On, lo, jo, ko, mo, cia, Ik, Jk, djb, ejb, fjb, np, Hla, hp, Mr, Fna, Cna, Pr, xr, Xma, sr, Qma, rr, Nma, Mma, Pma, qr, Oma, Zma, Ar, tr, $ma, mr, dna, zr, Or, xna, ir, qna, pna, nna, Lr, mna, vc, lq, kq, rq, qq, rd, jna, hna, gna, fna, ur, nr, jr, sd, yc, wc, xc, Lma, Wma, Yma, hr, er, gr, Vma, Er, Rma, ina, gjb, Hr, ona, Uq, rna, sna, vna, Jna, zna, Gna, Bna, Lna, Wr, Ina, Ana, Yq, Wq, Gla, bt, gt, ct, ypa, et, xpa, zpa, Apa, ft, aqa, bqa, zt, rt, ut, tt, wt, Upa, Wpa, Ft, hqa, Ep, Fp, Qna, Kq, ih, dca, Hba, Yba, Og, Wba, vh, Lf, Sg, lh, gca, tg, xba, Rna, jg, Vg, Tg, Ug, Of, Zba, Wg, Xg, Tf, uh, Sna, mg, gg, Aba, Wf, Bba, $f, Zf, vba, ag, Tna, ph, Una, Gma, Ema, Ima, Vna, Ona, Ena, qp, op, Ila, kd, Ka, Mq, Ama, qqa, rqa, sqa, Ut, yqa, tqa, uqa, Mna, Nna, Pt, Qt, coa, zma, vga, rga, qga, lga, tga, oga, nga, pga, mga, uga, sga, tp, Lla, Mi, Li, Mp, Xla, Yla, ida, zp, bma, fma, ema, gma, Tc, Ec, vaa, Dc, pc, cma, Kp, Sla, Tla, vp, Ii, up, Ula, yp, Ola, uda, Vd, hba, lf, bba, ef, te, xka, Xe, Dla, pp, ls, ioa, tla, Wo, kla, Io, Ho, Xka, Wka, so, ola, pla, qla, to, Yka, Vo, Ro, Mo, fla, Eo, xo, ala, dla, vo, uo, ela, wo, bla, $ka, Zka, Jo, Uo, So, hla, Fo, To, Vka, ks, gs, fs, zs, Ooa, wka, gn, gl, il, xha, fl, jl, ll, yha, ml, zha, Cha, dl, ol, Aha, el, Dha, sl, ws, us, Poa, Noa, K_, Aoa, qs, toa, ps, yr, zoa, woa, uoa, xoa, yoa, voa, Soa, Ioa, Tfa, wk, vk, Si, Qi, Hoa, Moa, Boa, una, lna, kna, tna, As, poa, ms, os, soa, qoa, roa, Eoa, Doa, Roa, Foa, yl, Rha, Tha, Gl, ab, Kha, Nha, Al, Iha, El, Uha, Sha, Oha, Pha, Qha, Vha, cqa, Gt, gqa, Ht, Nt, kqa, iqa, Zna, ig, qh, dg, nh, jh, Bma, hg, zba, vqa, wqa, th, Tpa, Spa, Zo, Gc, Hc, xqa, Ypa, Jt, Rpa, kt, jt, Epa, Fpa, Hpa, Lpa, Kpa, Opa, Mpa, Npa, mt, Jma, Jpa, Ipa, ot, It, jp, Iqa, Km, Om, Ki, Pm, Pja, Lja, Kja, Jja, Ub, Jm, Im, Lm, Oja, Mja, dy, ey, lc, hha, Rga, bl, IH, Sga, Tga, raa, Uga, Qr, tH, KWa, Vga, Wga, ija, Xga, Yga, Zga, $ga, aha, bha, cha, dha, eha, fha, Mj;

  //#region --- start [nsigFunction] ---
  w = "/initplayback{/file/index.m3u8{A{path{length{call{set{{indexOf{toString{n{join{/videoplayback{/{B{mn{j{file{www.youtube.com{&{http://local{split{startsWith{splice{get{C{1970-01-01T05:45:08.000+05:45{redirector.googlevideo.com{\\.a1\\.googlevideo\\.com${TP{%3D{slice{push{rr?[1-9].*\\.c\\.youtube\\.com${1{scheme{cmo=pf{pJ{fromCharCode{unshift{pop{cmo{s{match{fallback_count{url{1970-01-01T06:00:03.000+06:00{1969-12-31T15:00:49.000-09:00{1970-01-01T07:00:02.000+07:00{finally{forEach{undefined{1970-01-01T04:15:04.000+04:15{rr{\\.googlevideo\\.com${gf{reverse{={assign{DH{,53];c[54]=c;{,{a1.googlevideo.com{local{1970-01-01T01:59:52.000+02:00{1970-01-01T02:47:49.000+02:45{AD{index.m3u8{clone{signatureCipher{1969-12-31T12:46:10.000-11:15{/}';}],{,;,)[\u00b8{SX7T5EqvRPwoqIB3d3-_w8_{1970-01-01T01:46:25.000+01:45{let{youtube.player.web_20261115_00_RC00{sp{://{D{AF{fvip{1969-12-31T16:16:10.000-07:45{playerfallback{1969-12-31T22:31:17.000-01:30{replace{https://local{cmo=td{Untrusted URL{1970-01-01T05:15:41.000+05:15{VLDJ_-2{r{rZ{/api/manifest{//".split("{");
  by = function(a,b,c,d,e,f,h,k,l,m,p,q){var u=b^a,v;if(a>>2>=-35&&a+7>>4<1){if(d===w[u^5379]){var z;(z=e[w[u^5410]](w[u^5395]))>=0?(d=`cmo=${e[w[u^5429]](0,z)}`,e=e[w[u^5429]](z+1)):(z=e[w[u^5410]](w[u^5428]))>=0&&(d=`cmo=${e[w[u^5429]](0,z)}`,e=e[w[u^5429]](z+3))}c[d]=e}if((a>>1&14)==4)for(z=c[w[4]];z;)c[w[u^8732]](c[w[u^8747]](--z,1)[0]);(a-9&23)==3&&(v=d(h,k,l,m,p,q));a-5<<1>=a&&(a-1|42)<a&&(v=d(f,h,k));if((a<<2&15)>=12&&(a^86)>>5<3){z=c[w[u^3821]](w[u^3819]);let L={};for(let N=0;N<z[w[4]];N++)var F=
ay(u^3816,u^7128,z,N,L);v=L}return v};
  g.Vq = class extends Error{constructor(a,...b){super(a);this.args=[...b];Object.setPrototypeOf(this,new.target.prototype)}};
  var fxa = RegExp("^((http(s)?):)?\\/\\/((((lh[3-6](-tt|-d[a-g,z])?\\.((ggpht)|(googleusercontent)|(google)|(sandbox\\.google)))|(lh7\\-(eu|us|qw|rt|xx|ty)\\.((googleusercontent)|(google)))|((photos|testonly|work)\\.fife\\.usercontent\\.google)|([\\w\\-]+\\.fife\\.usercontent\\.google)|(([1-4]\\.bp\\.blogspot)|(bp[0-3]\\.blogger))|(ccp-lh\\.googleusercontent)|((((cp|ci|gp)[3-6])|(ap[1-2]))\\.(ggpht|googleusercontent))|(gm[1-4]\\.ggpht)|(play-(ti-)?lh\\.googleusercontent)|(gz[0-1]\\.googleusercontent)|(lh3\\-gm\\.google)|(((yt[3-4])|(sp[1-3]))\\.(ggpht|googleusercontent)))\\.com)|(drive\\.google\\.com\\/drive\\-(usercontent|viewer))|(dp[3-6]\\.googleusercontent\\.cn)|(dp4\\.googleusercontent\\.com)|((photos|drive|contribution)\\-image\\-(dev|qa)(-us|-eu)?(-auth|-cookie)?\\.corp\\.google\\.com)|(photos\\-image\\-dev\\-dl\\-(auth|eu|us)\\.corp\\.google\\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\\.sandbox\\.google\\.com\\/image)|(image\\-(dev|qa)\\-lighthouse(-auth)?\\.sandbox\\.google\\.com(\\/image)?)|(drive\\-qa\\.corp\\.google\\.com\\/drive\\-(usercontent|viewer))|(docs(\\-(dev|qa)\\.corp)?\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|brands|email\\-layouts)\\-images\\-(rt|qw|xx|ty))|(docs\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|brands|email\\-layouts)\\-images)|(sites\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(atari-green-test\\.corp\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(sites\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images))\\/|^https://([A-Za-z0-9-]{1,63}\\.)+demos\\.corp\\.google\\.com(/(?!url\\b)|$)|^https://([A-Za-z0-9-]{1,63}\\.)+sslproxy\\.corp\\.google\\.com(/|$)|^https?://(([A-Za-z0-9-]{1,63}\\.)*(corp\\.google\\.com|proxy\\.googleprod\\.com|c\\.googlers\\.com|proxy\\.googlers\\.com|borg\\.google\\.com|docs\\.google\\.com|drive\\.google\\.com|googleplex\\.com|googlevideo\\.com|prod\\.google\\.com|lh3\\.photos\\.google\\.com|mail\\.google\\.com|youtube\\.com|yt\\.akamaized\\.net|chat\\.google\\.com)[.]?(:[0-9]+)?/|([A-Za-z0-9-]{1,63}\\.)*(sandbox\\.google\\.com)(:[0-9]+)?(/(?!url\\b)|$)|([A-Za-z0-9-]{1,63}\\.)*c\\.lh3(-d[a-gyz]|-testonly)?\\.(googleusercontent|photos\\.google)\\.com/.*$)");
  var gxa = RegExp("^https?://([A-Za-z0-9-]{1,63}\\.)*(currents\\.google\\.com)[.]?(:[0-9]+)?/");
  var cxa = !1;
  Jz = function(a,b,c){return!!(b&&b.test(a)||cxa&&c&&c.test(a))};
  g.Ga = {};
  var Uib = {};
  var gp = {};
  g.ip = function(a,b){return a in gp?gp[a]:b};
  Jqa = function(a,b={}){if(a=a.Y2){let c=a.Bka;a=[["componentStack",a.l5],["wizTagName",a.tagName],["wizOwnerTrace",a.ena?.join(" > ")],["errorSeverity",a.Jy?.toString()],["wizFeatureFlags",c?Object.entries(c).join("\n"):void 0]];for(let [d,e]of a)a=e,a!==void 0&&(b[d]=a)}return b};
  Bp = function(a,b){a=g.ip("EXPERIMENT_FLAGS",{})[a];return a!==void 0?a:b};
  g.Cp = function(a,b){a=Bp(a,b);return typeof a==="string"&&a==="false"?!1:!!a};
  var Mqa = [];
  var Nqa = [];
  g.Ia = function(a,b){a=a.split(".");b=b||g.Ga;for(var c=0;c<a.length;c++)if(b=b[a[c]],b==null)return null;return b};
  hd = function(a){var b="";typeof a.toString==="function"&&(b=""+a);return b+a.stack};
  fd = function(a,b){b||(b={});b[hd(a)]=!0;var c=a.stack||"",d=a.cause;d&&!b[hd(d)]&&(c+="\nCaused by: ",d.stack&&d.stack.indexOf(d.toString())==0||(c+=typeof d==="string"?d:d.message+"\n"),c+=fd(d,b));a=a.errors;if(Array.isArray(a)){d=1;let e;for(e=0;e<a.length&&!(d>4);e++)b[hd(a[e])]||(c+="\nInner error "+d++ +": ",a[e].stack&&a[e].stack.indexOf(a[e].toString())==0||(c+=typeof a[e]==="string"?a[e]:a[e].message+"\n"),c+=fd(a[e],b));e<a.length&&(c+="\n... "+(a.length-e)+" more inner errors")}return c};
  var gd = {};
  Baa = function(a){var b=g.Ia("window.location.href");a==null&&(a='Unknown Error of type "null/undefined"');if(typeof a==="string")return{message:a,name:"Unknown error",lineNumber:"Not available",fileName:b,stack:"Not available"};var c=!1;try{var d=a.lineNumber||a.line||"Not available"}catch(f){d="Not available",c=!0}try{var e=a.fileName||a.filename||a.sourceURL||g.Ga.$googDebugFname||b}catch(f){e="Not available",c=!0}b=fd(a);if(!(!c&&a.lineNumber&&a.fileName&&a.stack&&a.message&&a.name)){c=a.message;
if(c==null){if(a.constructor&&a.constructor instanceof Function){if(a.constructor.name)c=a.constructor.name;else if(c=a.constructor,gd[c])c=gd[c];else{c=String(c);if(!gd[c]){let f=/function\s+([^\(]+)/m.exec(c);gd[c]=f?f[1]:"[Anonymous]"}c=gd[c]}c='Unknown Error of type "'+c+'"'}else c="Unknown Error of unknown type";typeof a.toString==="function"&&Object.prototype.toString!==a.toString&&(c+=": "+a.toString())}return{message:c,name:a.name||"UnknownError",lineNumber:d,fileName:e,stack:b||"Not available"}}return{message:a.message,
name:a.name,lineNumber:a.lineNumber,fileName:a.fileName,stack:b}};
  Os = function(a){try{return(typeof a==="string"?a:String(JSON.stringify(a))).substr(0,500)}catch(b){return`unable to serialize ${typeof a} (${b.message})`}};
  Ns = function(a,b,c,d){c+=`.${a}`;a=Os(b);d[c]=a;return c.length+a.length};
  Ms = function(a){var b=a(),c=b&127;if(b<128)return c;b=a();c|=(b&127)<<7;if(b<128)return c;b=a();c|=(b&127)<<14;if(b<128)return c;b=a();return b<128?c|(b&127)<<21:Infinity};
  kpa = function(a){var b=a.length,c=0,d=()=>a.charCodeAt(c++);
do{var e=Ms(d);if(e===Infinity)break;let f=e>>3;switch(e&7){case 0:e=Ms(d);if(f===2)return e;break;case 1:if(f===2)return;c+=8;break;case 2:e=Ms(d);if(f===2)return a.substr(c,e);c+=e;break;case 5:if(f===2)return;c+=4;break;default:return}}while(c<b)};
  lpa = function(a,b,c,d){if(a)if(Array.isArray(a)){var e=d;for(d=0;d<a.length&&!(a[d]&&(e+=Ns(d,a[d],b,c),e>500));d++);d=e}else if(typeof a==="object")for(e in a){if(a[e]){a:{var f=e;var h=a[e],k=b,l=c;if(typeof h!=="string"||f!=="clickTrackingParams"&&f!=="trackingParams"){f=0;break a}f=(h=kpa(atob(h.replace(/-/g,"+").replace(/_/g,"/"))))?Ns(`${f}.ve`,h,k,l):0}d+=f;d+=Ns(e,a[e],b,c);if(d>500)break}}else c[b]=Os(a),d+=c[b].length;else c[b]=Os(a),d+=c[b].length;return d};
  var hpa = class{constructor(){this.Et=[];this.ou=[]}};
  Ks = undefined;
  fpa = function(a){if(a.name==="JavaException")return!0;a=a.stack;return a.includes("chrome://")||a.includes("-extension://")||a.includes("webkit-masked-url://")};
  gpa = function(a){if(!a.stack)return!0;var b=!a.stack.includes("\n");return!!(b&&a.stack.includes("ErrorType: ")||b&&a.stack.includes("Anonymous function (Unknown script")||a.stack.toLowerCase()==="not available"||a.fileName==="user-script"||a.fileName.startsWith("user-script:"))};
  var jpa = {};
  ipa = function(a,b){b.ou&&a.ou.unshift.apply(a.ou,b.ou);b.Et&&a.Et.unshift.apply(a.Et,b.Et)};
  Ls = function(){if(!Ks){var a=Ks=new hpa;a.ou.length=0;a.Et.length=0;ipa(a,jpa)}return Ks};
  var Oqa = [];
  var Pqa = {};
  var Lqa = 0;
  daa = 0;
  Na = undefined;
  g.Pa = function(a){return Object.prototype.hasOwnProperty.call(a,Na)&&a[Na]||(a[Na]=++daa)};
  var nj = {};
  var mj = 0;
  g.oj = function(){mj!=0&&(nj[g.Pa(this)]=this);this.uh=this.uh;this.Lc=this.Lc};
  g.Ln = function(a){g.oj.call(this);this.K=1;this.B=[];this.C=0;this.j=[];this.A={};this.L=!!a};
  g.G = g.Ln.prototype;
  g.G.subscribe = function(a,b,c){var d=this.A[a];d||(d=this.A[a]=[]);var e=this.K;this.j[e]=a;this.j[e+1]=b;this.j[e+2]=c;this.K=e+3;d.push(e);return e};
  g.G.unsubscribe = function(a,b,c){if(a=this.A[a]){let d=this.j;if(a=a.find(function(e){return d[e+1]==b&&d[e+2]==c}))return this.unsubscribeByKey(a)}return!1};
  g.sb = function(a,b){return Array.prototype.splice.call(a,b,1).length==1};
  g.tb = function(a,b){b=Array.prototype.indexOf.call(a,b,void 0);var c;(c=b>=0)&&g.sb(a,b);return c};
  g.G.unsubscribeByKey = function(a){var b=this.j[a];if(b){let c=this.A[b];this.C!=0?(this.B.push(a),this.j[a+1]=()=>{}):(c&&g.tb(c,a),delete this.j[a],delete this.j[a+1],delete this.j[a+2])}return!!b};
  qf = function(a){g.Ga.setTimeout(()=>{throw a;},0)};
  var gdb = class{constructor(){this.next=this.scope=this.j=null}set(a,b){this.j=a;
this.scope=b;this.next=null}reset(){this.next=this.scope=this.j=null}};
  var edb = class{constructor(a,b){this.B=a;this.C=b;this.A=0;this.j=null}get(){if(this.A>0){this.A--;var a=this.j;this.j=a.next;a.next=null}else a=this.B();return a}put(a){this.C(a);this.A<100&&(this.A++,a.next=this.j,this.j=a)}};
  var Gha = {};
  var fdb = class{constructor(){this.A=this.j=null}add(a,b){var c=Gha.get();c.set(a,b);this.A?this.A.next=c:this.j=c;this.A=c}remove(){var a=null;this.j&&(a=this.j,this.j=this.j.next,this.j||(this.A=null),a.next=null);return a}};
  Fha = {};
  xl = !1;
  Hha = function(){for(var a;a=Fha.remove();){try{a.j.call(a.scope)}catch(b){qf(b)}Gha.put(a)}xl=!1};
  g_ = undefined;
  hdb = ()=>{var a=Promise.resolve(void 0);g_=()=>{a.then(Hha)}};
  g.Dl = (a,b)=>{g_||hdb();xl||(g_(),xl=!0);Fha.add(a,b)};
  Nka = function(a,b,c){g.Dl(function(){a.apply(b,c)})};
  g.G.publish = function(a,b){var c=this.A[a];if(c){let e=Array(arguments.length-1);var d=arguments.length;let f;for(f=1;f<d;f++)e[f-1]=arguments[f];if(this.L)for(f=0;f<c.length;f++)d=c[f],Nka(this.j[d+1],this.j[d+2],e);else{this.C++;try{for(f=0,d=c.length;f<d&&!this.oa();f++){let h=c[f];this.j[h+1].apply(this.j[h+2],e)}}finally{if(this.C--,this.B.length>0&&this.C==0)for(;c=this.B.pop();)this.unsubscribeByKey(c)}}return f!=0}return!1};
  g.G.clear = function(a){if(a){let b=this.A[a];b&&(b.forEach(this.unsubscribeByKey,this),delete this.A[a])}else this.j.length=0,this.A={}};
  g.G.ka = function(){g.Ln.Lh.ka.call(this);this.clear();this.B.length=0};
  var cu = {};
  var Rqa = 0;
  g.Xr = function(){return{innertubeApiKey:g.ip("INNERTUBE_API_KEY"),innertubeApiVersion:g.ip("INNERTUBE_API_VERSION"),vM:g.ip("INNERTUBE_CONTEXT_CLIENT_CONFIG_INFO"),AS:g.ip("INNERTUBE_CONTEXT_CLIENT_NAME","WEB"),QZ:g.ip("INNERTUBE_CONTEXT_CLIENT_NAME",1),innertubeContextClientVersion:g.ip("INNERTUBE_CONTEXT_CLIENT_VERSION"),CS:g.ip("INNERTUBE_CONTEXT_HL"),BS:g.ip("INNERTUBE_CONTEXT_GL"),SZ:g.ip("INNERTUBE_HOST_OVERRIDE")||"",TZ:!!g.ip("INNERTUBE_USE_THIRD_PARTY_AUTH",!1),r7:!!g.ip("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT",
!1),appInstallData:g.ip("SERIALIZED_CLIENT_CONFIG_DATA")}};
  Pna = function(){return"INNERTUBE_API_KEY"in gp&&"INNERTUBE_API_VERSION"in gp};
  g.Yt = class{constructor(a){this.config_=null;a?this.config_=a:Pna()&&(this.config_=g.Xr())}isReady(){!this.config_&&Pna()&&(this.config_=g.Xr());return!!this.config_}};
  I_ = window;
  g.T = undefined;
  $s = function(){var a=g.Ia("_lact",window);return a==null?-1:Math.max(Date.now()-a,0)};
  var Wt = {};
  Hqa = function(a){Wt[a]=a in Wt?Wt[a]+1:0;return Wt[a]};
  var Vt = [];
  g.Ha = function(a,b,c){a=a.split(".");c=c||g.Ga;for(var d;a.length&&(d=a.shift());)a.length||b===void 0?c[d]&&c[d]!==Object.prototype[d]?c=c[d]:c=c[d]={}:c[d]=b};
  Bt = function(a,b){var c=g.Ia("yt.logging.transport.enableScrapingForTest"),d=Bp("il_payload_scraping");d=(d!==void 0?String(d):"")==="enable_il_payload_scraping";if(!c)if(d)Vt=[],g.Ha("yt.logging.transport.enableScrapingForTest",!0),g.Ha("yt.logging.transport.scrapedPayloadsForTesting",Vt),g.Ha("yt.logging.transport.payloadToScrape","visualElementShown visualElementHidden visualElementAttached screenCreated visualElementGestured visualElementStateChanged".split(" ")),g.Ha("yt.logging.transport.getScrapedPayloadFromClientEventsFunction"),
g.Ha("yt.logging.transport.scrapeClientEvent",!0);else return;c=g.Ia("yt.logging.transport.scrapedPayloadsForTesting");d=g.Ia("yt.logging.transport.payloadToScrape");b&&(b=b.payload,(b=g.Ia("yt.logging.transport.getScrapedPayloadFromClientEventsFunction").bind(b)())&&c.push(b));b=g.Ia("yt.logging.transport.scrapeClientEvent");if(d&&d.length>=1)for(let e=0;e<d.length;e++)a&&a.payload[d[e]]&&(b?c.push(a.payload):c.push((a?.payload)[d[e]]));g.Ha("yt.logging.transport.scrapedPayloadsForTesting",c)};
  var Mt = {};
  var Kt = [1,2];
  Nf = function(a,b=!1){return b&&Symbol.for&&a?Symbol.for(a):a!=null?Symbol(a):Symbol()};
  var cca = undefined;
  bh = function(a){return a[cca]??(a[cca]=new Map)};
  var Qf = undefined;
  Rg = function(a,b,c,d,e){var f=c+(e?0:-1),h=a.length-1;if(h>=1+(e?0:-1)&&f>=h){let k=a[h];if(k!=null&&typeof k==="object"&&k.constructor===Object)return k[c]=d,b}if(f<=h)return a[f]=d,b;d!==void 0&&(h=(b??(b=a[Qf]|0))>>14&1023||536870912,c>=h?d!=null&&(a[h+(e?0:-1)]={[c]:d}):a[f]=d);return b};
  Pg = function(a,b,c,d){if(b===-1)return null;var e=b+(c?0:-1),f=a.length-1;if(!(f<1+(c?0:-1))){if(e>=f){var h=a[f];if(h!=null&&typeof h==="object"&&h.constructor===Object){c=h[b];var k=!0}else if(e===f)c=h;else return}else c=a[e];if(d&&c!=null){d=d(c);if(d==null)return d;if(!Object.is(d,c))return k?h[b]=d:a[e]=d,d}return c}};
  dh = function(a,b,c,d,e){var f=a.get(d);if(f!=null)return f;f=0;for(let h=0;h<d.length;h++){let k=d[h];Pg(b,k,e)!=null&&(f!==0&&(c=Rg(b,c,f,void 0,e)),f=k)}a.set(d,f);return f};
  gh = function(a,b,c){a=a.Fe;return dh(bh(a),a,void 0,b)===c?c:-1};
  var rh = {};
  var Pf = {};
  Qg = function(a,b,c,d,e){Object.isExtensible(a);b=Pg(a.Fe,b,c,e);if(b!==null||d&&a.C!==Pf)return b};
  sg = function(a){return a==null||typeof a==="string"?a:void 0};
  sh = function(a,b){return sg(Qg(a,b,void 0,rh))};
  rg = function(a){if(a!=null&&typeof a!=="string")throw Error();return a};
  Rf = function(a,b){return b===void 0?a.j!==Pf&&!!(2&(a.Fe[Qf]|0)):!!(2&b)&&a.j!==Pf};
  Lg = function(a,b,c){a=new a.constructor(b);c&&(a.j=Pf);a.C=Pf;return a};
  Kg = function(a,b,c){return c&2?!0:c&32&&!(c&4096)?(b[Qf]=c|2,a.j=Pf,!0):!1};
  var vg = {};
  var ug = undefined;
  var Gf = {};
  If = function(a){if(a!==Gf)throw Error("illegal external caller");};
  var Bf = /[-_.]/g;
  var nba = {"-":"+",_:"/",".":"="};
  oba = function(a){return nba[a]||""};
  Cf = function(a){a=Bf.test(a)?a.replace(Bf,oba):a;a=atob(a);var b=new Uint8Array(a.length);for(let c=0;c<a.length;c++)b[c]=a.charCodeAt(c);return b};
  Jf = function(a){If(Gf);var b=a.j;b=b==null||b!=null&&b instanceof Uint8Array?b:typeof b==="string"?Cf(b):null;return b==null?b:a.j=b};
  var Ef = class{sizeBytes(){var a=Jf(this);return a?a.length:0}constructor(a,b){If(b);this.j=a;if(a!=null&&a.length===0)throw Error("ByteString should be constructed with non-empty values");}};
  Vba = function(a,b){if(typeof a!=="object")return a;if(Array.isArray(a)){var c=a[Qf]|0;a.length===0&&c&1?a=void 0:c&2||(!b||4096&c||16&c?a=Jg(a,c,!1,b&&!(c&16)):(a[Qf]|=34,c&4&&Object.freeze(a)));return a}if(a!=null&&a[ug]===vg)return b=a.Fe,c=b[Qf]|0,Rf(a,c)?a:Kg(a,b,c)?Lg(a,b):Jg(b,c);if(a instanceof Ef)return a};
  var xg = undefined;
  Xa = function(a){return a};
  var Jba = undefined;
  var pba = void 0;
  ed = function(a,b){a.__closure__error__context__984382||(a.__closure__error__context__984382={});a.__closure__error__context__984382.severity=b};
  Mf = function(a,b){if(a!=null){var c=pba??(pba={});var d=c[a]||0;d>=b||(c[a]=d+1,a=Error(),ed(a,"incident"),qf(a))}};
  Kba = function(a,b){b<100||Mf(Jba,1)};
  zg = function(a,b){for(let c in a)!isNaN(c)&&b(a,+c,a[c])};
  wg = function(a){return a};
  Dg = undefined;
  var Cg = class{};
  Iba = function(a){var b=new Cg;zg(a,(c,d,e)=>{b[d]=[...e]});
b.j=a.j;return b};
  yg = function(a){var b=Xa(xg);return b?a[b]:void 0};
  Eg = function(a,b,c,d){var e=d!==void 0;d=!!d;var f=Xa(xg),h;!e&&f&&(h=a[f])&&zg(h,Kba);f=[];var k=a.length;h=4294967295;var l=!1,m=!!(b&64),p=m?b&128?0:-1:void 0;if(!(b&1)){var q=k&&a[k-1];q!=null&&typeof q==="object"&&q.constructor===Object?(k--,h=k):q=void 0;!m||b&128||e||(l=!0,h=(Dg??wg)(h-p,p,a,q,void 0)+p)}b=void 0;for(var u=0;u<k;u++){let v=a[u];if(v!=null&&(v=c(v,d))!=null)if(m&&u>=h){let z=u-p;(b??(b={}))[z]=v}else f[u]=v}if(q)for(let v in q){k=q[v];if(k==null||(k=c(k,d))==null)continue;u=
+v;let z;m&&!Number.isNaN(u)&&(z=u+p)<h?f[z]=k:(b??(b={}))[v]=k}b&&(l?f.push(b):f[h]=b);e&&(c=Xa(xg))&&(a=yg(a))&&a instanceof Cg&&(f[c]=Iba(a));return f};
  Jg = function(a,b,c,d){d??(d=!!(34&b));a=Eg(a,b,Vba,d);d=32;c&&(d|=2);b=b&16769217|d;a[Qf]=b;return a};
  Mg = function(a){if(a.j!==Pf)return!1;var b=a.Fe;b=Jg(b,b[Qf]|0);b[Qf]|=2048;a.Fe=b;a.j=void 0;a.C=void 0;return!0};
  Ng = function(a){if(!Mg(a)&&Rf(a,a.Fe[Qf]|0))throw Error();};
  Zg = function(a,b,c,d,e){d===0||c.includes(d);var f=bh(a),h=dh(f,a,b,c,e);h!==d&&(h&&(b=Rg(a,b,h,void 0,e)),f.set(c,d));return b};
  eh = function(a,b,c,d){Ng(a);var e=a.Fe,f=e[Qf]|0;if(d==null){let h=bh(e);if(dh(h,e,f,c)===b)h.set(c,0);else return a}else f=Zg(e,f,c,b);Rg(e,f,b,d);return a};
  Ja = function(a,b){var c=g.Ia("CLOSURE_FLAGS");a=c&&c[a];return a!=null?a:b};
  var Sba = undefined;
  var Uba = undefined;
  Tba = function(){if(Sba)throw Error("carr");Mf(Uba,5)};
  Rba = function(a,b,c,d=0){if(a==null){var e=32;c?(a=[c],e|=128):a=[];b&&(e=e&-16760833|(b&1023)<<14)}else{if(!Array.isArray(a))throw Error("narr");e=a[Qf]|0;if(Sba&&1&e)throw Error("rfarr");2048&e&&!(2&e)&&Tba();if(e&256)throw Error("farr");if(e&64)return(e|d)!==e&&(a[Qf]=e|d),a;if(c&&(e|=128,c!==a[0]))throw Error("mid");a:{c=a;e|=64;var f=c.length;if(f){var h=f-1;let l=c[h];if(l!=null&&typeof l==="object"&&l.constructor===Object){b=e&128?0:-1;h-=b;if(h>=1024)throw Error("pvtlmt");for(var k in l)if(f=
+k,f<h)c[f+b]=l[k],delete l[k];else break;e=e&-16760833|(h&1023)<<14;break a}}if(b){k=Math.max(b,f-(e&128?0:-1));if(k>1024)throw Error("spvt");e=e&-16760833|(k&1023)<<14}}}a[Qf]=e|64|d;return a};
  var Nba = {};
  var Mba = undefined;
  var Wab = undefined;
  var Vab = undefined;
  qe = function(a){a.Dma=!0;return a};
  var Fg = undefined;
  Lba = function(a){switch(typeof a){case "number":return Number.isFinite(a)?a:""+a;case "bigint":return Fg(a)?Number(a):""+a;case "boolean":return a?1:0;case "object":if(Array.isArray(a)){var b=a[Qf]|0;return a.length===0&&b&1?void 0:Eg(a,b,Lba)}if(a!=null&&a[ug]===vg)return Gg(a);if(a instanceof Ef){b=a.j;if(b==null)a="";else if(typeof b==="string")a=b;else{let c="",d=0,e=b.length-10240;for(;d<e;)c+=String.fromCharCode.apply(null,b.subarray(d,d+=10240));c+=String.fromCharCode.apply(null,d?b.subarray(d):
b);b=btoa(c);a=a.j=b}return a}return}return a};
  Gg = function(a){a=a.Fe;return Eg(a,a[Qf]|0,Lba)};
  Hg = function(a,b){if(b){Dg=b==null||b===wg||b[Mba]!==Nba?wg:b;try{return Gg(a)}finally{Dg=void 0}}return Gg(a)};
  var fi = class{constructor(a,b,c){this.Fe=Rba(a,b,c,2048)}toJSON(){return Hg(this)}Kh(a){return JSON.stringify(Hg(this,a))}clone(){var a=this.Fe,b=a[Qf]|0;return Kg(this,a,b)?Lg(this,a,!0):new this.constructor(Jg(a,b,!1))}};
  var jqa = class extends fi{constructor(a){super(a)}getVideoId(){return sh(this,gh(this,Kt,1))}setVideoId(a){return eh(this,1,Kt,rg(a))}getPlaylistId(){return sh(this,gh(this,Kt,2))}};
  var Lt = {};
  Ct = function(a,b=!1){var c="";if(a.dangerousLogToVisitorSession)c="visitorOnlyApprovedKey";else if(a.cttAuthInfo){if(b){b=a.cttAuthInfo.token;c=a.cttAuthInfo;let d=new jqa;c.videoId?d.setVideoId(c.videoId):c.playlistId&&eh(d,2,Kt,rg(c.playlistId));Lt[b]=d}else b=a.cttAuthInfo,c={},b.videoId?c.videoId=b.videoId:b.playlistId&&(c.playlistId=b.playlistId),Mt[a.cttAuthInfo.token]=c;c=a.cttAuthInfo.token}return c};
  var Gqa = {accountStateChangeSignedIn:23,accountStateChangeSignedOut:24,delayedEventMetricCaptured:11,latencyActionBaselined:6,latencyActionInfo:7,latencyActionTicked:5,offlineTransferStatusChanged:2,offlineImageDownload:335,playbackStartStateChanged:9,systemHealthCaptured:3,mangoOnboardingCompleted:10,mangoPushNotificationReceived:230,mangoUnforkDbMigrationError:121,mangoUnforkDbMigrationSummary:122,mangoUnforkDbMigrationPreunforkDbVersionNumber:133,mangoUnforkDbMigrationPhoneMetadata:134,mangoUnforkDbMigrationPhoneStorage:135,
mangoUnforkDbMigrationStep:142,mangoAsyncApiMigrationEvent:223,mangoDownloadVideoResult:224,mangoHomepageVideoCount:279,mangoHomeV3State:295,mangoImageClientCacheHitEvent:273,sdCardStatusChanged:98,framesDropped:12,thumbnailHovered:13,deviceRetentionInfoCaptured:14,thumbnailLoaded:15,backToAppEvent:318,streamingStatsCaptured:17,offlineVideoShared:19,appCrashed:20,youThere:21,offlineStateSnapshot:22,mdxSessionStarted:25,mdxSessionConnected:26,mdxSessionDisconnected:27,bedrockResourceConsumptionSnapshot:28,
nextGenWatchWatchSwiped:29,kidsAccountsSnapshot:30,zeroStepChannelCreated:31,tvhtml5SearchCompleted:32,offlineSharePairing:34,offlineShareUnlock:35,mdxRouteDistributionSnapshot:36,bedrockRepetitiveActionTimed:37,unpluggedDegradationInfo:229,uploadMp4HeaderMoved:38,uploadVideoTranscoded:39,uploadProcessorStarted:46,uploadProcessorEnded:47,uploadProcessorReady:94,uploadProcessorRequirementPending:95,uploadProcessorInterrupted:96,uploadFrontendEvent:241,assetPackDownloadStarted:41,assetPackDownloaded:42,
assetPackApplied:43,assetPackDeleted:44,appInstallAttributionEvent:459,playbackSessionStopped:45,adBlockerMessagingShown:48,distributionChannelCaptured:49,dataPlanCpidRequested:51,detailedNetworkTypeCaptured:52,sendStateUpdated:53,receiveStateUpdated:54,sendDebugStateUpdated:55,receiveDebugStateUpdated:56,kidsErrored:57,mdxMsnSessionStatsFinished:58,appSettingsCaptured:59,mdxWebSocketServerHttpError:60,mdxWebSocketServer:61,startupCrashesDetected:62,coldStartInfo:435,offlinePlaybackStarted:63,liveChatMessageSent:225,
liveChatUserPresent:434,liveChatBeingModerated:457,liveChatGiftButtonImpressed:558,liveCreationCameraUpdated:64,liveCreationEncodingCaptured:65,liveCreationError:66,liveCreationHealthUpdated:67,liveCreationVideoEffectsCaptured:68,liveCreationStageOccured:75,offlineSystemFailure:546,liveCreationBroadcastScheduled:123,liveCreationArchiveReplacement:149,liveCreationCostreamingConnection:421,liveCreationPlayablesMetrics:533,liveCreationStreamWebrtcStats:288,liveCreationWebrtcError:526,mdxSessionRecoveryStarted:69,
mdxSessionRecoveryCompleted:70,mdxSessionRecoveryStopped:71,visualElementShown:72,visualElementHidden:73,visualElementGestured:78,visualElementStateChanged:208,screenCreated:156,playbackAssociated:202,visualElementAttached:215,playbackContextEvent:214,cloudCastingPlaybackStarted:74,webPlayerApiCalled:76,tvhtml5AccountDialogOpened:79,foregroundHeartbeat:80,foregroundHeartbeatScreenAssociated:111,kidsOfflineSnapshot:81,mdxEncryptionSessionStatsFinished:82,playerRequestCompleted:83,liteSchedulerStatistics:84,
mdxSignIn:85,spacecastMetadataLookupRequested:86,spacecastBatchLookupRequested:87,spacecastSummaryRequested:88,spacecastPlayback:89,spacecastDiscovery:90,tvhtml5LaunchUrlComponentChanged:91,mdxBackgroundPlaybackRequestCompleted:92,mdxBrokenAdditionalDataDeviceDetected:93,tvhtml5LocalStorage:97,tvhtml5DeviceStorageStatus:147,autoCaptionsAvailable:99,playbackScrubbingEvent:339,flexyState:100,interfaceOrientationCaptured:101,mainAppBrowseFragmentCache:102,offlineCacheVerificationFailure:103,offlinePlaybackExceptionDigest:217,
vrCopresenceStats:104,vrCopresenceSyncStats:130,vrCopresenceCommsStats:137,vrCopresencePartyStats:153,vrCopresenceEmojiStats:213,vrCopresenceEvent:141,vrCopresenceFlowTransitEvent:160,vrCowatchPartyEvent:492,vrCowatchUserStartOrJoinEvent:504,vrPlaybackEvent:345,kidsAgeGateTracking:105,offlineDelayAllowedTracking:106,mainAppAutoOfflineState:107,videoAsThumbnailDownload:108,videoAsThumbnailPlayback:109,liteShowMore:110,renderingError:118,kidsProfilePinGateTracking:119,abrTrajectory:124,scrollEvent:125,
streamzIncremented:126,kidsProfileSwitcherTracking:127,kidsProfileCreationTracking:129,buyFlowStarted:136,integrationAttributionEvent:556,mbsConnectionInitiated:138,mbsPlaybackInitiated:139,mbsLoadChildren:140,liteProfileFetcher:144,mdxRemoteTransaction:146,reelPlaybackError:148,reachabilityDetectionEvent:150,mobilePlaybackEvent:151,courtsidePlayerStateChanged:152,musicPersistentCacheChecked:154,musicPersistentCacheCleared:155,playbackInterrupted:157,playbackInterruptionResolved:158,fixFopFlow:159,
anrDetection:161,backstagePostCreationFlowEnded:162,clientError:163,gamingAccountLinkStatusChanged:164,liteHousewarming:165,buyFlowEvent:167,kidsParentalGateTracking:168,kidsSignedOutSettingsStatus:437,kidsSignedOutPauseHistoryFixStatus:438,tvhtml5WatchdogViolation:444,ypcUpgradeFlow:169,yongleStudy:170,ypcUpdateFlowStarted:171,ypcUpdateFlowCancelled:172,ypcUpdateFlowSucceeded:173,ypcUpdateFlowFailed:174,liteGrowthkitPromo:175,paymentFlowStarted:341,transactionFlowShowPaymentDialog:405,transactionFlowStarted:176,
transactionFlowSecondaryDeviceStarted:222,transactionFlowSecondaryDeviceSignedOutStarted:383,transactionFlowCancelled:177,transactionFlowPaymentCallBackReceived:387,transactionFlowPaymentSubmitted:460,transactionFlowPaymentSucceeded:329,transactionFlowSucceeded:178,transactionFlowFailed:179,transactionFlowPlayBillingConnectionStartEvent:428,transactionFlowSecondaryDeviceSuccess:458,transactionFlowErrorEvent:411,liteVideoQualityChanged:180,watchBreakEnablementSettingEvent:181,watchBreakFrequencySettingEvent:182,
videoEffectsCameraPerformanceMetrics:183,adNotify:184,startupTelemetry:185,playbackOfflineFallbackUsed:186,outOfMemory:187,ypcPauseFlowStarted:188,ypcPauseFlowCancelled:189,ypcPauseFlowSucceeded:190,ypcPauseFlowFailed:191,uploadFileSelected:192,ypcResumeFlowStarted:193,ypcResumeFlowCancelled:194,ypcResumeFlowSucceeded:195,ypcResumeFlowFailed:196,adsClientStateChange:197,ypcCancelFlowStarted:198,ypcCancelFlowCancelled:199,ypcCancelFlowSucceeded:200,ypcCancelFlowFailed:201,ypcCancelFlowGoToPaymentProcessor:402,
ypcDeactivateFlowStarted:320,ypcRedeemFlowStarted:203,ypcRedeemFlowCancelled:204,ypcRedeemFlowSucceeded:205,ypcRedeemFlowFailed:206,ypcFamilyCreateFlowStarted:258,ypcFamilyCreateFlowCancelled:259,ypcFamilyCreateFlowSucceeded:260,ypcFamilyCreateFlowFailed:261,ypcFamilyManageFlowStarted:262,ypcFamilyManageFlowCancelled:263,ypcFamilyManageFlowSucceeded:264,ypcFamilyManageFlowFailed:265,restoreContextEvent:207,embedsAdEvent:327,autoplayTriggered:209,clientDataErrorEvent:210,experimentalVssValidation:211,
tvhtml5TriggeredEvent:212,tvhtml5FrameworksFieldTrialResult:216,tvhtml5FrameworksFieldTrialStart:220,musicOfflinePreferences:218,watchTimeSegment:219,appWidthLayoutError:221,accountRegistryChange:226,userMentionAutoCompleteBoxEvent:227,downloadRecommendationEnablementSettingEvent:228,musicPlaybackContentModeChangeEvent:231,offlineDbOpenCompleted:232,kidsFlowEvent:233,kidsFlowCorpusSelectedEvent:234,videoEffectsEvent:235,unpluggedOpsEogAnalyticsEvent:236,playbackAudioRouteEvent:237,interactionLoggingDebugModeError:238,
offlineYtbRefreshed:239,kidsFlowError:240,musicAutoplayOnLaunchAttempted:242,deviceContextActivityEvent:243,deviceContextEvent:244,templateResolutionException:245,musicSideloadedPlaylistServiceCalled:246,embedsStorageAccessNotChecked:247,embedsHasStorageAccessResult:248,embedsItpPlayedOnReload:249,embedsRequestStorageAccessResult:250,embedsShouldRequestStorageAccessResult:251,embedsRequestStorageAccessState:256,embedsRequestStorageAccessFailedState:257,embedsItpWatchLaterResult:266,searchSuggestDecodingPayloadFailure:252,
siriShortcutActivated:253,tvhtml5KeyboardPerformance:254,latencyActionSpan:255,elementsLog:267,ytbFileOpened:268,tfliteModelError:269,apiTest:270,yongleUsbSetup:271,touStrikeInterstitialEvent:272,liteStreamToSave:274,appBundleClientEvent:275,ytbFileCreationFailed:276,adNotifyFailure:278,ytbTransferFailed:280,blockingRequestFailed:281,liteAccountSelector:282,liteAccountUiCallbacks:283,dummyPayload:284,browseResponseValidationEvent:285,entitiesError:286,musicIosBackgroundFetch:287,mdxNotificationEvent:289,
layersValidationError:290,musicPwaInstalled:291,liteAccountCleanup:292,html5PlayerHealthEvent:293,watchRestoreAttempt:294,liteAccountSignIn:296,notaireEvent:298,kidsVoiceSearchEvent:299,adNotifyFilled:300,delayedEventDropped:301,analyticsSearchEvent:302,systemDarkThemeOptOutEvent:303,flowEvent:304,networkConnectivityBaselineEvent:305,ytbFileImported:306,downloadStreamUrlExpired:307,directSignInEvent:308,lyricImpressionEvent:309,accessibilityStateEvent:310,tokenRefreshEvent:311,genericAttestationExecution:312,
tvhtml5VideoSeek:313,unpluggedAutoPause:314,scrubbingEvent:315,bedtimeReminderEvent:317,tvhtml5UnexpectedRestart:319,tvhtml5DeviceStorageStats:535,tvhtml5StabilityTraceEvent:478,tvhtml5OperationHealth:467,tvhtml5WatchKeyEvent:321,voiceLanguageChanged:322,tvhtml5LiveChatStatus:323,parentToolsCorpusSelectedEvent:324,offerAdsEnrollmentInitiated:325,networkQualityIntervalEvent:326,deviceStartupMetrics:328,heartbeatActionPlayerTransitioned:330,tvhtml5Lifecycle:331,heartbeatActionPlayerHalted:332,adaptiveInlineMutedSettingEvent:333,
mainAppLibraryLoadingState:334,thirdPartyLogMonitoringEvent:336,appShellAssetLoadReport:337,tvhtml5AndroidAttestation:338,tvhtml5StartupSoundEvent:340,iosBackgroundRefreshTask:342,iosBackgroundProcessingTask:343,sliEventBatch:344,postImpressionEvent:346,musicSideloadedPlaylistExport:347,idbUnexpectedlyClosed:348,voiceSearchEvent:349,mdxSessionCastEvent:350,idbQuotaExceeded:351,idbTransactionEnded:352,idbTransactionAborted:353,tvhtml5KeyboardLogging:354,idbIsSupportedCompleted:355,creatorStudioMobileEvent:356,
idbDataCorrupted:357,parentToolsAppChosenEvent:358,webViewBottomSheetResized:359,activeStateControllerScrollPerformanceSummary:360,navigatorValidation:361,mdxSessionHeartbeat:362,clientHintsPolyfillDiagnostics:363,clientHintsPolyfillEvent:364,proofOfOriginTokenError:365,kidsAddedAccountSummary:366,musicWearableDevice:367,ypcRefundFlowEvent:368,tvhtml5PlaybackMeasurementEvent:369,tvhtml5WatermarkMeasurementEvent:370,clientExpGcfPropagationEvent:371,mainAppReferrerIntent:372,leaderLockEnded:373,leaderLockAcquired:374,
googleHatsEvent:375,persistentLensLaunchEvent:376,parentToolsChildWelcomeChosenEvent:378,browseThumbnailPreloadEvent:379,finalPayload:380,mdxDialAdditionalDataUpdateEvent:381,webOrchestrationTaskLifecycleRecord:382,startupSignalEvent:384,accountError:385,gmsDeviceCheckEvent:386,accountSelectorEvent:388,accountUiCallbacks:389,mdxDialAdditionalDataProbeEvent:390,downloadsSearchIcingApiStats:391,downloadsSearchIndexUpdatedEvent:397,downloadsSearchIndexSnapshot:398,dataPushClientEvent:392,kidsCategorySelectedEvent:393,
mdxDeviceManagementSnapshotEvent:394,prefetchRequested:395,prefetchableCommandExecuted:396,gelDebuggingEvent:399,webLinkTtsPlayEnd:400,clipViewInvalid:401,persistentStorageStateChecked:403,cacheWipeoutEvent:404,playerEvent:410,sfvEffectPipelineStartedEvent:412,sfvEffectPipelinePausedEvent:429,sfvEffectPipelineEndedEvent:413,sfvEffectChosenEvent:414,sfvEffectLoadedEvent:415,sfvEffectUserInteractionEvent:465,sfvEffectFirstFrameProcessedLatencyEvent:416,sfvEffectAggregatedFramesProcessedLatencyEvent:417,
sfvEffectAggregatedFramesDroppedEvent:418,sfvEffectPipelineErrorEvent:430,sfvEffectGraphFrozenEvent:419,sfvEffectGlThreadBlockedEvent:420,mdeQosEvent:510,mdeVideoChangedEvent:442,mdePlayerPerformanceMetrics:472,mdeExporterEvent:497,genericClientExperimentEvent:423,homePreloadTaskScheduled:424,homePreloadTaskExecuted:425,homePreloadCacheHit:426,polymerPropertyChangedInObserver:427,applicationStarted:431,networkCronetRttBatch:432,networkCronetRttSummary:433,repeatChapterLoopEvent:436,seekCancellationEvent:462,
lockModeTimeoutEvent:483,externalVideoShareToYoutubeAttempt:501,parentCodeEvent:502,offlineTransferStarted:4,musicOfflineMixtapePreferencesChanged:16,mangoDailyNewVideosNotificationAttempt:40,mangoDailyNewVideosNotificationError:77,dtwsPlaybackStarted:112,dtwsTileFetchStarted:113,dtwsTileFetchCompleted:114,dtwsTileFetchStatusChanged:145,dtwsKeyframeDecoderBufferSent:115,dtwsTileUnderflowedOnNonkeyframe:116,dtwsBackfillFetchStatusChanged:143,dtwsBackfillUnderflowed:117,dtwsAdaptiveLevelChanged:128,
blockingVisitorIdTimeout:277,liteSocial:18,mobileJsInvocation:297,biscottiBasedDetection:439,coWatchStateChange:440,embedsVideoDataDidChange:441,shortsFirst:443,cruiseControlEvent:445,qoeClientLoggingContext:446,atvRecommendationJobExecuted:447,tvhtml5UserFeedback:448,producerProjectCreated:449,producerProjectOpened:450,producerProjectDeleted:451,producerProjectElementAdded:453,producerProjectElementRemoved:454,producerAppStateChange:509,producerProjectDiskInsufficientExportFailure:516,producerMediaServicesResetDetails:522,
tvhtml5ShowClockEvent:455,deviceCapabilityCheckMetrics:456,youtubeClearcutEvent:461,offlineBrowseFallbackEvent:463,getCtvTokenEvent:464,startupDroppedFramesSummary:466,screenshotEvent:468,miniAppPlayEvent:469,elementsDebugCounters:470,fontLoadEvent:471,webKillswitchReceived:473,webKillswitchExecuted:474,cameraOpenEvent:475,manualSmoothnessMeasurement:476,tvhtml5AppQualityEvent:477,polymerPropertyAccessEvent:479,miniAppSdkUsage:480,cobaltTelemetryEvent:481,crossDevicePlayback:482,channelCreatedWithObakeImage:484,
channelEditedWithObakeImage:485,offlineDeleteEvent:486,crossDeviceNotificationTransfer:487,androidIntentEvent:488,unpluggedAmbientInterludesCounterfactualEvent:489,keyPlaysPlayback:490,shortsCreationFallbackEvent:493,vssData:491,castMatch:494,miniAppPerformanceMetrics:495,userFeedbackEvent:496,kidsGuestSessionMismatch:498,musicSideloadedPlaylistMigrationEvent:499,sleepTimerSessionFinishEvent:500,watchEpPromoConflict:503,innertubeResponseCacheMetrics:505,miniAppAdEvent:506,dataPlanUpsellEvent:507,
producerProjectRenamed:508,producerMediaSelectionEvent:511,embedsAutoplayStatusChanged:512,remoteConnectEvent:513,connectedSessionMisattributionEvent:514,producerProjectElementModified:515,adsSeenClientLogging:517,producerEvent:518,tvhtml5CleanStart:519,deviceAccountMetricsEvent:520,derpLogEvent:521,playablesPortalEvent:523,ipValidationStarted:524,ipValidationReceived:525,reelsSequenceMutationEvent:527,watchZoomStateChange:528,metadataEditorEvent:529,kidsPrismaDeeplinksEvent:530,creationOrchestrationEvent:531,
coordinatedSamplingTriggered:532,recapScreenshotEvent:534,mdxLocalNetworkPermissionRequestEvent:536,mdxLocalNetworkPermissionResponseEvent:537,sessionReplayEvent:538,sessionReplayStatusEvent:539,loggingReliabilityProbe:540,keyValueStoreStatsEvent:541,deviceLocationPermissionEvent:542,remoteControlStarted:543,remoteControlCompleted:544,reelsAdsEvents:545,ytlrLoaderTestHarnessEvent:547,biometricAuthenticationEvent:548,mainAppLifecycleEvent:549,musicDownloadBackgroundContinuedProcessingTask:550,musicMetadataMismatchEvent:551,
scrollToComponentCompleted:552,entityStoreTelemetry:553,streamingDarkLaunchEvent:554,childAccountsDisplayEvent:555,tvfasPlaybackContext:557,mdeC2PaEvent:559,mdeBatchedPlayerEvents:560,tvhtml5UlpCreationFlowData:561,alwaysConnectedHandshakeRemoteControlStarted:562,alwaysConnectedHandshakeRemoteControlCompleted:563,alwaysConnectedHandshakeAwarenessStarted:564,alwaysConnectedHandshakeAwarenessCompleted:565,customThumbnailSourceMetadata:567,miniAppInGameEvent:568,androidToastyRun:569,tvhtml5AppTelemetryEvent:570,
shortsEffectStartedEvent:571,shortsEffectEndedEvent:572,networkQualityTransitionEvent:573,elementsReceivedResourcesEvent:574};
  Dt = function(a){a=Object.keys(a);for(let b of a)if(Gqa[b])return b};
  var jjb = class extends g.oj{constructor(){super();this.A=[];this.j=[];var a=g.Ia("yt.gcf.config.hotUpdateCallbacks");a?(this.A=[...a],this.j=a):(this.j=[],g.Ha("yt.gcf.config.hotUpdateCallbacks",this.j))}ka(){for(let b of this.A){var a=this.j;let c=a.indexOf(b);c>=0&&a.splice(c,1)}this.A.length=0;super.ka()}};
  Sr = function(a,b){a.A=b;g.Ha("yt.gcf.config.hotConfigGroup",a.A||null)};
  Tr = function(a,b){a.j=b;g.Ha("yt.gcf.config.coldConfigGroup",a.j||null)};
  Ur = function(){return g.Ia("yt.gcf.config.coldConfigGroup")};
  Vr = function(){return g.Ia("yt.gcf.config.hotConfigGroup")};
  On = function(a){this.j=a};
  jo = function(a){this.j=a;this.A=null};
  g.G = jo.prototype;
  g.G.isAvailable = function(){if(this.A===null){var a=this.j;if(a)try{a.setItem("__sak","1");a.removeItem("__sak");var b=!0}catch(c){b=c instanceof DOMException&&(c.name==="QuotaExceededError"||c.code===22||c.code===1014||c.name==="NS_ERROR_DOM_QUOTA_REACHED")&&a&&a.length!==0}else b=!1;this.A=b}return this.A};
  ko = function(a){if(a.j==null)throw Error("Storage mechanism: Storage unavailable");a.isAvailable()||qf(Error("Storage mechanism: Storage unavailable"))};
  g.G.set = function(a,b){ko(this);try{this.j.setItem(a,b)}catch(c){if(this.j.length==0)throw"Storage mechanism: Storage disabled";throw"Storage mechanism: Quota exceeded";}};
  g.G.get = function(a){ko(this);a=this.j.getItem(a);if(typeof a!=="string"&&a!==null)throw"Storage mechanism: Invalid value was encountered";return a};
  g.G.remove = function(a){ko(this);this.j.removeItem(a)};
  g.zj = function(){};
  g.SZ = {};
  g.Aj = function(a){return{value:a,done:!1}};
  g.G.mo = function(a){ko(this);var b=0,c=this.j,d=new g.zj;d.next=function(){if(b>=c.length)return g.SZ;var e=c.key(b++);if(a)return g.Aj(e);e=c.getItem(e);if(typeof e!=="string")throw"Storage mechanism: Invalid value was encountered";return g.Aj(e)};
return d};
  g.G.clear = function(){ko(this);this.j.clear()};
  g.G.key = function(a){ko(this);return this.j.key(a)};
  lo = function(){var a=null;try{a=g.Ga.localStorage||null}catch(b){}jo.call(this,a)};
  mo = function(a,b){this.A=a;this.j=b+"::"};
  g.no = function(a){var b=new lo;return b.isAvailable()?a?new mo(b,a):b:null};
  cia = function(){};
  g.Ol = function(a){return(new cia).Kh(a)};
  Ik = function(a){this.j=a||{cookie:""}};
  g.G = Ik.prototype;
  g.G.isEnabled = function(){if(!g.Ga.navigator.cookieEnabled)return!1;if(this.j.cookie)return!0;this.set("TESTCOOKIESENABLED","1",{cN:60});if(this.get("TESTCOOKIESENABLED")!=="1")return!1;this.remove("TESTCOOKIESENABLED");return!0};
  g.G.set = function(a,b,c){var d=!1;if(typeof c==="object"){var e=c.sameSite;d=c.secure||!1;var f=c.domain||void 0;var h=c.path||void 0;var k=c.cN}if(/[;=\s]/.test(a))throw Error('Invalid cookie name "'+a+'"');if(/[;\r\n]/.test(b))throw Error('Invalid cookie value "'+b+'"');k===void 0&&(k=-1);c=f?";domain="+f:"";h=h?";path="+h:"";d=d?";secure":"";k=k<0?"":k==0?";expires="+(new Date(1970,1,1)).toUTCString():";expires="+(new Date(Date.now()+k*1E3)).toUTCString();this.j.cookie=a+"="+b+c+h+k+d+(e!=null?
";samesite="+e:"")};
  g.G.get = function(a,b){var c=a+"=",d=(this.j.cookie||"").split(";");for(let e=0,f;e<d.length;e++){f=d[e].trim();if(f.lastIndexOf(c,0)==0)return f.slice(c.length);if(f==a)return""}return b};
  g.G.remove = function(a,b,c){var d=this.get(a)!==void 0;this.set(a,"",{cN:0,path:b,domain:c});return d};
  Jk = function(a){a=(a.j.cookie||"").split(";");var b=[],c=[];for(let f=0;f<a.length;f++){var d=a[f].trim();var e=d.indexOf("=");e==-1?(b.push(""),c.push(d)):(b.push(d.substring(0,e)),c.push(d.substring(e+1)))}return{keys:b,values:c}};
  g.G.Hr = function(){return Jk(this).keys};
  g.G.Eo = function(){return Jk(this).values};
  g.G.clear = function(){var a=Jk(this).keys;for(let b=a.length-1;b>=0;b--)this.remove(a[b])};
  var Up = {};
  var Tp = !1;
  g.Vp = function(a,b,c,d="youtube.com",e=!1){Tp||Up.set(""+a,b,{cN:c,path:"/",domain:d,secure:e})};
  g.Wp = function(a,b){if(!Tp)return Up.get(""+a,b)};
  g.Xp = function(a,b="/",c="youtube.com"){Tp||Up.remove(""+a,b,c)};
  var vs = class{constructor(a){this.j=(a=g.no(a))?new On(a):null;this.domain=document.domain||window.location.hostname}A(){return!!this.j}set(a,b,c,d){c=c||31104E3;this.remove(a);if(this.j)try{this.j.set(a,b,Date.now()+c*1E3);return}catch(f){}var e="";if(d)try{e=escape(g.Ol(b))}catch(f){return}else e=escape(String(b));g.Vp(a,e,c,this.domain)}get(a,b){var c=void 0,d=!this.A();if(!d&&this.j)try{c=this.j.get(a)}catch(e){d=!0}if(d&&(c=g.Wp(a)))if(d=unescape(c),b)try{c=JSON.parse(d)}catch(e){this.remove(a),
c=void 0}else c=d;return c}remove(a){this.j&&this.j.remove(a);g.Xp(a,"/",this.domain)}getCreationTime(a){return this.j&&(a=(this.j.A(a)||{}).creation,typeof a==="number")?a:null}};
  var br = undefined;
  cr = function(){return br()?.get("LAST_RESULT_ENTRY_KEY",!0)};
  djb = {AUTH_INVALID:"No user identifier specified.",EXPLICIT_ABORT:"Transaction was explicitly aborted.",IDB_NOT_SUPPORTED:"IndexedDB is not supported.",MISSING_INDEX:"Index not created.",MISSING_OBJECT_STORES:"Object stores not created.",DB_DELETED_BY_MISSING_OBJECT_STORES:"Database is deleted because expected object stores were not created.",DB_REOPENED_BY_MISSING_OBJECT_STORES:"Database is reopened because expected object stores were not created.",UNKNOWN_ABORT:"Transaction was aborted for unknown reasons.",QUOTA_EXCEEDED:"The current transaction exceeded its quota limitations.",
QUOTA_MAYBE_EXCEEDED:"The current transaction may have failed because of exceeding quota limitations.",EXECUTE_TRANSACTION_ON_CLOSED_DB:"Can't start a transaction on a closed database",INCOMPATIBLE_DB_VERSION:"The binary is incompatible with the database version"};
  ejb = {AUTH_INVALID:"ERROR",EXECUTE_TRANSACTION_ON_CLOSED_DB:"WARNING",EXPLICIT_ABORT:"IGNORED",IDB_NOT_SUPPORTED:"ERROR",MISSING_INDEX:"WARNING",MISSING_OBJECT_STORES:"ERROR",DB_DELETED_BY_MISSING_OBJECT_STORES:"WARNING",DB_REOPENED_BY_MISSING_OBJECT_STORES:"WARNING",QUOTA_EXCEEDED:"WARNING",QUOTA_MAYBE_EXCEEDED:"WARNING",UNKNOWN_ABORT:"WARNING",INCOMPATIBLE_DB_VERSION:"WARNING"};
  fjb = {};
  g.kr = class extends g.Vq{constructor(a,b={},c=djb[a],d=ejb[a],e=fjb[a]){super(c,{name:"YtIdbKnownError",isSw:self.document===void 0,isIframe:self!==self.top,type:a,...b});this.type=a;this.message=c;this.level=d;this.j=e;Object.setPrototypeOf(this,g.kr.prototype)}};
  g.or = function(a,b,c){var d=cr();return new g.kr("IDB_NOT_SUPPORTED",{context:{caller:a,publicName:b,version:c,hasSucceededOnce:d?.hasSucceededOnce}})};
  hp = function(...a){a=arguments;a.length>1?gp[a[0]]=a[1]:a.length===1&&Object.assign(gp,a[0])};
  Hla = function(a,b,c,d,e,f){var h=g.Ia("yt.logging.errors.log");h?h(a,b,c,d,e,void 0,f):(h=g.ip("ERRORS",[]),h.push([a,b,c,d,e,void 0,f]),hp("ERRORS",h))};
  np = function(a,b,c,d,e){Hla(a,"WARNING",b,c,d,e)};
  Mr = function(){return g.Ia("ytglobal.idbToken_")||void 0};
  Qma = function(a,b,c){var d=()=>{try{a.removeEventListener("success",e),a.removeEventListener("error",f)}catch{}},e=()=>{b(a.result);
d()},f=()=>{c(a.error);
d()};
a.addEventListener("success",e);a.addEventListener("error",f)};
  rr = class{constructor(a){this.j=a}};
  Nma = function(a){return a};
  Mma = function(a){if(!a)throw Error();throw a;};
  qr = function(a,b,c,d,e){b===c?e(new TypeError("Circular promise chain detected.")):c.then(f=>{f instanceof g.pr?qr(a,b,f,d,e):d(f)},f=>{e(f)})};
  Pma = function(a,b,c,d,e){try{if(a.state.status!=="REJECTED")throw Error("calling handleReject before the promise is rejected.");let f=c(a.state.reason);f instanceof g.pr?qr(a,b,f,d,e):d(f)}catch(f){e(f)}};
  Oma = function(a,b,c,d,e){try{if(a.state.status!=="FULFILLED")throw Error("calling handleResolve before the promise is fulfilled.");let f=c(a.state.value);f instanceof g.pr?qr(a,b,f,d,e):d(f)}catch(f){e(f)}};
  g.pr = class{constructor(a){this.state={status:"PENDING"};this.j=[];this.A=[];a=a.j;var b=d=>{if(this.state.status==="PENDING"){this.state={status:"FULFILLED",value:d};for(let e of this.j)e()}},c=d=>{if(this.state.status==="PENDING"){this.state={status:"REJECTED",
reason:d};for(let e of this.A)e()}};
try{a(b,c)}catch(d){c(d)}}static all(a){return new g.pr(new rr((b,c)=>{var d=[],e=a.length;e===0&&b(d);for(let f=0;f<a.length;++f)g.pr.resolve(a[f]).then(h=>{d[f]=h;e--;e===0&&b(d)}).catch(h=>{c(h)})}))}static resolve(a){return new g.pr(new rr((b,c)=>{a instanceof g.pr?a.then(b,c):b(a)}))}static reject(a){return new g.pr(new rr((b,c)=>{c(a)}))}then(a,b){var c=a??Nma,d=b??Mma;
return new g.pr(new rr((e,f)=>{this.state.status==="PENDING"?(this.j.push(()=>{Oma(this,this,c,e,f)}),this.A.push(()=>{Pma(this,this,d,e,f)})):this.state.status==="FULFILLED"?Oma(this,this,c,e,f):this.state.status==="REJECTED"&&Pma(this,this,d,e,f)}))}catch(a){return this.then(void 0,a)}};
  sr = function(a){return new g.pr(new rr((b,c)=>{Qma(a,b,c)}))};
  var ena = class{constructor(a,b){this.request=a;
this.cursor=b}delete(){return sr(this.cursor.delete()).then(()=>{})}getValue(){return this.cursor.value}update(a){return sr(this.cursor.update(a))}};
  Ar = function(a){return sr(a).then(b=>b?new ena(a,b):null)};
  g.Cr = function(a){a.cursor.continue(void 0);return Ar(a.request)};
  tr = function(a,b){return new g.pr(new rr((c,d)=>{var e=()=>{var f=a?b(a):null;f?f.then(h=>{a=h;e()},d):c()};
e()}))};
  g.Br = function(a,b,c){a=a.j.openCursor(b.query,b.direction);return Ar(a).then(d=>tr(d,c))};
  Zma = function(a,b){return g.Br(a,{query:b},c=>c.delete().then(()=>g.Cr(c))).then(()=>{})};
  $ma = function(a,b,c){var d=[];return g.Br(a,{query:b},e=>{if(!(c!==void 0&&d.length>=c))return d.push(e.getValue()),g.Cr(e)}).then(()=>d)};
  mr = class extends Error{constructor(a,b){super();this.index=a;this.objectStore=b;Object.setPrototypeOf(this,mr.prototype)}};
  g.Dr = function(a,b,c){var {query:d=null,direction:e="next"}=b;a=a.j.openCursor(d,e);return Ar(a).then(f=>tr(f,c))};
  dna = function(a,b,c){var d=[];return g.Dr(a,{query:b},e=>{if(!(c!==void 0&&d.length>=c))return d.push(e.getValue()),g.Cr(e)}).then(()=>d)};
  var hjb = class{constructor(a){this.j=a}count(a){return sr(this.j.count(a))}delete(a){return g.Dr(this,{query:a},b=>b.delete().then(()=>g.Cr(b)))}get(a){return sr(this.j.get(a))}getAll(a,b){return"getAll"in IDBIndex.prototype?sr(this.j.getAll(a,b)):dna(this,a,b)}keyPath(){return this.j.keyPath}unique(){return this.j.unique}};
  Xma = class{constructor(a){this.j=a}add(a,b){return sr(this.j.add(a,b))}autoIncrement(){return this.j.autoIncrement}clear(){return sr(this.j.clear()).then(()=>{})}count(a){return sr(this.j.count(a))}delete(a){return a instanceof IDBKeyRange?Zma(this,a):sr(this.j.delete(a))}get(a){return sr(this.j.get(a))}getAll(a,b){return"getAll"in IDBObjectStore.prototype?sr(this.j.getAll(a,b)):$ma(this,a,b)}index(a){try{return new hjb(this.j.index(a))}catch(b){if(b instanceof Error&&b.name==="NotFoundError")throw new mr(a,
this.j.name);
throw b;}}getName(){return this.j.name}keyPath(){return this.j.keyPath}put(a,b){return sr(this.j.put(a,b))}};
  xr = function(a,b,c){a=a.j.createObjectStore(b,c);return new Xma(a)};
  zr = function(a,b,c){a.j.createIndex(b,c,{unique:!1})};
  ir = function(a){if(a.indexOf(":")>=0)throw Error("Database name cannot contain ':'");};
  var Kr = {};
  Lr = undefined;
  var dr = !1;
  g.uc = function(){var a=g.Ga.navigator;return a&&(a=a.userAgent)?a:""};
  vc = function(a){return g.uc().indexOf(a)!=-1};
  g.Jr = undefined;
  lq = function(){var a=/WebKit\/([0-9]+)/.exec(g.uc());return!!(a&&parseInt(a[1],10)>=602)};
  kq = function(){var a=/WebKit\/([0-9]+)/.exec(g.uc());return!!(a&&parseInt(a[1],10)>=600)};
  rq = undefined;
  rd = function(){return vc("iPhone")&&!vc("iPod")&&!vc("iPad")};
  qq = {};
  g.Ir = qq||rq;
  ur = function(){return g.Cp("idb_immediate_commit")};
  jr = function(a){return a.substr(0,a.indexOf(":"))||a};
  sd = function(){return rd()||vc("iPad")||vc("iPod")};
  wc = function(){return vc("Firefox")||vc("FxiOS")};
  xc = function(){return(vc("Chrome")||vc("CriOS"))&&!vc("Edge")||vc("Silk")};
  yc = function(){return vc("Safari")&&!(xc()||vc("Coast")||vc("Opera")||vc("Edge")||vc("Edg/")||vc("OPR")||wc()||vc("Silk")||vc("Android"))};
  g.lr = {};
  Lma = ["The database connection is closing","Can't start a transaction on a closed database","A mutation operation was attempted on a database that did not allow mutations"];
  nr = function(a,b,c,d){b=jr(b);var e=a instanceof Error?a:Error(`Unexpected error: ${a}`);if(e instanceof g.kr)return e;a={objectStoreNames:c,dbName:b,dbVersion:d};if(e.name==="QuotaExceededError")return new g.kr("QUOTA_EXCEEDED",a);if(g.lr&&e.name==="UnknownError")return new g.kr("QUOTA_MAYBE_EXCEEDED",a);if(e instanceof mr)return new g.kr("MISSING_INDEX",{...a,objectStore:e.objectStore,index:e.index});if(e.name==="InvalidStateError"&&Lma.some(f=>e.message.includes(f)))return new g.kr("EXECUTE_TRANSACTION_ON_CLOSED_DB",
a);
if(e.name==="AbortError")return new g.kr("UNKNOWN_ABORT",a,e.message);e.args=[{...a,name:"IdbError",KN:e.name}];e.level="WARNING";return e};
  var fr = [];
  er = undefined;
  hr = function(a,b){dr||(er?er.logEvent(a,b):(fr.push({type:"EVENT",eventType:a,payload:b}),fr.length>10&&fr.shift()))};
  Yma = function(a,b,c,d,e,f="IDB_TRANSACTION_TAG_UNKNOWN"){hr("TRANSACTION_ENDED",{objectStoreNames:d,connectionHasUnknownAbortedTransaction:a.A,duration:e,isSuccessful:b,tryCount:c,tag:f})};
  gr = function(a){dr||(er?er.Mi(a):(fr.push({type:"ERROR",payload:a}),fr.length>10&&fr.shift()))};
  Wma = function(a,b,c,d,e,f,h){b=c-b;e?(e instanceof g.kr&&(e.type==="QUOTA_EXCEEDED"||e.type==="QUOTA_MAYBE_EXCEEDED")&&hr("QUOTA_EXCEEDED",{dbName:jr(a.j.name),objectStoreNames:f,transactionCount:a.transactionCount,transactionMode:h.mode}),e instanceof g.kr&&e.type==="UNKNOWN_ABORT"&&(c-=a.B,c<0&&c>=2147483648&&(c=0),hr("TRANSACTION_UNEXPECTEDLY_ABORTED",{objectStoreNames:f,transactionDuration:b,transactionCount:a.transactionCount,dbDuration:c}),a.A=!0),Yma(a,!1,d,f,b,h.tag),gr(e)):Yma(a,!0,d,f,b,
h.tag)};
  g.vr = class{constructor(a){this.j=a;this.A=new Map;this.aborted=!1;this.done=new Promise((b,c)=>{this.j.addEventListener("complete",()=>{b()});
this.j.addEventListener("error",d=>{d.currentTarget===d.target&&c(this.j.error)});
this.j.addEventListener("abort",()=>{var d=this.j.error;if(d)c(d);else if(!this.aborted){d=g.kr;var e=this.j.objectStoreNames;let f=[];for(let h=0;h<e.length;h++){let k=e.item(h);if(k===null)throw Error("Invariant: item in DOMStringList is null");f.push(k)}d=new d("UNKNOWN_ABORT",{objectStoreNames:f.join(),dbName:this.j.db.name,mode:this.j.mode});c(d)}})})}abort(){this.j.abort();
this.aborted=!0;throw new g.kr("EXPLICIT_ABORT");}commit(){this.aborted||this.j.commit?.()}objectStore(a){a=this.j.objectStore(a);var b=this.A.get(a);b||(b=new Xma(a),this.A.set(a,b));return b}};
  Vma = function(a,b,c){var d=new Promise((e,f)=>{try{let h=b(a);c&&a.commit();h.then(k=>{e(k)}).catch(f)}catch(h){f(h),a.abort()}});
return Promise.all([d,a.done]).then(([e])=>e)};
  g.wr = async function(a,b,c,d){var e={mode:"readonly",kc:!1,tag:"IDB_TRANSACTION_TAG_UNKNOWN"};typeof c==="string"?e.mode=c:Object.assign(e,c);a.transactionCount++;c=e.kc?3:1;for(var f=0,h;!h;){f++;let p=Math.round((0,g.T)());try{var k=a.j.transaction(b,e.mode),l=d,m=!!e.commit;let q=new g.vr(k),u=await Vma(q,l,m),v=Math.round((0,g.T)());Wma(a,p,v,f,void 0,b.join(),e);return u}catch(q){l=Math.round((0,g.T)());let u=nr(q,a.j.name,b.join(),a.j.version);if(u instanceof g.kr&&!u.j||f>=c)Wma(a,p,l,f,u,b.join(),
e),h=u}}return Promise.reject(h)};
  fna = class{constructor(a,b){this.j=a;this.options=b;this.transactionCount=0;this.B=Math.round((0,g.T)());this.A=!1}add(a,b,c){return g.wr(this,[a],{mode:"readwrite",kc:!0,commit:ur()},d=>d.objectStore(a).add(b,c))}clear(a){return g.wr(this,[a],{mode:"readwrite",
kc:!0},b=>b.objectStore(a).clear())}close(){this.j.close();
this.options?.closed&&this.options.closed()}count(a,b){return g.wr(this,[a],{mode:"readonly",kc:!0,commit:ur()},c=>c.objectStore(a).count(b))}delete(a,b){return g.wr(this,[a],{mode:"readwrite",
kc:!0,commit:ur()&&!(b instanceof IDBKeyRange)},c=>c.objectStore(a).delete(b))}get(a,b){return g.wr(this,[a],{mode:"readonly",
kc:!0,commit:ur()},c=>c.objectStore(a).get(b))}getAll(a,b,c){return g.wr(this,[a],{mode:"readonly",
kc:!0},d=>d.objectStore(a).getAll(b,c))}put(a,b,c){return g.wr(this,[a],{mode:"readwrite",
kc:!0,commit:ur()},d=>d.objectStore(a).put(b,c))}objectStoreNames(){return Array.from(this.j.objectStoreNames)}getName(){return this.j.name}};
  gna = function(a,b,c){return new Promise((d,e)=>{var f=b!==void 0?self.indexedDB.open(a,b):self.indexedDB.open(a);var h=c.blocked,k=c.blocking,l=c.Eaa,m=c.upgrade,p=c.closed,q,u=()=>{q||(q=new fna(f.result,{closed:p}));return q};
f.addEventListener("upgradeneeded",v=>{try{if(v.newVersion===null)throw Error("Invariant: newVersion on IDbVersionChangeEvent is null");if(f.transaction===null)throw Error("Invariant: transaction on IDbOpenDbRequest is null");v.dataLoss&&v.dataLoss!=="none"&&hr("IDB_DATA_CORRUPTED",{reason:v.dataLossMessage||"unknown reason",dbName:jr(a)});let z=u(),F=new g.vr(f.transaction);m&&m(z,L=>v.oldVersion<L&&v.newVersion>=L,F);
F.done.catch(L=>{e(L)})}catch(z){e(z)}});
f.addEventListener("success",()=>{var v=f.result;k&&v.addEventListener("versionchange",()=>{k(u())});
v.addEventListener("close",()=>{hr("IDB_UNEXPECTEDLY_CLOSED",{dbName:jr(a),dbVersion:v.version});l&&l()});
d(u())});
f.addEventListener("error",()=>{e(f.error)});
h&&f.addEventListener("blocked",()=>{h()})})};
  hna = function(a,b,c={}){return gna(a,b,c)};
  Rma = function(a){return new Promise((b,c)=>{Qma(a,b,c)})};
  Er = async function(a,b={}){try{let c=self.indexedDB.deleteDatabase(a),d=b.blocked;d&&c.addEventListener("blocked",()=>{d()});
await Rma(c)}catch(c){throw nr(c,a,"",-1);}};
  ina = function(a,b){return new g.kr("INCOMPATIBLE_DB_VERSION",{dbName:a.name,oldVersion:a.options.version,newVersion:b})};
  g.Dp = function(a,b){return Number(Bp(a,b)||0)};
  gjb = class extends g.kr{constructor(a,b){super("MISSING_OBJECT_STORES",{expectedObjectStores:b,foundObjectStores:a},djb.MISSING_OBJECT_STORES);Object.setPrototypeOf(this,gjb.prototype)}};
  var ijb = class{constructor(a,b){this.name=a;this.options=b;this.B=!0;this.D=this.C=0}A(a,b,c={}){return hna(a,b,c)}delete(a={}){return Er(this.name,a)}open(){if(!this.B)throw ina(this);if(this.j)return this.j;var a,b=()=>{this.j===a&&(this.j=void 0)},c={blocking:e=>{e.close()},
closed:b,Eaa:b,upgrade:this.options.upgrade},d=async()=>{var e=Error().stack??"";try{let k=await this.A(this.name,this.options.version,c);var f=k,h=this.options;let l=[];for(let m of Object.keys(h.zu)){let {Cp:p,vna:q=Number.MAX_VALUE}=h.zu[m];!(f.j.version>=p)||f.j.version>=q||f.j.objectStoreNames.contains(m)||l.push(m)}if(l.length!==0){let m=Object.keys(this.options.zu),p=k.objectStoreNames();if(this.D<g.Dp("ytidb_reopen_db_retries",0))return this.D++,k.close(),gr(new g.kr("DB_REOPENED_BY_MISSING_OBJECT_STORES",
{dbName:this.name,expectedObjectStores:m,foundObjectStores:p})),d();if(this.C<g.Dp("ytidb_remake_db_retries",1))return this.C++,await this.delete(),gr(new g.kr("DB_DELETED_BY_MISSING_OBJECT_STORES",{dbName:this.name,expectedObjectStores:m,foundObjectStores:p})),d();throw new gjb(p,m);}return k}catch(k){if(k instanceof DOMException?k.name==="VersionError":"DOMError"in self&&k instanceof DOMError?k.name==="VersionError":k instanceof Object&&"message"in k&&k.message==="An attempt was made to open a database using a lower version than the existing version."){e=
await this.A(this.name,void 0,{...c,upgrade:void 0});f=e.j.version;if(this.options.version!==void 0&&f>this.options.version+1)throw e.close(),this.B=!1,ina(this,f);return e}b();k instanceof Error&&!g.Cp("ytidb_async_stack_killswitch")&&(k.stack=`${k.stack}\n${e.substring(e.indexOf("\n")+1)}`);throw nr(k,this.name,"",this.options.version??-1);}};
return this.j=a=d()}};
  var Gr = {};
  g.Fr = function(a,b){if(!b)throw g.or("openWithToken",jr(a.name));return a.open()};
  jna = async function(a,b){return g.wr(await g.Fr(Gr,b),["databases"],{kc:!0,mode:"readwrite"},c=>{var d=c.objectStore("databases");return d.get(a.actualName).then(e=>{if(e?a.actualName!==e.actualName||a.publicName!==e.publicName||a.userIdentifier!==e.userIdentifier:1)return d.put(a).then(()=>{})})})};
  Hr = async function(a,b){return a?(await g.Fr(Gr,b)).delete("databases",a):void 0};
  mna = async function(){if(cr()?.hasSucceededOnce)return!0;var a;if(!(a=g.Ir&&kq()&&!lq()||g.Jr)){try{a=self;var b=!!(a.indexedDB&&a.IDBIndex&&a.IDBKeyRange&&a.IDBObjectStore)}catch(c){b=!1}a=!b}if(a||!("IDBTransaction"in self&&"objectStoreNames"in IDBTransaction.prototype))return!1;try{return await jna({actualName:"yt-idb-test-do-not-use",publicName:"yt-idb-test-do-not-use",userIdentifier:void 0},Kr),await Hr("yt-idb-test-do-not-use",Kr),!0}catch(c){return!1}};
  nna = function(){if(Lr!==void 0)return Lr;dr=!0;return Lr=mna().then(a=>{dr=!1;if(br()?.A()){var b={hasSucceededOnce:cr()?.hasSucceededOnce||a};br()?.set("LAST_RESULT_ENTRY_KEY",b,2592E3,!0)}return a})};
  g.Nr = function(){var a=Mr();return a?Promise.resolve(a):nna().then(b=>{b?(g.Ha("ytglobal.idbToken_",Kr),b=Kr):b=void 0;return b})};
  g.Tq = function(a="unknown"){if(g.ip("DATASYNC_ID")!==void 0)return g.ip("DATASYNC_ID");throw new g.Vq("Datasync ID not set",a);};
  Uq = function(){try{return g.Tq(),!0}catch(a){return!1}};
  ona = function(a){if(!Uq())throw a=new g.kr("AUTH_INVALID",{dbName:a}),gr(a),a;var b=g.Tq();return{actualName:`${a}:${b}`,publicName:a,userIdentifier:b}};
  pna = async function(a,b,c,d){var e=Error().stack??"",f=await g.Nr();if(!f)throw b=g.or("openDbImpl",a,b),g.Cp("ytidb_async_stack_killswitch")||(b.stack=`${b.stack}\n${e.substring(e.indexOf("\n")+1)}`),gr(b),b;ir(a);e=c?{actualName:a,publicName:a,userIdentifier:void 0}:ona(a);try{return await jna(e,f),await hna(e.actualName,b,d)}catch(h){try{await Hr(e.actualName,f)}catch{}throw h;}};
  qna = function(a,b,c={}){return pna(a,b,!1,c)};
  rna = function(a,b,c={}){return pna(a,b,!0,c)};
  sna = async function(a,b={}){var c=await g.Nr();c&&(ir(a),a=ona(a),await Er(a.actualName,b),await Hr(a.actualName,c))};
  vna = async function(a,b={}){var c=await g.Nr();c&&(ir(a),await Er(a,b),await Hr(a,c))};
  var wna = class extends ijb{constructor(a,b){super(a,b);this.options=b;ir(a)}A(a,b,c={}){return(this.options.shared?rna:qna)(a,b,{...c})}delete(a={}){return(this.options.shared?vna:sna)(this.name,a)}};
  xna = function(a,b){var c;return()=>{c||(c=new wna(a,b));return c}};
  Or = function(a,b){return xna(a,b)};
  var yna = undefined;
  Pr = function(a){return g.Fr(yna(),a)};
  Cna = async function(a){a=await Pr(a);var b=void 0;await g.wr(a,["hotConfigStore"],{mode:"readwrite",kc:!0},c=>g.Dr(c.objectStore("hotConfigStore").index("hotTimestampIndex"),{direction:"prev"},d=>{b=d.getValue()}));
return b};
  Jna = function(a){Sr(a,g.ip("RAW_HOT_CONFIG_GROUP"));a.Yu(g.ip("SERIALIZED_HOT_HASH_DATA"))};
  zna = async function(a,b,c,d){a={config:a,hashData:b,timestamp:d!==void 0?d:(0,g.T)()};c=await Pr(c);await c.clear("hotConfigStore");return await c.put("hotConfigStore",a)};
  Fna = async function(a){if(a.A)return Vr();if(!a.K)return a=g.or("getHotConfig IDB not initialized"),np(a),Promise.reject(a);var b=Mr(),c=g.ip("TIME_CREATED_MS");if(b){var d=await Cna(b);if(d&&d.timestamp>c)return Sr(a,d.config),a.Yu(d.hashData),Vr()}else d=g.or("getHotConfig token error"),np(d);Jna(a);b&&a.A&&a.hotHashData&&await zna(a.A,a.hotHashData,b,c);return a.A?Vr():(a=new g.Vq("Config not available in ytConfig"),np(a),Promise.reject(a))};
  Bna = async function(a){a=await Pr(a);var b=void 0;await g.wr(a,["coldConfigStore"],{mode:"readwrite",kc:!0},c=>g.Dr(c.objectStore("coldConfigStore").index("coldTimestampIndex"),{direction:"prev"},d=>{b=d.getValue()}));
return b};
  Lna = function(a,b){a.configData=b;g.Ha("yt.gcf.config.coldConfigData",a.configData||null)};
  Wr = function(a,b){a.coldHashData=b;g.Ha("yt.gcf.config.coldHashData",a.coldHashData||null)};
  Ina = function(a){Tr(a,g.ip("RAW_COLD_CONFIG_GROUP"));Wr(a,g.ip("SERIALIZED_COLD_HASH_DATA"));Lna(a,a.j?.configData)};
  Ana = async function(a,b,c,d,e){a={config:a,hashData:b,configData:c,timestamp:e!==void 0?e:(0,g.T)()};d=await Pr(d);await d.clear("coldConfigStore");return await d.put("coldConfigStore",a)};
  Gna = async function(a){if(a.j)return Ur();if(!a.K)return a=g.or("getColdConfig IDB not initialized"),np(a),Promise.reject(a);var b=Mr(),c=g.ip("TIME_CREATED_MS");if(b){var d=await Bna(b);if(d&&d.timestamp>c)return Tr(a,d.config),Lna(a,d.configData),Wr(a,d.hashData),Ur()}else d=g.or("getColdConfig"),np(d);Ina(a);b&&a.j&&a.coldHashData&&a.configData&&await Ana(a.j,a.coldHashData,a.configData,b,c);return a.j?Ur():(a=new g.Vq("Config not available in ytConfig"),np(a),Promise.reject(a))};
  g.Ip = function(a){window.clearTimeout(a)};
  var kp = [];
  Gla = function(a){kp.forEach(b=>{b(a)})};
  g.lp = function(a,b,c,d,e){Hla(a,"ERROR",b,c,d,e);Gla(a)};
  g.mp = function(a){var b=window;return a&&b.yterr?function(...c){try{return a.apply(this,c)}catch(d){g.lp(d instanceof Error?d:Error(String(d)))}}:a};
  g.Gp = function(a,b){typeof a==="function"&&(a=g.mp(a));return window.setTimeout(a,b)};
  Wq = function(a,b,c,d){d!==void 0&&Number.isNaN(Number(d))&&(d=void 0);return(a=g.Ia("yt.scheduler.instance.addJob"))?a(b,c,d):d===void 0?(b(),NaN):g.Gp(b,d||0)};
  var cjb = class{constructor(){this.j=new WeakMap}bl(a,b){return Wq(0,a,1,b)}a5(a){(a=this.j.get(a))&&a()}};
  Yq = class extends cjb{ak(a){if(a===void 0||!Number.isNaN(Number(a))){var b=g.Ia("yt.scheduler.instance.cancelJob");b?b(a):g.Ip(a)}}start(){var a=g.Ia("yt.scheduler.instance.start");a&&a()}pause(){var a=g.Ia("yt.scheduler.instance.pause");a&&a()}};
  g.Zq = function(){Yq.instance||(Yq.instance=new Yq);return Yq.instance};
  g.en = undefined;
  Hna = function(a){if(!a.A||!a.j){if(!Mr()){let b=g.or("scheduleGetConfigs");np(b)}a.D||(a.D=g.en.bl(async()=>{try{await Fna(a)}catch{}try{await Gna(a)}catch{}a.D&&(a.D=0)},100))}};
  var Rr = class{constructor(){this.K=!1;this.B=this.D=0;this.L=new jjb;this.uc={zma:()=>{this.K=!0},
Vka:()=>this.j,
Ona:a=>{Sr(this,a)},
Yu:a=>{this.Yu(a)},
Ina:a=>{Tr(this,a)},
D6:()=>this.coldHashData,
J6:()=>this.hotHashData,
wla:()=>this.A,
kla:()=>Ur(),
mla:()=>Vr(),
lla:()=>g.Ia("yt.gcf.config.coldHashData"),
nla:()=>g.Ia("yt.gcf.config.hotHashData"),
noa:()=>{Hna(this)},
wna:()=>{this.Yu(void 0);Wr(this);delete Rr.instance},
Lna:a=>{this.B=a},
ela:()=>this.B}}C(){return Vr()??g.ip("RAW_HOT_CONFIG_GROUP")}Yu(a){this.hotHashData=a;
g.Ha("yt.gcf.config.hotHashData",this.hotHashData||null)}};
  var at = class{constructor(a){this.key=a}};
  bt = function(a){return new at(a)};
  ypa = function(a,b){var c=a.C.get(b);if(c)try{c.uA(a.resolve(b))}catch(d){c.bV(d)}for(let d of a.children)d.A.has(b)||ypa(d,b)};
  ct = function(a,b){a.A.set(b.Qd,b);ypa(a,b.Qd)};
  var wjb = class{constructor(){this.stack=[]}push(a,b){this.stack.push({key:a,WI:b})}pop(){this.stack.pop()}};
  xpa = function(a,b,c){return a.stack.some(d=>{if(d.key!==b)return!1;var e=Math.min(d.WI.length,c.length);for(let f=0;f<e;f++)if(d.WI[f]!==c[f])return!1;return!0})};
  var dt = Symbol("injectionDeps");
  zpa = function(a,b){return b?b.map(c=>c instanceof at?et(a,c.key,!0):et(a,c)):[]};
  et = function(a,b,c=!1){if(xpa(a.B,b,a.WI))throw Error(`Deps cycle for: ${b}`);if(a.j.has(b))return a.j.get(b);if(a.A.has(b)){a.B.push(b,a.WI);try{let f=a.A.get(b);var d=f;if(d.Px!==void 0)var e=d.Px;else if(d.ZA){let h=d[dt]?zpa(a,d[dt]):[];e=d.ZA(...h)}else if(d.Oh){let h=d.Oh,k=h[dt]?zpa(a,h[dt]):[];e=new h(...k)}else{if(!c)throw Error(`Could not resolve providers for: ${b}`);e=void 0}f.rj||a.j.set(b,e);return e}finally{a.B.pop()}}if(a.parent)return et(a.parent,b,c);if(!c)throw Error(`No provider for: ${b}`);
};
  var Bpa = class{constructor(){this.A=new Map;this.C=new Map;this.j=new Map;this.children=new Set;this.uc={K6:()=>{var a=this.parent?this.parent.uc.K6():new Map;for(let [b,c]of this.A.entries())a.set(b,c);return a},
dna:a=>{var b=this.A.get(a.Qd),c=this.j.has(a.Qd),d=this.j.get(a.Qd);this.j.delete(a.Qd);ct(this,a);return()=>{this.A.delete(a.Qd);this.j.delete(a.Qd);b&&ct(this,b);c&&this.j.set(a.Qd,d)}}};
this.parent=null;this.WI=[this];this.B=new wjb;this.parent?.children.add(this)}resolve(a){return a instanceof at?et(this,a.key,!0):et(this,a)}};
  Apa = undefined;
  ft = undefined;
  gt = function(){ft||(ft=Apa=new Bpa);return ft};
  $pa = function(a){if(g.Cp("enable_web_tiered_gel")){a=Gqa[a||""];var b=gt().resolve(bt(Rr))?.C()?.loggingHotConfig?.eventLoggingConfig?.payloadPolicies;if(b)for(let c=0;c<b.length;c++)if(b[c].payloadNumber===a)return b[c]}};
  aqa = function(a){switch(a){case "DELAYED_EVENT_TIER_UNSPECIFIED":return 0;case "DELAYED_EVENT_TIER_DEFAULT":return 100;case "DELAYED_EVENT_TIER_DISPATCH_TO_EMPTY":return 200;case "DELAYED_EVENT_TIER_FAST":return 300;case "DELAYED_EVENT_TIER_IMMEDIATE":return 400;default:return 200}};
  rt = function(a){return[a.auth===void 0?"undefined":a.auth,a.isJspb===void 0?"undefined":a.isJspb,a.cttAuthInfo===void 0?"undefined":a.cttAuthInfo,a.tier===void 0?"undefined":a.tier].join("/")};
  tt = function(a,b){return a===void 0||a==="undefined"?!0:a===b};
  ut = function(a,b){var c=rt(b);if(a.A[c])return a.A[c];var d=Object.keys(a.store)||[];if(d.length<=1&&rt(b)===d[0])return d;var e=[];for(let h=0;h<d.length;h++){let k=d[h].split("/");if(tt(b.auth,k[0])){var f=b.isJspb;tt(f===void 0?"undefined":f?"true":"false",k[1])&&tt(b.cttAuthInfo,k[2])&&(f=b.tier,f=f===void 0?"undefined":JSON.stringify(f),tt(f,k[3])&&e.push(d[h]))}}return a.A[c]=e};
  var xt = class{constructor(){this.store={};this.j=0;this.A={};this.uc={ila:()=>this.j}}storePayload(a,b){a=rt(a);
this.store[a]?this.store[a].push(b):(this.A={},this.store[a]=[b]);this.j++;g.Cp("more_accurate_gel_parser")&&(b=new CustomEvent("TRANSPORTING_NEW_EVENT"),window.dispatchEvent(b));return a}smartExtractMatchingEntries(a){if(!a.keys.length)return[];var b=ut(this,a.keys.splice(0,1)[0]),c=[];for(let d=0;d<b.length;d++)this.store[b[d]]&&a.sizeLimit&&(this.store[b[d]].length<=a.sizeLimit?(c.push(...this.store[b[d]]),delete this.store[b[d]]):c.push(...this.store[b[d]].splice(0,a.sizeLimit)));this.j-=c.length;
a?.sizeLimit&&c.length<a?.sizeLimit&&(a.sizeLimit-=c.length,c.push(...this.smartExtractMatchingEntries(a)));return c}extractMatchingEntries(a){a=ut(this,a);var b=[];for(let c=0;c<a.length;c++)this.store[a[c]]&&(b.push(...this.store[a[c]]),delete this.store[a[c]]);this.j-=b.length;return b}getSequenceCount(a){a=ut(this,a);var b=0;for(let c=0;c<a.length;c++)b+=this.store[a[c]]?.length||0;return b}};
  zt = function(){var a=g.Ia("yt.logging.ims");a||(a=new xt,g.Ha("yt.logging.ims",a));return a};
  var Vpa = null;
  Upa = function(){return g.Cp("html5_send_qoe_on_gel")||g.Cp("web_send_vss3_isolated_payload")||g.Cp("web_send_vss3_pings")};
  var vt = void 0;
  wt = function(a){Vpa=a;Upa()&&(g.Ga.ytLoggingTransportRegisteredClientCtor_=a);vt=new a};
  Wpa = function(a){return a?a:Upa()?Vpa||g.Ga.ytLoggingTransportRegisteredClientCtor_||null:null};
  Ft = function(a){return a==="gelDebuggingEvent"||a==="watchTimeSegment"};
  Ep = function(){return g.ip("EXPERIMENTS_TOKEN","")};
  Fp = function(){var a=[],b=g.ip("EXPERIMENTS_FORCED_FLAGS",{});for(var c of Object.keys(b))a.push({key:c,value:String(b[c])});c=g.ip("EXPERIMENT_FLAGS",{});for(let d of Object.keys(c))d.startsWith("force_")&&b[d]===void 0&&a.push({key:d,value:String(c[d])});return a};
  Kq = function(){if(!g.Ga.matchMedia)return"WEB_DISPLAY_MODE_UNKNOWN";try{return g.Ga.matchMedia("(display-mode: standalone)").matches?"WEB_DISPLAY_MODE_STANDALONE":g.Ga.matchMedia("(display-mode: minimal-ui)").matches?"WEB_DISPLAY_MODE_MINIMAL_UI":g.Ga.matchMedia("(display-mode: fullscreen)").matches?"WEB_DISPLAY_MODE_FULLSCREEN":g.Ga.matchMedia("(display-mode: browser)").matches?"WEB_DISPLAY_MODE_BROWSER":"WEB_DISPLAY_MODE_UNKNOWN"}catch(a){return"WEB_DISPLAY_MODE_UNKNOWN"}};
  var cs = class extends fi{constructor(a){super(a)}};
  Hba = function(a,b,c){if(a!=null&&a[ug]===vg)return a;if(Array.isArray(a)){var d=a[Qf]|0;c=d|c&32|c&2;c!==d&&(a[Qf]=c);return new b(a)}};
  Yba = function(a,b,c,d){return Pg(a,b,c,d)};
  Og = function(a,b){b===void 0&&(b=a[Qf]|0);b&32&&!(b&4096)&&(a[Qf]=b|4096)};
  dca = function(a,b,c,d,e){var f=!1;d=Yba(a,d,e,h=>{var k=Hba(h,c,b);f=k!==h&&k!=null;return k});
if(d!=null)return f&&!Rf(d)&&Og(a,b),d};
  Wba = function(a){var b=a.Fe,c=b[Qf]|0;return Rf(a,c)?Kg(a,b,c)?Lg(a,b,!0):new a.constructor(Jg(b,c,!1)):a};
  ih = function(a,b,c,d){var e=a.Fe,f=e[Qf]|0;b=dca(e,f,b,c,d);if(b==null)return b;f=e[Qf]|0;if(!Rf(a,f)){let h=Wba(b);h!==b&&(Mg(a)&&(e=a.Fe,f=e[Qf]|0),b=h,f=Rg(e,f,c,b,d),Og(e,f))}return b};
  var $na = {aja:"WEB_DISPLAY_MODE_UNKNOWN",Wia:"WEB_DISPLAY_MODE_BROWSER",Yia:"WEB_DISPLAY_MODE_MINIMAL_UI",Zia:"WEB_DISPLAY_MODE_STANDALONE",Xia:"WEB_DISPLAY_MODE_FULLSCREEN"};
  Lf = function(a){a=Error(a);ed(a,"warning");return a};
  var fg = {};
  Sg = function(a,b,c){Ng(a);var d=a.Fe;Rg(d,d[Qf]|0,b,c);return a};
  vh = function(a,b,c){if(c!=null){if(!fg(c))throw Lf("enum");c|=0}return Sg(a,b,c)};
  xba = function(a){return a.displayName||a.name||"unknown type name"};
  tg = function(a,b){if(!(a instanceof b))throw Error(`Expected instanceof ${xba(b)} but got ${a&&xba(a.constructor)}`);return a};
  gca = function(a,b){a!=null?tg(a,b):a=void 0;return a};
  lh = function(a,b,c,d){d=gca(d,b);Sg(a,c,d);d&&!Rf(d)&&Og(a.Fe);return a};
  Qna = function(a,b,c){a=a.AS;if(a==="WEB"||a==="MWEB"||a===1||a===2)b?(c=ih(b,cs,96)||new cs,a=Kq(),a=Object.keys($na).indexOf(a),a=a===-1?null:a,a!==null&&vh(c,3,a),lh(b,cs,96,c)):c&&(c.client.mainAppWebInfo=c.client.mainAppWebInfo??{},c.client.mainAppWebInfo.webDisplayMode=Kq())};
  jg = function(a){if(a==null)return a;if(typeof a==="string"&&a)a=+a;else if(typeof a!=="number")return;return fg(a)?a>>>0:void 0};
  var Uab = [];
  Ug = undefined;
  Tg = function(a,b,c){a=Pg(a,b,c);return Array.isArray(a)?a:Ug};
  Of = function(a,b){2&b&&(a|=2);return a|1};
  Wg = function(a){return!!(2&a)&&!!(4&a)||!!(256&a)};
  Xg = function(a,b){return a=(2&b?a|2:a&-3)&-273};
  Zba = function(a,b,c,d,e,f,h,k,l){var m=b,p=Wg(b);p&&h===2&&(a=[...a],m=0,b=Xg(b,d),d=Rg(c,d,e,a,f),p=!1);p||(h===1||(h!==4?0:2&b||!(16&b)&&32&d)?(b|=!a.length||k&&!(4096&b)||32&d&&!(4096&b||16&b)?2:256,b!==m&&(a[Qf]=b),Object.freeze(a)):(l||(b|=16),b!==m&&(a[Qf]=b)));2&b||!(4096&b||16&b)||Og(c,d);return a};
  Vg = function(a,b,c,d,e){var f=a.Fe,h=f[Qf]|0;d=d&&d!==4?d!==1&&(a?Rf(a,h):2&h)?1:d:4;e=!!e||d===3;d===2&&Mg(a)&&(f=a.Fe,h=f[Qf]|0);a=Tg(f,b);var k=a===Ug?7:a[Qf]|0,l=Of(k,h);var m=!(4&l);if(m){let p=0,q=0;for(;p<a.length;p++){let u=c(a[p]);u!=null&&(a[q++]=u)}q<p&&(a.length=q);c=(l|4)&-513;l=c&=-1025;l&=-4097}l!==k&&(a[Qf]=l,2&l&&Object.freeze(a));return a=Zba(a,l,f,h,b,void 0,d,m,e)};
  Tf = function(a,b){if(typeof b!=="number"||b<0||b>=a.length)throw Error();};
  var ds = class extends fi{constructor(a){super(a)}fC(a){var b=Vg(this,5,jg,3,!0);Tf(b,a);return b[a]}};
  uh = function(a,b,c){return Sg(a,b,rg(c))};
  Rna = function(a,b){var c=g.Ia("yt.embedded_player.embed_url");c&&(a?(b=ih(a,ds,7)||new ds,uh(b,4,c),lh(a,ds,7,b)):b&&(b.thirdParty={embedUrl:c}))};
  var yba = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  gg = function(a){switch(typeof a){case "bigint":return!0;case "number":return fg(a);case "string":return yba.test(a);default:return!1}};
  var ng = {};
  var rba = undefined;
  var jf = undefined;
  Wf = function(a){if(jf(a)){if(!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a))throw Error(String(a));}else if(rba(a)&&!Number.isSafeInteger(a))throw Error(String(a));return BigInt(a)};
  var lg = {};
  var kg = undefined;
  Aba = function(a){var b=ng(Number(a));if(lg(b))return Wf(b);b=a.indexOf(".");b!==-1&&(a=a.substring(0,b));return Wf(kg(64,BigInt(a)))};
  var Xf = 0;
  var Yf = 0;
  Zf = function(a){var b=a>>>0;Xf=b;Yf=(a-b)/4294967296>>>0};
  $f = function(a){if(a<0){Zf(0-a);a=Xf;var b=Yf;b=~b;a?a=~a+1:b+=1;let [c,d]=[a,b];Xf=c>>>0;Yf=d>>>0}else Zf(a)};
  ag = function(a,b){b>>>=0;a>>>=0;var c;b<=2097151?c=""+(4294967296*b+a):c=""+(BigInt(b)<<BigInt(32)|BigInt(a));return c};
  vba = function(){var a=Xf,b=Yf,c;b&2147483648?c=""+(BigInt(b|0)<<BigInt(32)|BigInt(a>>>0)):c=ag(a,b);return c};
  Bba = function(a){gg(a);a=ng(a);lg(a)?a=String(a):($f(a),a=vba());return a};
  mg = function(a){if(a!=null)a:{if(!gg(a))throw Lf("int64");switch(typeof a){case "string":a=Aba(a);break a;case "bigint":a=Wf(kg(64,a));break a;default:a=Wf(lg(a)?a:Bba(a))}}return a};
  Sna = function(a,b){if(g.Cp("web_log_memory_total_kbytes")&&g.Ga.navigator?.deviceMemory){let c=g.Ga.navigator?.deviceMemory;a?Sg(a,95,mg(c*1E6)):b&&(b.client.memoryTotalKbytes=`${c*1E6}`)}};
  ph = function(a,b,c="",d){return sg(Qg(a,b,d))??c};
  var $r = class extends fi{constructor(a){super(a)}D6(){return ph(this,3)}J6(){return ph(this,5)}Yu(a){return uh(this,5,a)}};
  Tna = function(a,b,c){a.appInstallData&&(b?(c=ih(b,$r,62)??new $r,uh(c,6,a.appInstallData),lh(b,$r,62,c)):c&&(c.client.configInfo=c.client.configInfo||{},c.client.configInfo.appInstallData=a.appInstallData))};
  Ema = function(){var a=g.Ga.navigator;return a?a.connection:void 0};
  var Fma = {bluetooth:"CONN_DISCO",cellular:"CONN_CELLULAR_UNKNOWN",ethernet:"CONN_WIFI",none:"CONN_NONE",wifi:"CONN_WIFI",wimax:"CONN_CELLULAR_4G",other:"CONN_UNKNOWN",unknown:"CONN_UNKNOWN","slow-2g":"CONN_CELLULAR_2G","2g":"CONN_CELLULAR_2G","3g":"CONN_CELLULAR_3G","4g":"CONN_CELLULAR_4G"};
  Gma = function(){var a=Ema();if(a){var b=Fma[a.type||"unknown"]||"CONN_UNKNOWN";a=Fma[a.effectiveType||"unknown"]||"CONN_UNKNOWN";b==="CONN_CELLULAR_UNKNOWN"&&a!=="CONN_UNKNOWN"&&(b=a);if(b!=="CONN_UNKNOWN")return b;if(a!=="CONN_UNKNOWN")return a}};
  var aoa = {CONN_DEFAULT:0,CONN_UNKNOWN:1,CONN_NONE:2,CONN_WIFI:3,CONN_CELLULAR_2G:4,CONN_CELLULAR_3G:5,CONN_CELLULAR_4G:6,CONN_CELLULAR_UNKNOWN:7,CONN_DISCO:8,CONN_CELLULAR_5G:9,CONN_WIFI_METERED:10,CONN_CELLULAR_5G_SA:11,
CONN_CELLULAR_5G_NSA:12,CONN_WIRED:30,CONN_INVALID:31};
  var boa = {EFFECTIVE_CONNECTION_TYPE_UNKNOWN:0,EFFECTIVE_CONNECTION_TYPE_OFFLINE:1,EFFECTIVE_CONNECTION_TYPE_SLOW_2G:2,EFFECTIVE_CONNECTION_TYPE_2G:3,EFFECTIVE_CONNECTION_TYPE_3G:4,EFFECTIVE_CONNECTION_TYPE_4G:5};
  var Hma = {"slow-2g":"EFFECTIVE_CONNECTION_TYPE_SLOW_2G","2g":"EFFECTIVE_CONNECTION_TYPE_2G","3g":"EFFECTIVE_CONNECTION_TYPE_3G","4g":"EFFECTIVE_CONNECTION_TYPE_4G"};
  Ima = function(){var a=Ema();if(a?.effectiveType)return Hma.hasOwnProperty(a.effectiveType)?Hma[a.effectiveType]:"EFFECTIVE_CONNECTION_TYPE_UNKNOWN"};
  Una = function(a,b){var c=Gma();c&&(a?vh(a,61,aoa[c]):b&&(b.client.connectionType=c));g.Cp("web_log_effective_connection_type")&&(c=Ima())&&(a?vh(a,94,boa[c]):b&&(b.client.effectiveConnectionType=c))};
  Ena = function(){if(!Rr.instance){let a=new Rr;Rr.instance=a}return Rr.instance};
  Ona = function(){var a=Ena(),b=(0,g.T)()-a.B;if(!(a.B!==0&&b<g.Dp("send_config_hash_timer"))){b=g.Ia("yt.gcf.config.coldConfigData");var c=g.Ia("yt.gcf.config.hotHashData"),d=g.Ia("yt.gcf.config.coldHashData");b&&c&&d&&(a.B=(0,g.T)());return{coldConfigData:b,hotHashData:c,coldHashData:d}}};
  Vna = function(a,b){var c=Ona();if(c){var d=c.coldConfigData,e=c.coldHashData;c=c.hotHashData;a?(b=ih(a,$r,62)??new $r,d=uh(b,1,d),uh(d,3,e).Yu(c),lh(a,$r,62,b)):b&&(b.client.configInfo=b.client.configInfo||{},d&&(b.client.configInfo.coldConfigData=d),e&&(b.client.configInfo.coldHashData=e),c&&(b.client.configInfo.hotHashData=c))}};
  var Jla = String(op);
  var Kla = {};
  kd = function(a){return decodeURIComponent(a.replace(/\+/g," "))};
  var Mla = /^[\w.]*$/;
  Ila = function(a){return a&&a.match(Mla)?a:kd(a)};
  Ka = function(a){var b=typeof a;return b!="object"?b:a?Array.isArray(a)?"array":b:"null"};
  g.La = function(a){var b=Ka(a);return b=="array"||b=="object"&&typeof a.length=="number"};
  g.zb = function(a,b){for(let c=1;c<arguments.length;c++){let d=arguments[c];if(g.La(d)){let e=a.length||0,f=d.length||0;a.length=e+f;for(let h=0;h<f;h++)a[e+h]=d[h]}else a.push(d)}};
  op = function(a,b){b=a.split(b);var c={};for(let f=0,h=b.length;f<h;f++){let k=b[f].split("=");if(k.length===1&&k[0]||k.length===2)try{let l=Ila(k[0]||""),m=Ila(k[1]||"");if(l in c){let p=c[l];Array.isArray(p)?g.zb(p,m):c[l]=[p,m]}else c[l]=m}catch(l){var d=l,e=k[0];let m=String(op);d.args=[{key:e,value:k[1],query:a,method:Jla===m?"unchanged":m}];Kla.hasOwnProperty(e)||np(d)}}return c};
  qp = function(a){a.charAt(0)==="?"&&(a=a.substring(1));return op(a,"&")};
  Ama = function(a=typeof window!=="undefined"?window:g.Ga?.window){if(!a)return!1;var b=a.location?.hostname||"";return!!((a.location?.pathname||"").includes("/playable")||b.includes("playables")||a.toa)};
  Mq = function(){if(!g.Cp("enable_ipad_webview_innertube_context_override"))return!1;var a=typeof navigator!=="undefined"?navigator:g.Ga?.navigator;if(!(a&&a.platform==="MacIntel"&&a.maxTouchPoints>0&&"standalone"in a))return!1;a=typeof window!=="undefined"?window:g.Ga?.window;return Ama(a)?!(!a?.youtubewebview&&!a?.webkit?.messageHandlers?.youtubewebview):!1};
  g.Yr = function(a){var b={client:{hl:a.CS,gl:a.BS,clientName:a.AS,clientVersion:a.innertubeContextClientVersion,configInfo:a.vM}};navigator.userAgent&&(b.client.userAgent=String(navigator.userAgent));var c=g.Ga.devicePixelRatio;c&&c!=1&&(b.client.screenDensityFloat=String(c));c=Ep();c!==""&&(b.client.experimentsToken=c);c=Fp();c.length>0&&(b.request={internalExperimentFlags:c});Qna(a,void 0,b);Rna(void 0,b);Sna(void 0,b);Tna(a,void 0,b);Una(void 0,b);g.Cp("start_client_gcf")&&Vna(void 0,b);g.ip("DELEGATED_SESSION_ID")&&
!g.Cp("pageid_as_header_web")&&(b.user={onBehalfOfUser:g.ip("DELEGATED_SESSION_ID")});!g.Cp("fill_delegate_context_in_gel_killswitch")&&(a=g.ip("INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT"))&&(b.user={...b.user,serializedDelegationContext:a});a=g.ip("INNERTUBE_CONTEXT");g.Cp("enable_persistent_device_token")&&a?.client?.rolloutToken&&(b.client.rolloutToken=a?.client?.rolloutToken);a=Object;c=a.assign;var d=b.client,e=g.ip("DEVICE",""),f={};for(let [h,k]of Object.entries(qp(e))){e=h;let l=k;e===
"cbrand"?f.deviceMake=l:e==="cmodel"?f.deviceModel=l:e==="cbr"?f.browserName=l:e==="cbrver"?f.browserVersion=l:e==="cos"?f.osName=l:e==="cosver"?f.osVersion=l:e==="cplatform"&&(f.platform=l)}Mq()&&(f.osName="IOS",f.platform="TABLET",f.clientFormFactor="LARGE_FORM_FACTOR");b.client=c.call(a,d,f);g.Cp("web_attention_logging_enabled")&&(b.client.windowWidthPoints=window.innerWidth,b.client.windowHeightPoints=window.innerHeight);return b};
  g.fc = function(a){if(!a||typeof a!=="object")return a;if(typeof a.clone==="function")return a.clone();if(typeof Map!=="undefined"&&a instanceof Map)return new Map(a);if(typeof Set!=="undefined"&&a instanceof Set)return new Set(a);if(a instanceof Date)return new Date(a.getTime());var b=Array.isArray(a)?[]:typeof ArrayBuffer!=="function"||typeof ArrayBuffer.isView!=="function"||!ArrayBuffer.isView(a)||a instanceof DataView?{}:new a.constructor(a.length);for(let c in a)b[c]=g.fc(a[c]);return b};
  qqa = function(a=!1){return a&&g.Cp("vss_through_gel_video_stats")?"video_stats":"log_event"};
  rqa = function(a,b,c){if(c.videoId)var d="VIDEO";else if(c.playlistId)d="PLAYLIST";else return;a.credentialTransferTokenTargetId=c;a.context=a.context||{};a.context.user=a.context.user||{};a.context.user.credentialTransferTokens=[{token:b,scope:d}]};
  Ut = function(){return g.Cp("use_request_time_ms_header")};
  yqa = function(){var a=g.ip("BATCH_CLIENT_COUNTER")||0;a||(a=Math.floor(Math.random()*65535/2));a++;a>65535&&(a=1);hp("BATCH_CLIENT_COUNTER",a);return a};
  sqa = function(a,b,c){Ut()||(a.requestTimeMs=String(b));g.Cp("unsplit_gel_payloads_in_logs")&&(a.unsplitGelPayloadsInLogs=!0);!c&&(b=g.ip("EVENT_ID"))&&(c=yqa(),a.serializedClientEventId={serializedEventId:b,clientCounter:String(c)})};
  tqa = function(a){g.Cp("always_send_and_write")&&(a.writeThenSend=!1)};
  g.x_ = class{constructor(a){this.name=a}};
  var Bqa = {};
  g.R = function(a,b){if(a)return a[b.name]};
  var Cqa = {};
  Mna = async function(a,b,c){if(g.Cp("start_client_gcf")){c&&Sr(a,c);a.Yu(b);let d=Mr();d&&(c||(c=(await Cna(d))?.config),await zna(c,b,d));if(c){a=a.L;for(let e of a.j)e(c)}}};
  Nna = async function(a,b,c){g.Cp("start_client_gcf")&&(Wr(a,b),a=Mr())&&(c||(c=(await Bna(a))?.config),c&&await Ana(c,b,c.configData,a))};
  var M_ = class{constructor(a){this.name=a}toString(){return`InjectionToken(${this.name})`}};
  var Dqa = {};
  uqa = async function(a){a=a?.responseContext?.globalConfigGroup;var b=g.R(a,Bqa),c=a?.hotHashData,d=g.R(a,Cqa),e=a?.coldHashData,f=gt().resolve(bt(Rr));f&&(c&&(b?await Mna(f,c,b):await Mna(f,c)),e&&(d?await Nna(f,e,d):await Nna(f,e)));b=a?.rawFinchStaticConfigGroup;(a=a?.finchStaticHashData)?(c=gt().resolve(bt(Dqa)))?await c.pna({config:b||{},Yja:a||""},"INNERTUBE_RESPONSE"):(b||a)&&np(new g.Vq("FinchConfigManagerService is not present, but Finch config data is present.")):b&&np(new g.Vq("Finch config data is present, but hash is missing."))};
  Pt = function(a){g.lp(a,void 0,void 0,void 0,!0)};
  Qt = function(a,b,c,d,e){a={retry:!0,onSuccess:c,onError:d,networklessOptions:a,dangerousLogToVisitorSession:b,Pja:!!e,headers:{},postBodyFormat:"",postBody:"",compress:g.Cp("compress_gel")||g.Cp("compress_gel_lr")};Ut()&&(a.headers["X-Goog-Request-Time"]=JSON.stringify(Math.round((0,g.T)())));return a};
  var es = {identityType:"UNAUTHENTICATED_IDENTITY_TYPE_UNKNOWN"};
  var Kk = null;
  var Lk = "";
  var Mk = 0;
  qga = function(){Kk=null;Lk="";Mk=0};
  var Nk = null;
  rga = function(){var a=g.Ga?.cookieStore||null;Nk!==a&&(Nk&&(Nk.removeEventListener("change",qga),Nk=null),typeof EventTarget!=="undefined"&&a instanceof EventTarget&&(Nk=a,a.addEventListener("change",qga)))};
  lga = function(a){if(!a)return"";if(/^about:(?:blank|srcdoc)$/.test(a))return window.origin||"";a.indexOf("blob:")===0&&(a=a.substring(5));a=a.split("#")[0].split("?")[0];a=a.toLowerCase();a.indexOf("//")==0&&(a=window.location.protocol+a);/^[\w\-]*:\/\//.test(a)||(a=window.location.href);var b=a.substring(a.indexOf("://")+3),c=b.indexOf("/");c!=-1&&(b=b.substring(0,c));c=a.substring(0,a.indexOf("://"));if(!c)throw Error("URI is missing protocol: "+a);if(c!=="http"&&c!=="https"&&c!=="chrome-extension"&&
c!=="moz-extension"&&c!=="file"&&c!=="android-app"&&c!=="chrome-search"&&c!=="chrome-untrusted"&&c!=="chrome"&&c!=="app"&&c!=="devtools")throw Error("Invalid URI scheme in origin: "+c);a="";var d=b.indexOf(":");if(d!=-1){var e=b.substring(d+1);b=b.substring(0,d);if(c==="http"&&e!=="80"||c==="https"&&e!=="443")a=":"+e}return c+"://"+b+a};
  g.cb = function(a,b,c){Array.prototype.forEach.call(a,b,c)};
  mga = function(){function a(){e[0]=1732584193;e[1]=4023233417;e[2]=2562383102;e[3]=271733878;e[4]=3285377520;p=m=0}
function b(q){for(var u=h,v=0;v<64;v+=4)u[v/4]=q[v]<<24|q[v+1]<<16|q[v+2]<<8|q[v+3];for(v=16;v<80;v++)q=u[v-3]^u[v-8]^u[v-14]^u[v-16],u[v]=(q<<1|q>>>31)&4294967295;q=e[0];var z=e[1],F=e[2],L=e[3],N=e[4];for(v=0;v<80;v++){if(v<40)if(v<20){var S=L^z&(F^L);var Q=1518500249}else S=z^F^L,Q=1859775393;else v<60?(S=z&F|L&(z|F),Q=2400959708):(S=z^F^L,Q=3395469782);S=((q<<5|q>>>27)&4294967295)+S+N+Q+u[v]&4294967295;N=L;L=F;F=(z<<30|z>>>2)&4294967295;z=q;q=S}e[0]=e[0]+q&4294967295;e[1]=e[1]+z&4294967295;e[2]=
e[2]+F&4294967295;e[3]=e[3]+L&4294967295;e[4]=e[4]+N&4294967295}
function c(q,u){if(typeof q==="string"){q=unescape(encodeURIComponent(q));for(var v=[],z=0,F=q.length;z<F;++z)v.push(q.charCodeAt(z));q=v}u||(u=q.length);v=0;if(m==0)for(;v+64<u;)b(q.slice(v,v+64)),v+=64,p+=64;for(;v<u;)if(f[m++]=q[v++],p++,m==64)for(m=0,b(f);v+64<u;)b(q.slice(v,v+64)),v+=64,p+=64}
function d(){var q=[],u=p*8;m<56?c(k,56-m):c(k,64-(m-56));for(var v=63;v>=56;v--)f[v]=u&255,u>>>=8;b(f);for(v=u=0;v<5;v++)for(var z=24;z>=0;z-=8)q[u++]=e[v]>>z&255;return q}
for(var e=[],f=[],h=[],k=[128],l=1;l<64;++l)k[l]=0;var m,p;a();return{reset:a,update:c,digest:d,O5:function(){for(var q=d(),u="",v=0;v<q.length;v++)u+="0123456789ABCDEF".charAt(Math.floor(q[v]/16))+"0123456789ABCDEF".charAt(q[v]%16);return u}}};
  pga = function(a){var b=mga();b.update(a);return b.O5().toLowerCase()};
  nga = function(a,b,c){var d=[],e=[];if((Array.isArray(c)?2:1)==1)return e=[b,a],g.cb(d,function(k){e.push(k)}),pga(e.join(" "));
var f=[],h=[];g.cb(c,function(k){h.push(k.key);f.push(k.value)});
c=Math.floor((new Date).getTime()/1E3);e=f.length==0?[c,b,a]:[f.join(":"),c,b,a];g.cb(d,function(k){e.push(k)});
a=pga(e.join(" "));a=[c,a];h.length==0||a.push(h.join(""));return a.join("_")};
  oga = function(a,b,c){var d=String(g.Ga?.location.href);return d&&a&&b?[b,nga(lga(d),a,c||null)].join(" "):null};
  tga = function(a,b){var c=a?g.Ga.__SAPISID:g.Ga.__APISID;c||typeof document==="undefined"||(c=new Ik(document),c=c.get(a?"SAPISID":"APISID")||c.get("__Secure-3PAPISID"));return c?oga(c,a?"SAPISIDHASH":"APISIDHASH",b):null};
  uga = function(a,b,c,d){(a=g.Ga[a])||typeof document==="undefined"||(a=(new Ik(document)).get(b));return a?oga(a,c,d):null};
  sga = function(){var a=g.Ga.__SAPISID||g.Ga.__APISID||g.Ga.__3PSAPISID||g.Ga.__1PSAPISID||g.Ga.__OVERRIDE_SID;if(a)return!0;typeof document!=="undefined"&&(a=new Ik(document),a=a.get("SAPISID")||a.get("APISID")||a.get("__Secure-3PAPISID")||a.get("__Secure-1PAPISID"));return!!a};
  vga = function(a){rga();var b=lga(g.Ga?.location.href),c=b.indexOf("https:")==0||b.indexOf("chrome-extension:")==0||b.indexOf("chrome-untrusted://new-tab-page")==0||b.indexOf("moz-extension:")==0;b=Array.isArray(a)?`${b}|v2|${a.map(h=>`${h.key}:${h.value}`).join(",")}`:`${b}|v1`;
var d=Date.now(),e=d-Mk;if(c&&Kk!=null&&Lk===b&&e>=0&&e<1E3)return Kk;e=[];if(sga()){var f=tga(c,a);f&&e.push(f);c&&((f=uga("__1PSAPISID","__Secure-1PAPISID","SAPISID1PHASH",a))&&e.push(f),(a=uga("__3PSAPISID","__Secure-3PAPISID","SAPISID3PHASH",a))&&e.push(a))}a=e.length==0?null:e.join(" ");c&&(Kk=a,Lk=b,Mk=d);return a};
  var Lq = class{constructor(){this.aW=!0}Py(a,b){a={};var c=[];"USER_SESSION_ID"in gp&&c.push({key:"u",value:g.ip("USER_SESSION_ID")});if(c=vga(c))a.Authorization=c,c=b=b?.sessionIndex,c===void 0&&(c=Number(g.ip("SESSION_INDEX",0)),c=isNaN(c)?0:c),g.Cp("voice_search_auth_header_removal")||(a["X-Goog-AuthUser"]=c.toString()),"INNERTUBE_HOST_OVERRIDE"in gp||(a["X-Origin"]=window.location.origin),b===void 0&&"DELEGATED_SESSION_ID"in gp&&(a["X-Goog-PageId"]=g.ip("DELEGATED_SESSION_ID"));return a}};
  zma = function(){Lq.instance||(Lq.instance=new Lq);return Lq.instance};
  coa = function(a,b,c={}){var d={};g.ip("EOM_VISITOR_DATA")?d={"X-Goog-EOM-Visitor-Id":g.ip("EOM_VISITOR_DATA")}:d={"X-Goog-Visitor-Id":c.visitorData||g.ip("VISITOR_DATA","")};if(b&&b.includes("www.youtube-nocookie.com"))return d;b=c.wX||g.ip("AUTHORIZATION");b||(a?b=`Bearer ${g.Ia("gapi.auth.getToken")().Eja}`:(a=zma().Py(es),g.Cp("pageid_as_header_web")||delete a["X-Goog-PageId"],d={...d,...a}));b&&(d.Authorization=b);return d};
  g.Wb = function(a,b){return a!==null&&b in a};
  g.jd = function(a){return encodeURIComponent(String(a))};
  Mi = function(a,b,c){if(Array.isArray(b))for(let d=0;d<b.length;d++)Mi(a,String(b[d]),c);else b!=null&&c.push(a+(b===""?"":"="+g.jd(b)))};
  g.Ni = function(a){var b=[];for(let c in a)Mi(c,a[c],b);return b.join("&")};
  Li = function(a,b){if(!b)return a;var c=a.indexOf("#");c<0&&(c=a.length);var d=a.indexOf("?");if(d<0||d>c){d=c;var e=""}else e=a.substring(d+1,c);a=[a.slice(0,d),e,a.slice(c)];c=a[1];a[1]=b?c?c+"&"+b:b:c;return a[0]+(a[1]?"?"+a[1]:"")+a[2]};
  g.Oi = function(a,b){b=g.Ni(b);return Li(a,b)};
  Lla = function(a,b,c){var d=(a||"").split("#",2);a=d[0];d=d.length>1?"#"+d[1]:"";var e=a.indexOf("?"),f=e!==-1?a.substring(0,e):a;a=qp(e!==-1?a.substring(e+1):"");for(let h in b)if(c||!g.Wb(a,h))a[h]=b[h];return g.Oi(f,a)+d};
  tp = function(a,b){return Lla(a,b||{},!0)};
  Xla = function(a,b){b.includeDomain&&(a=document.location.protocol+"//"+document.location.hostname+(document.location.port?":"+document.location.port:"")+a);var c=g.ip("XSRF_FIELD_NAME");if(b=b.urlParams)b[c]&&delete b[c],a=tp(a,b);return a};
  var hda = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
  g.Gi = function(a){return a.match(hda)};
  ida = function(a){return a?decodeURI(a):a};
  g.Hi = function(a){return ida(g.Gi(a)[3]||null)};
  var hc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
  g.ic = function(a,b){for(let e=1;e<arguments.length;e++){var c=arguments[e];for(d in c)a[d]=c[d];for(let f=0;f<hc.length;f++){var d=hc[f];Object.prototype.hasOwnProperty.call(c,d)&&(a[d]=c[d])}}};
  g.$b = function(a){for(let b in a)return!1;return!0};
  var dma = !1;
  Yla = function(a,b){var c=g.ip("XSRF_FIELD_NAME"),d=g.ip("XSRF_TOKEN"),e=b.postBody||"",f=b.postParams,h=g.ip("XSRF_FIELD_NAME"),k;b.headers&&(k=b.headers["Content-Type"]);b.excludeXsrf||g.Hi(a)&&!b.withCredentials&&g.Hi(a)!==document.location.hostname||b.method!=="POST"||k&&k!=="application/x-www-form-urlencoded"||b.postParams&&b.postParams[h]||(f||(f={}),f[c]=d);f&&typeof e==="string"&&(e=qp(e),g.ic(e,f),e=b.postBodyFormat&&b.postBodyFormat==="JSON"?JSON.stringify(e):g.Ni(e));f=e||f&&!g.$b(f);!dma&&
f&&b.method!=="POST"&&(dma=!0,g.lp(Error("AJAX request with postData should use POST")));return e};
  zp = function(a){return a&&"status"in a?a.status:-1};
  g.Ap = function(a){switch(zp(a)){case 200:case 201:case 202:case 203:case 204:case 205:case 206:case 304:return!0;default:return!1}};
  fma = function(a){var b="";g.cb(a.childNodes,c=>{b+=c.nodeValue});
return b};
  ema = function(a){return a?(a=("responseXML"in a?a.responseXML:a).getElementsByTagName("root"))&&a.length>0?a[0]:null:null};
  var Cc = {};
  vaa = function(){var a=null;if(!Cc)return a;try{let b=c=>c;
a=Cc.createPolicy("goog#html",{createHTML:b,createScript:b,createScriptURL:b})}catch(b){}return a};
  Dc = undefined;
  Ec = function(){Dc===void 0&&(Dc=vaa());return Dc};
  var Sc = class{constructor(a){this.j=a}toString(){return this.j+""}};
  Tc = function(a){var b=Ec();a=b?b.createHTML(a):a;return new Sc(a)};
  pc = function(a,b){var c=a.length-b.length;return c>=0&&a.indexOf(b,c)==c};
  g.Ma = function(a){var b=typeof a;return b=="object"&&a!=null||b=="function"};
  gma = function(a){if(g.Ma(a))for(let b in a)b==="html_content"||pc(b,"_html")?a[b]=Tc(a[b]):gma(a[b])};
  bma = function(a,b,c,d){var e=null;switch(b){case "JSON":let f;try{f=c.responseText}catch(h){throw d=Error("Error reading responseText"),d.params=a,np(d),h;}a=c.getResponseHeader("Content-Type")||"";if(f&&a.indexOf("json")>=0){f.substring(0,5)===")]}'\n"&&(f=f.substring(5));try{e=JSON.parse(f)}catch(h){}}break;case "XML":if(a=(a=c.responseXML)?ema(a):null)e={},g.cb(a.getElementsByTagName("*"),h=>{e[h.tagName]=fma(h)})}d&&gma(e);
return e};
  cma = function(a,b,c){if(b&&b.status===204)return!0;switch(a){case "JSON":return!!c;case "XML":return Number(c&&c.return_code)===0;case "RAW":return!0;default:return!!c}};
  var Rla = undefined;
  Sla = function(){if(!Rla)return null;var a=Rla();return"open"in a?a:null};
  vp = function(a){if(!b)var b=window.location.href;var c=g.Gi(a)[1]||null,d=g.Hi(a);c&&d?(a=g.Gi(a),b=g.Gi(b),a=a[3]==b[3]&&a[1]==b[1]&&a[4]==b[4]):a=d?g.Hi(b)===d&&(Number(g.Gi(b)[4]||null)||null)===(Number(g.Gi(a)[4]||null)||null):!0;return a};
  Ii = function(a){return ida(g.Gi(a)[5]||null)};
  var Vib = "absolute_experiments client_dev_domain client_dev_expflag client_dev_regex_map client_dev_root_url client_rollout_override expflag forcedCapability jsfeat jsmode mods theme".split(" ");
  var hma = [];
  up = function(a,b){return Lla(a,b||{},!1)};
  Tla = function(a){var b=window.location.search,c=g.Hi(a);g.Cp("debug_handle_relative_url_for_query_forward_killswitch")||!c&&vp(a)&&(c=document.location.hostname);var d=Ii(a);d=(c=c&&(c.endsWith("youtube.com")||c.endsWith("youtube-nocookie.com")))&&d&&d.startsWith("/api/");if(!c||d)return a;var e=qp(b),f={};g.cb(hma,h=>{e[h]&&(f[h]=e[h])});
return up(a,f)};
  var Vla = {Authorization:"AUTHORIZATION","X-Goog-EOM-Visitor-Id":"EOM_VISITOR_DATA","X-Goog-Visitor-Id":"SANDBOXED_VISITOR_ID","X-Youtube-Domain-Admin-State":"DOMAIN_ADMIN_STATE","X-Youtube-Chrome-Connected":"CHROME_CONNECTED_HEADER","X-YouTube-Client-Name":"INNERTUBE_CONTEXT_CLIENT_NAME","X-YouTube-Client-Version":"INNERTUBE_CONTEXT_CLIENT_VERSION","X-YouTube-Delegation-Context":"INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT","X-YouTube-Device":"DEVICE","X-Youtube-Identity-Token":"ID_TOKEN","X-YouTube-Page-CL":"PAGE_CL",
"X-YouTube-Page-Label":"PAGE_BUILD_LABEL","X-Goog-AuthUser":"SESSION_INDEX","X-Goog-PageId":"DELEGATED_SESSION_ID"};
  var Pla = {};
  var Nla = undefined;
  var oe = window;
  Ola = function(a){a:{let c;try{c=a.j.top.location.href}catch(d){a=2;break a}a=c?c===a.A.location.href?0:1:2}a={dt:Nla,flash:"0",frm:a};try{a.u_tz=-(new Date).getTimezoneOffset();try{var b=oe.history.length}catch(c){b=0}a.u_his=b;a.u_h=oe.screen?.height;a.u_w=oe.screen?.width;a.u_ah=oe.screen?.availHeight;a.u_aw=oe.screen?.availWidth;a.u_cd=oe.screen?.colorDepth}catch(c){}return a};
  g.Dd = function(a,b){this.width=a;this.height=b};
  g.G = g.Dd.prototype;
  g.G.clone = function(){return new g.Dd(this.width,this.height)};
  g.G.aspectRatio = function(){return this.width/this.height};
  g.G.ceil = function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
  g.G.floor = function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
  g.G.round = function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};
  g.G.scale = function(a,b){b=typeof b==="number"?b:a;this.width*=a;this.height*=b;return this};
  Vd = function(a){a=a.document;a=a.compatMode=="CSS1Compat"?a.documentElement:a.body;return new g.Dd(a.clientWidth,a.clientHeight)};
  uda = function(a,b,c=!1){if(a&&b!==null&&b!=b.top){if(!b.top)return new g.Dd(-12245933,-12245933);b=b.top}try{return c?(new g.Dd(b.innerWidth,b.innerHeight)).round():Vd(b||window).round()}catch(d){return new g.Dd(-12245933,-12245933)}};
  var Qla = class{constructor(){this.data=[];this.j=-1}set(a,b=!0){0<=a&&a<52&&Number.isInteger(a)&&this.data[a]!==b&&(this.data[a]=b,this.j=-1)}get(a){return!!this.data[a]}};
  lf = function(a,b=document){return b.createElement(String(a).toLowerCase())};
  var aba = {Pba:"allow-forms",Qba:"allow-modals",Rba:"allow-orientation-lock",Sba:"allow-pointer-lock",Tba:"allow-popups",Uba:"allow-popups-to-escape-sandbox",Vba:"allow-presentation",Wba:"allow-same-origin",Xba:"allow-scripts",Yba:"allow-top-navigation",Zba:"allow-top-navigation-by-user-activation"};
  ef = function(a,b){if(a)for(let c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(a[c],c,a)};
  bba = function(){var a=[];ef(aba,b=>{a.push(b)});
return a};
  te = function(a){var b=!1,c;return function(){b||(c=a(),b=!0);return c}};
  var gba = undefined;
  hba = function(){var a=lf("IFRAME"),b={};g.cb(gba(),c=>{a.sandbox&&a.sandbox.supports&&a.sandbox.supports(c)&&(b[c]=!0)});
return b};
  xka = function(a){a.j===-1&&(a.j=a.data.reduce((b,c,d)=>b+(c?2**d:0),0));
return a.j};
  Xe = function(a){return a.prerendering?3:{visible:1,hidden:2,prerender:3,preview:4,unloaded:5,"":0}[a.visibilityState||a.webkitVisibilityState||a.mozVisibilityState||""]??0};
  Dla = function(){return g.Ia("yt.ads.biscotti.lastId_")||""};
  yp = function(a=Dla()){var b=Pla,c=Object,d=c.assign,e=Ola(b);var f=b.j;try{var h=f.screenX;var k=f.screenY}catch(L){}try{var l=f.outerWidth;var m=f.outerHeight}catch(L){}try{var p=f.innerWidth;var q=f.innerHeight}catch(L){}try{var u=f.screenLeft;var v=f.screenTop}catch(L){}try{p=f.innerWidth,q=f.innerHeight}catch(L){}try{var z=f.screen.availWidth;var F=f.screen.availTop}catch(L){}f=[u,v,h,k,z,F,l,m,p,q];h=uda(!1,b.j.top);k=new Qla;"SVGElement"in g.Ga&&"createElementNS"in g.Ga.document&&k.set(0);l=
hba();l["allow-top-navigation-by-user-activation"]&&k.set(1);l["allow-popups-to-escape-sandbox"]&&k.set(2);g.Ga.crypto&&g.Ga.crypto.subtle&&k.set(3);"TextDecoder"in g.Ga&&"TextEncoder"in g.Ga&&k.set(4);k=xka(k);b=d.call(c,e,{bc:k,bih:h.height,biw:h.width,brdim:f.join(),vis:Xe(b.A),wgl:!!oe.WebGLRenderingContext});b.ca_type="image";a&&(b.bid=a);return b};
  g.Mb = function(a,b,c){for(let d in a)b.call(c,a[d],d,a)};
  pp = function(a){var b=[];g.Mb(a,(c,d)=>{var e=g.jd(d);g.cb(Array.isArray(c)?c:[c],f=>{f==""?b.push(e):b.push(`${e}=${g.jd(f)}`)})});
return b.join("&")};
  Ula = function(a,b={}){var c=vp(a),d=g.ip("INNERTUBE_CLIENT_NAME"),e=g.Cp("web_ajax_ignore_global_headers_if_set");for(let f in Vla){let h=g.ip(Vla[f]),k=f==="X-Goog-AuthUser"||f==="X-Goog-PageId";f!=="X-Goog-Visitor-Id"||h||(h=g.ip("VISITOR_DATA"));!h||!c&&g.Hi(a)||e&&b[f]!==void 0||d==="TVHTML5_UNPLUGGED"&&k||(b[f]=h)}"X-Goog-EOM-Visitor-Id"in b&&"X-Goog-Visitor-Id"in b&&delete b["X-Goog-Visitor-Id"];if(c||!g.Hi(a))b["X-YouTube-Utc-Offset"]=String(-(new Date).getTimezoneOffset());if(c||!g.Hi(a)){let f;
try{f=(new Intl.DateTimeFormat).resolvedOptions().timeZone}catch{}f&&(b["X-YouTube-Time-Zone"]=f)}document.location.hostname.endsWith("youtubeeducation.com")||!c&&g.Hi(a)||(b["X-YouTube-Ad-Signals"]=pp(yp()));return b};
  Kp = function(a,b,c="GET",d="",e,f,h,k=!1,l){var m=Sla();if(!m)return null;var p=()=>{(m&&"readyState"in m?m.readyState:0)===4&&b&&g.mp(b)(m)};
"onloadend"in m?m.addEventListener("loadend",p,!1):m.onreadystatechange=p;g.Cp("debug_forward_web_query_parameters")&&(a=Tla(a));m.open(c,a,!0);f&&(m.responseType=f);h&&(m.withCredentials=!0);c=c==="POST"&&(window.FormData===void 0||!(d instanceof FormData));if(e=Ula(a,e))for(let q in e)m.setRequestHeader(q,e[q]),"content-type"===q.toLowerCase()&&(c=!1);c&&m.setRequestHeader("Content-Type","application/x-www-form-urlencoded");l&&"onprogress"in m&&(m.onprogress=()=>{l(m.responseText)});
if(k&&"setAttributionReporting"in XMLHttpRequest.prototype){a={eventSourceEligible:!0,triggerEligible:!1};try{m.setAttributionReporting(a)}catch(q){np(q)}}m.send(d);return m};
  var ama = Kp;
  g.Lp = function(a,b){var c=b.format||"JSON";a=Xla(a,b);var d=Yla(a,b),e=!1,f=ama(a,k=>{if(!e){e=!0;h&&g.Ip(h);var l=g.Ap(k),m=null,p=400<=k.status&&k.status<500,q=500<=k.status&&k.status<600;if(l||p||q)m=bma(a,c,k,b.convertToSafeHtml);l&&(l=cma(c,k,m));m=m||{};p=b.context||g.Ga;l?b.onSuccess&&b.onSuccess.call(p,k,m):b.onError&&b.onError.call(p,k,m);b.onFinish&&b.onFinish.call(p,k,m)}},b.method,d,b.headers,b.responseType,b.withCredentials,!1,b.onProgress);
d=b.timeout||0;if(b.onTimeout&&d>0){let k=b.onTimeout;var h=g.Gp(()=>{e||(e=!0,f.abort(),g.Ip(h),k.call(b.context||g.Ga,f))},d)}return f};
  Mp = function(a,b){b.method="POST";b.postParams||(b.postParams={});return g.Lp(a,b)};
  var ooa = undefined;
  ioa = function(a){if(g.Cp("body_size_via_text_encoder")&&ooa)return ooa.encode(a).length;try{return(new Blob(a.split(""))).size}catch(b){return np(b),null}};
  g.sf = function(a){var b=[],c=0;for(let d=0;d<a.length;d++){let e=a.charCodeAt(d);e<128?b[c++]=e:(e<2048?b[c++]=e>>6|192:((e&64512)==55296&&d+1<a.length&&(a.charCodeAt(d+1)&64512)==56320?(e=65536+((e&1023)<<10)+(a.charCodeAt(++d)&1023),b[c++]=e>>18|240,b[c++]=e>>12&63|128):b[c++]=e>>12|224,b[c++]=e>>6&63|128),b[c++]=e&63|128)}return b};
  var kjb = undefined;
  var loa = undefined;
  var qo = {};
  var mla = function(){this.input=null;this.TA=this.fl=this.Kz=0;this.output=null;this.iW=this.zf=this.VC=0;this.msg="";this.state=null;this.YQ=2;this.Ke=0};
  Io = function(a){for(var b=a.length;--b>=0;)a[b]=0};
  kla = function(){this.lf=null;this.status=0;this.kh=null;this.wrap=this.pending=this.eI=this.So=0;this.Ee=null;this.Tp=0;this.method=8;this.HC=-1;this.Sx=this.vW=this.Zk=0;this.window=null;this.X2=0;this.head=this.Bs=null;this.e0=this.jZ=this.strategy=this.level=this.yT=this.D_=this.Fn=this.Kc=this.NC=this.Nb=this.Dz=this.X0=this.Lf=this.hn=this.Ut=this.Tt=this.pS=this.lM=this.qf=0;this.qm=new qo.kt(1146);this.Hy=new qo.kt(122);this.Hk=new qo.kt(78);Io(this.qm);Io(this.Hy);Io(this.Hk);this.EX=this.lL=
this.KM=null;this.Ct=new qo.kt(16);this.heap=new qo.kt(573);Io(this.heap);this.rC=this.Vt=0;this.depth=new qo.kt(573);Io(this.depth);this.Zj=this.il=this.dj=this.matches=this.gE=this.Hu=this.LF=this.Lo=this.nH=this.aT=0};
  var Go = {2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"};
  Ho = function(a,b){a.msg=Go[b];return b};
  var yo = Array(256);
  var zo = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  var Ao = Array(29);
  var Bo = Array(512);
  var Co = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  var Do = Array(30);
  var Ko = Array(576);
  Wka = function(a,b){var c=0;do c|=a&1,a>>>=1,c<<=1;while(--b>0);return c>>>1};
  Xka = function(a,b,c){var d=Array(16),e=0,f;for(f=1;f<=15;f++)d[f]=e=e+c[f-1]<<1;for(c=0;c<=b;c++)e=a[c*2+1],e!==0&&(a[c*2]=Wka(d[e]++,e))};
  var Lo = Array(60);
  so = function(a,b,c,d,e){this.S1=a;this.n6=b;this.m6=c;this.U5=d;this.c8=e;this.DZ=a&&a.length};
  ola = undefined;
  pla = undefined;
  var rla = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7];
  qla = undefined;
  var nla = !1;
  to = function(a,b){this.pY=a;this.PC=0;this.Gx=b};
  Yka = function(a){var b;for(b=0;b<286;b++)a.qm[b*2]=0;for(b=0;b<30;b++)a.Hy[b*2]=0;for(b=0;b<19;b++)a.Hk[b*2]=0;a.qm[512]=1;a.Hu=a.gE=0;a.Lo=a.matches=0};
  var Po = function(a,b,c,d){var e=a&65535|0;a=a>>>16&65535|0;for(var f;c!==0;){f=c>2E3?2E3:c;c-=f;do e=e+b[d++]|0,a=a+e|0;while(--f);e%=65521;a%=65521}return e|a<<16|0};
  Ro = function(a){var b=a.Zk,c;do{var d=a.X2-a.Kc-a.Nb;if(a.Nb>=b+(b-262)){qo.xB(a.window,a.window,b,b,0);a.NC-=b;a.Nb-=b;a.hn-=b;var e=c=a.lM;do{var f=a.head[--e];a.head[e]=f>=b?f-b:0}while(--c);e=c=b;do f=a.Bs[--e],a.Bs[e]=f>=b?f-b:0;while(--c);d+=b}if(a.lf.fl===0)break;e=a.lf;c=a.window;f=a.Nb+a.Kc;var h=e.fl;h>d&&(h=d);h===0?c=0:(e.fl-=h,qo.xB(c,e.input,e.Kz,h,f),e.state.wrap===1?e.Ke=Po(e.Ke,c,h,f):e.state.wrap===2&&(e.Ke=Qo(e.Ke,c,h,f)),e.Kz+=h,e.TA+=h,c=h);a.Kc+=c;if(a.Kc+a.dj>=3)for(d=a.Nb-a.dj,
a.qf=a.window[d],a.qf=(a.qf<<a.Ut^a.window[d+1])&a.Tt;a.dj&&!(a.qf=(a.qf<<a.Ut^a.window[d+3-1])&a.Tt,a.Bs[d&a.Sx]=a.head[a.qf],a.head[a.qf]=d,d++,a.dj--,a.Kc+a.dj<3););}while(a.Kc<262&&a.lf.fl!==0)};
  fla = function(a){var b=4093624447,c;for(c=0;c<=31;c++,b>>>=1)if(b&1&&a.qm[c*2]!==0)return 0;if(a.qm[18]!==0||a.qm[20]!==0||a.qm[26]!==0)return 1;for(c=32;c<256;c++)if(a.qm[c*2]!==0)return 1;return 0};
  ala = function(a,b,c,d){var e=b*2,f=c*2;return a[e]<a[f]||a[e]===a[f]&&d[b]<=d[c]};
  xo = function(a,b,c){for(var d=a.heap[c],e=c<<1;e<=a.Vt;){e<a.Vt&&ala(b,a.heap[e+1],a.heap[e],a.depth)&&e++;if(ala(b,d,a.heap[e],a.depth))break;a.heap[c]=a.heap[e];c=e;e<<=1}a.heap[c]=d};
  Eo = function(a,b){var c=b.pY,d=b.Gx.S1,e=b.Gx.DZ,f=b.Gx.U5,h,k=-1;a.Vt=0;a.rC=573;for(h=0;h<f;h++)c[h*2]!==0?(a.heap[++a.Vt]=k=h,a.depth[h]=0):c[h*2+1]=0;for(;a.Vt<2;){var l=a.heap[++a.Vt]=k<2?++k:0;c[l*2]=1;a.depth[l]=0;a.Hu--;e&&(a.gE-=d[l*2+1])}b.PC=k;for(h=a.Vt>>1;h>=1;h--)xo(a,c,h);l=f;do h=a.heap[1],a.heap[1]=a.heap[a.Vt--],xo(a,c,1),d=a.heap[1],a.heap[--a.rC]=h,a.heap[--a.rC]=d,c[l*2]=c[h*2]+c[d*2],a.depth[l]=(a.depth[h]>=a.depth[d]?a.depth[h]:a.depth[d])+1,c[h*2+1]=c[d*2+1]=l,a.heap[1]=l++,
xo(a,c,1);while(a.Vt>=2);a.heap[--a.rC]=a.heap[1];h=b.pY;l=b.PC;d=b.Gx.S1;e=b.Gx.DZ;f=b.Gx.n6;var m=b.Gx.m6,p=b.Gx.c8,q,u=0;for(q=0;q<=15;q++)a.Ct[q]=0;h[a.heap[a.rC]*2+1]=0;for(b=a.rC+1;b<573;b++){var v=a.heap[b];q=h[h[v*2+1]*2+1]+1;q>p&&(q=p,u++);h[v*2+1]=q;if(!(v>l)){a.Ct[q]++;var z=0;v>=m&&(z=f[v-m]);var F=h[v*2];a.Hu+=F*(q+z);e&&(a.gE+=F*(d[v*2+1]+z))}}if(u!==0){do{for(q=p-1;a.Ct[q]===0;)q--;a.Ct[q]--;a.Ct[q+1]+=2;a.Ct[p]--;u-=2}while(u>0);for(q=p;q!==0;q--)for(v=a.Ct[q];v!==0;)d=a.heap[--b],
d>l||(h[d*2+1]!==q&&(a.Hu+=(q-h[d*2+1])*h[d*2],h[d*2+1]=q),v--)}Xka(c,k,a.Ct)};
  dla = function(a,b,c){var d,e=-1,f=b[1],h=0,k=7,l=4;f===0&&(k=138,l=3);b[(c+1)*2+1]=65535;for(d=0;d<=c;d++){var m=f;f=b[(d+1)*2+1];++h<k&&m===f||(h<l?a.Hk[m*2]+=h:m!==0?(m!==e&&a.Hk[m*2]++,a.Hk[32]++):h<=10?a.Hk[34]++:a.Hk[36]++,h=0,e=m,f===0?(k=138,l=3):m===f?(k=6,l=3):(k=7,l=4))}};
  var gla = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
  uo = function(a,b){a.kh[a.pending++]=b&255;a.kh[a.pending++]=b>>>8&255};
  vo = function(a,b,c){a.Zj>16-c?(a.il|=b<<a.Zj&65535,uo(a,a.il),a.il=b>>16-a.Zj,a.Zj+=c-16):(a.il|=b<<a.Zj&65535,a.Zj+=c)};
  wo = function(a,b,c){vo(a,c[b*2],c[b*2+1])};
  ela = function(a,b,c){var d,e=-1,f=b[1],h=0,k=7,l=4;f===0&&(k=138,l=3);for(d=0;d<=c;d++){var m=f;f=b[(d+1)*2+1];if(!(++h<k&&m===f)){if(h<l){do wo(a,m,a.Hk);while(--h!==0)}else m!==0?(m!==e&&(wo(a,m,a.Hk),h--),wo(a,16,a.Hk),vo(a,h-3,2)):h<=10?(wo(a,17,a.Hk),vo(a,h-3,3)):(wo(a,18,a.Hk),vo(a,h-11,7));h=0;e=m;f===0?(k=138,l=3):m===f?(k=6,l=3):(k=7,l=4)}}};
  bla = function(a,b,c){var d=0;if(a.Lo!==0){do{var e=a.kh[a.LF+d*2]<<8|a.kh[a.LF+d*2+1];var f=a.kh[a.aT+d];d++;if(e===0)wo(a,f,b);else{var h=yo[f];wo(a,h+256+1,b);var k=zo[h];k!==0&&(f-=Ao[h],vo(a,f,k));e--;h=e<256?Bo[e]:Bo[256+(e>>>7)];wo(a,h,c);k=Co[h];k!==0&&(e-=Do[h],vo(a,e,k))}}while(d<a.Lo)}wo(a,256,b)};
  Zka = function(a){a.Zj>8?uo(a,a.il):a.Zj>0&&(a.kh[a.pending++]=a.il);a.il=0;a.Zj=0};
  $ka = function(a,b,c){Zka(a);uo(a,c);uo(a,~c);qo.xB(a.kh,a.window,b,c,a.pending);a.pending+=c};
  Jo = function(a){var b=a.state,c=b.pending;c>a.zf&&(c=a.zf);c!==0&&(qo.xB(a.output,b.kh,b.eI,c,a.VC),a.VC+=c,b.eI+=c,a.iW+=c,a.zf-=c,b.pending-=c,b.pending===0&&(b.eI=0))};
  Mo = function(a,b){var c=a.hn>=0?a.hn:-1,d=a.Nb-a.hn,e=0;if(a.level>0){a.lf.YQ===2&&(a.lf.YQ=fla(a));Eo(a,a.KM);Eo(a,a.lL);dla(a,a.qm,a.KM.PC);dla(a,a.Hy,a.lL.PC);Eo(a,a.EX);for(e=18;e>=3&&a.Hk[gla[e]*2+1]===0;e--);a.Hu+=3*(e+1)+5+5+4;var f=a.Hu+3+7>>>3;var h=a.gE+3+7>>>3;h<=f&&(f=h)}else f=h=d+5;if(d+4<=f&&c!==-1)vo(a,b?1:0,3),$ka(a,c,d);else if(a.strategy===4||h===f)vo(a,2+(b?1:0),3),bla(a,Ko,Lo);else{vo(a,4+(b?1:0),3);c=a.KM.PC+1;d=a.lL.PC+1;e+=1;vo(a,c-257,5);vo(a,d-1,5);vo(a,e-4,4);for(f=0;f<e;f++)vo(a,
a.Hk[gla[f]*2+1],3);ela(a,a.qm,c-1);ela(a,a.Hy,d-1);bla(a,a.qm,a.Hy)}Yka(a);b&&Zka(a);a.hn=a.Nb;Jo(a.lf)};
  Uo = function(a,b,c,d,e){this.V6=a;this.b8=b;this.t8=c;this.a8=d;this.func=e};
  hla = function(a,b){var c=a.D_,d=a.Nb,e=a.Fn,f=a.e0,h=a.Nb>a.Zk-262?a.Nb-(a.Zk-262):0,k=a.window,l=a.Sx,m=a.Bs,p=a.Nb+258,q=k[d+e-1],u=k[d+e];a.Fn>=a.jZ&&(c>>=2);f>a.Kc&&(f=a.Kc);do{var v=b;if(k[v+e]===u&&k[v+e-1]===q&&k[v]===k[d]&&k[++v]===k[d+1]){d+=2;for(v++;k[++d]===k[++v]&&k[++d]===k[++v]&&k[++d]===k[++v]&&k[++d]===k[++v]&&k[++d]===k[++v]&&k[++d]===k[++v]&&k[++d]===k[++v]&&k[++d]===k[++v]&&d<p;);v=258-(p-d);d=p-258;if(v>e){a.NC=b;e=v;if(v>=f)break;q=k[d+e-1];u=k[d+e]}}}while((b=m[b&l])>h&&--c!==
0);return e<=a.Kc?e:a.Kc};
  Fo = function(a,b,c){a.kh[a.LF+a.Lo*2]=b>>>8&255;a.kh[a.LF+a.Lo*2+1]=b&255;a.kh[a.aT+a.Lo]=c&255;a.Lo++;b===0?a.qm[c*2]++:(a.matches++,b--,a.qm[(yo[c]+256+1)*2]++,a.Hy[(b<256?Bo[b]:Bo[256+(b>>>7)])*2]++);return a.Lo===a.nH-1};
  So = function(a,b){for(var c;;){if(a.Kc<262){Ro(a);if(a.Kc<262&&b===0)return 1;if(a.Kc===0)break}c=0;a.Kc>=3&&(a.qf=(a.qf<<a.Ut^a.window[a.Nb+3-1])&a.Tt,c=a.Bs[a.Nb&a.Sx]=a.head[a.qf],a.head[a.qf]=a.Nb);c!==0&&a.Nb-c<=a.Zk-262&&(a.Lf=hla(a,c));if(a.Lf>=3)if(c=Fo(a,a.Nb-a.NC,a.Lf-3),a.Kc-=a.Lf,a.Lf<=a.yT&&a.Kc>=3){a.Lf--;do a.Nb++,a.qf=(a.qf<<a.Ut^a.window[a.Nb+3-1])&a.Tt,a.Bs[a.Nb&a.Sx]=a.head[a.qf],a.head[a.qf]=a.Nb;while(--a.Lf!==0);a.Nb++}else a.Nb+=a.Lf,a.Lf=0,a.qf=a.window[a.Nb],a.qf=(a.qf<<a.Ut^
a.window[a.Nb+1])&a.Tt;else c=Fo(a,0,a.window[a.Nb]),a.Kc--,a.Nb++;if(c&&(Mo(a,!1),a.lf.zf===0))return 1}a.dj=a.Nb<2?a.Nb:2;return b===4?(Mo(a,!0),a.lf.zf===0?3:4):a.Lo&&(Mo(a,!1),a.lf.zf===0)?1:2};
  To = function(a,b){for(var c,d;;){if(a.Kc<262){Ro(a);if(a.Kc<262&&b===0)return 1;if(a.Kc===0)break}c=0;a.Kc>=3&&(a.qf=(a.qf<<a.Ut^a.window[a.Nb+3-1])&a.Tt,c=a.Bs[a.Nb&a.Sx]=a.head[a.qf],a.head[a.qf]=a.Nb);a.Fn=a.Lf;a.X0=a.NC;a.Lf=2;c!==0&&a.Fn<a.yT&&a.Nb-c<=a.Zk-262&&(a.Lf=hla(a,c),a.Lf<=5&&(a.strategy===1||a.Lf===3&&a.Nb-a.NC>4096)&&(a.Lf=2));if(a.Fn>=3&&a.Lf<=a.Fn){d=a.Nb+a.Kc-3;c=Fo(a,a.Nb-1-a.X0,a.Fn-3);a.Kc-=a.Fn-1;a.Fn-=2;do++a.Nb<=d&&(a.qf=(a.qf<<a.Ut^a.window[a.Nb+3-1])&a.Tt,a.Bs[a.Nb&a.Sx]=
a.head[a.qf],a.head[a.qf]=a.Nb);while(--a.Fn!==0);a.Dz=0;a.Lf=2;a.Nb++;if(c&&(Mo(a,!1),a.lf.zf===0))return 1}else if(a.Dz){if((c=Fo(a,0,a.window[a.Nb-1]))&&Mo(a,!1),a.Nb++,a.Kc--,a.lf.zf===0)return 1}else a.Dz=1,a.Nb++,a.Kc--}a.Dz&&(Fo(a,0,a.window[a.Nb-1]),a.Dz=0);a.dj=a.Nb<2?a.Nb:2;return b===4?(Mo(a,!0),a.lf.zf===0?3:4):a.Lo&&(Mo(a,!1),a.lf.zf===0)?1:2};
  Vo = [];
  var sla = {};
  Vka = function(a){var b,c,d=a.length,e=0;for(b=0;b<d;b++){var f=a.charCodeAt(b);if((f&64512)===55296&&b+1<d){var h=a.charCodeAt(b+1);(h&64512)===56320&&(f=65536+(f-55296<<10)+(h-56320),b++)}e+=f<128?1:f<2048?2:f<65536?3:4}var k=new qo.dB(e);for(b=c=0;c<e;b++)f=a.charCodeAt(b),(f&64512)===55296&&b+1<d&&(h=a.charCodeAt(b+1),(h&64512)===56320&&(f=65536+(f-55296<<10)+(h-56320),b++)),f<128?k[c++]=f:(f<2048?k[c++]=192|f>>>6:(f<65536?k[c++]=224|f>>>12:(k[c++]=240|f>>>18,k[c++]=128|f>>>12&63),k[c++]=128|f>>>
6&63),k[c++]=128|f&63);return k};
  Wo = function(a){if(!(this instanceof Wo))return new Wo(a);a=this.options=qo.assign({level:-1,method:8,chunkSize:16384,Ux:15,l8:8,strategy:0,to:""},a||{});a.raw&&a.Ux>0?a.Ux=-a.Ux:a.W6&&a.Ux>0&&a.Ux<16&&(a.Ux+=16);this.err=0;this.msg="";this.ended=!1;this.chunks=[];this.lf=new mla;this.lf.zf=0;var b=this.lf;var c=a.level,d=a.method,e=a.Ux,f=a.l8,h=a.strategy;if(b){var k=1;c===-1&&(c=6);e<0?(k=0,e=-e):e>15&&(k=2,e-=16);if(f<1||f>9||d!==8||e<8||e>15||c<0||c>9||h<0||h>4)b=Ho(b,-2);else{e===8&&(e=9);var l=
new kla;b.state=l;l.lf=b;l.wrap=k;l.Ee=null;l.vW=e;l.Zk=1<<l.vW;l.Sx=l.Zk-1;l.pS=f+7;l.lM=1<<l.pS;l.Tt=l.lM-1;l.Ut=~~((l.pS+3-1)/3);l.window=new qo.dB(l.Zk*2);l.head=new qo.kt(l.lM);l.Bs=new qo.kt(l.Zk);l.nH=1<<f+6;l.So=l.nH*4;l.kh=new qo.dB(l.So);l.LF=1*l.nH;l.aT=3*l.nH;l.level=c;l.strategy=h;l.method=d;if(b&&b.state){b.TA=b.iW=0;b.YQ=2;c=b.state;c.pending=0;c.eI=0;c.wrap<0&&(c.wrap=-c.wrap);c.status=c.wrap?42:113;b.Ke=c.wrap===2?0:1;c.HC=0;if(!nla){d=Array(16);for(f=h=0;f<28;f++)for(Ao[f]=h,e=0;e<
1<<zo[f];e++)yo[h++]=f;yo[h-1]=f;for(f=h=0;f<16;f++)for(Do[f]=h,e=0;e<1<<Co[f];e++)Bo[h++]=f;for(h>>=7;f<30;f++)for(Do[f]=h<<7,e=0;e<1<<Co[f]-7;e++)Bo[256+h++]=f;for(e=0;e<=15;e++)d[e]=0;for(e=0;e<=143;)Ko[e*2+1]=8,e++,d[8]++;for(;e<=255;)Ko[e*2+1]=9,e++,d[9]++;for(;e<=279;)Ko[e*2+1]=7,e++,d[7]++;for(;e<=287;)Ko[e*2+1]=8,e++,d[8]++;Xka(Ko,287,d);for(e=0;e<30;e++)Lo[e*2+1]=5,Lo[e*2]=Wka(e,5);ola=new so(Ko,zo,257,286,15);pla=new so(Lo,Co,0,30,15);qla=new so([],rla,0,19,7);nla=!0}c.KM=new to(c.qm,ola);
c.lL=new to(c.Hy,pla);c.EX=new to(c.Hk,qla);c.il=0;c.Zj=0;Yka(c);c=0}else c=Ho(b,-2);c===0&&(b=b.state,b.X2=2*b.Zk,Io(b.head),b.yT=Vo[b.level].b8,b.jZ=Vo[b.level].V6,b.e0=Vo[b.level].t8,b.D_=Vo[b.level].a8,b.Nb=0,b.hn=0,b.Kc=0,b.dj=0,b.Lf=b.Fn=2,b.Dz=0,b.qf=0);b=c}}else b=-2;if(b!==0)throw Error(Go[b]);a.header&&(b=this.lf)&&b.state&&b.state.wrap===2&&(b.state.Ee=a.header);if(a.OF){var m;typeof a.OF==="string"?m=Vka(a.OF):sla.call(a.OF)==="[object ArrayBuffer]"?m=new Uint8Array(a.OF):m=a.OF;a=this.lf;
f=m;h=f.length;if(a&&a.state)if(m=a.state,b=m.wrap,b===2||b===1&&m.status!==42||m.Kc)b=-2;else{b===1&&(a.Ke=Po(a.Ke,f,h,0));m.wrap=0;h>=m.Zk&&(b===0&&(Io(m.head),m.Nb=0,m.hn=0,m.dj=0),c=new qo.dB(m.Zk),qo.xB(c,f,h-m.Zk,m.Zk,0),f=c,h=m.Zk);c=a.fl;d=a.Kz;e=a.input;a.fl=h;a.Kz=0;a.input=f;for(Ro(m);m.Kc>=3;){f=m.Nb;h=m.Kc-2;do m.qf=(m.qf<<m.Ut^m.window[f+3-1])&m.Tt,m.Bs[f&m.Sx]=m.head[m.qf],m.head[m.qf]=f,f++;while(--h);m.Nb=f;m.Kc=2;Ro(m)}m.Nb+=m.Kc;m.hn=m.Nb;m.dj=m.Kc;m.Kc=0;m.Lf=m.Fn=2;m.Dz=0;a.Kz=
d;a.input=e;a.fl=c;m.wrap=b;b=0}else b=-2;if(b!==0)throw Error(Go[b]);this.Dja=!0}};
  tla = function(a){var b=b||{};b.W6=!0;b=new Wo(b);b.push(a,!0);if(b.err)throw b.msg||Go[b.err];return b.result};
  var moa = 0;
  fs = function(){return g.Ia("ytPubsub2Pubsub2Instance")};
  gs = function(a,b){var c=fs();c&&c.publish.call(c,a.toString(),a,b)};
  ks = function(a,b,c={sampleRate:.1}){Math.random()<Math.min(.02,c.sampleRate/100)&&gs("meta_logging_csi_event",{timerName:a,timelineData:b})};
  var koa = undefined;
  var joa = undefined;
  ls = function(a,b,c,d){var e={startTime:(0,g.T)(),ticks:{},infos:{}};try{let h=ioa(b);if(h==null||!(h>joa||h<koa)){var f=tla(loa(b));let k=(0,g.T)();e.ticks.gelc=k;moa++;!g.Cp("gel_compression_csi_killswitch")&&g.Cp("log_gel_compression_latency")&&ks("gel_compression",e,{sampleRate:.1});c.headers||(c.headers={});c.headers["Content-Encoding"]="gzip";c.postBody=f;c.postParams=void 0}d(a,c)}catch(h){np(h),d(a,c)}};
  gn = function(a,b){return a.B?a.B:a.B=new Promise(async c=>{var d=window.AbortController?new window.AbortController:void 0,e=d?.signal,f=!1;try{d&&(a.j=a.eq.bl(()=>{d.abort()},b||2E4)),await fetch("/generate_204",{method:"HEAD",
signal:e}),f=!0}catch{f=!1}finally{a.B=void 0,a.j&&(a.eq.ak(a.j),a.j=0),f!==a.isOnline&&(a.isOnline=f,a.isOnline?a.dispatchEvent("networkstatus-online"):a.dispatchEvent("networkstatus-offline")),c(f)}})};
  gl = function(a){this.src=a;this.listeners={};this.j=0};
  g.G = gl.prototype;
  il = function(a,b,c,d){for(let e=0;e<a.length;++e){let f=a[e];if(!f.removed&&f.listener==b&&f.capture==!!c&&f.handler==d)return e}return-1};
  var wha = 0;
  xha = function(a,b,c,d,e){this.listener=a;this.proxy=null;this.src=b;this.type=c;this.capture=!!d;this.handler=e;this.key=++wha;this.removed=this.MK=!1};
  g.G.add = function(a,b,c,d,e){var f=a.toString();a=this.listeners[f];a||(a=this.listeners[f]=[],this.j++);var h=il(a,b,d,e);h>-1?(b=a[h],c||(b.MK=!1)):(b=new xha(b,this.src,f,!!d,e),b.MK=c,a.push(b));return b};
  fl = function(a){a.removed=!0;a.listener=null;a.proxy=null;a.src=null;a.handler=null};
  g.G.remove = function(a,b,c,d){a=a.toString();if(!(a in this.listeners))return!1;var e=this.listeners[a];b=il(e,b,c,d);return b>-1?(fl(e[b]),g.sb(e,b),e.length==0&&(delete this.listeners[a],this.j--),!0):!1};
  g.G.removeAll = function(a){a=a&&a.toString();var b=0;for(let c in this.listeners)if(!a||c==a){let d=this.listeners[c];for(let e=0;e<d.length;e++)++b,fl(d[e]);delete this.listeners[c];this.j--}return b};
  g.G.tG = function(a,b,c,d){a=this.listeners[a.toString()];var e=-1;a&&(e=il(a,b,c,d));return e>-1?a[e]:null};
  g.Pb = function(a,b,c){for(let d in a)if(b.call(c,a[d],d,a))return!0;return!1};
  g.G.hasListener = function(a,b){var c=a!==void 0,d=c?a.toString():"",e=b!==void 0;return g.Pb(this.listeners,function(f){for(let h=0;h<f.length;++h)if(!(c&&f[h].type!=d||e&&f[h].capture!=b))return!0;return!1})};
  g.rl = function(){g.oj.call(this);this.uo=new gl(this);this.E4=this;this.EU=null};
  g.G = g.rl.prototype;
  var ql = undefined;
  ll = function(a){if(typeof a==="function")return a;a[ql]||(a[ql]=function(b){return a.handleEvent(b)});
return a[ql]};
  var nl = undefined;
  ml = function(a){a=a[nl];return a instanceof gl?a:null};
  g.cl = function(a,b){this.type=a;this.A=this.target=b;this.defaultPrevented=this.B=!1};
  dl = function(a,b){g.cl.call(this,a?a.type:"");this.relatedTarget=this.A=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=this.offsetY=this.offsetX=0;this.key="";this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.timeStamp=0;this.j=null;a&&this.init(a,b)};
  var pl = {};
  Aha = function(a){return a in pl?pl[a]:pl[a]="on"+a};
  var Bha = 0;
  g.hl = function(a,b){var c=b.type;c in a.listeners&&g.tb(a.listeners[c],b)&&(fl(b),a.listeners[c].length==0&&(delete a.listeners[c],a.j--))};
  var vha = undefined;
  el = function(a){return!(!a||!a[vha])};
  ol = function(a){if(typeof a!=="number"&&a&&!a.removed){var b=a.src;if(el(b))g.hl(b.uo,a);else{var c=a.type,d=a.proxy;b.removeEventListener?b.removeEventListener(c,d,a.capture):b.detachEvent?b.detachEvent(Aha(c),d):b.addListener&&b.removeListener&&b.removeListener(d);Bha--;(c=ml(b))?(g.hl(c,a),c.j==0&&(c.src=null,b[nl]=null)):fl(a)}}};
  Cha = function(a,b){if(a.removed)a=!0;else{b=new dl(b,this);let c=a.listener,d=a.handler||a.src;a.MK&&ol(a);a=c.call(d,b)}return a};
  zha = function(){function a(c){return b.call(a.src,a.listener,c)}
var b=Cha;return a};
  yha = function(a,b,c,d,e,f){if(!b)throw Error("Invalid event type");var h=g.Ma(e)?!!e.capture:!!e,k=ml(a);k||(a[nl]=k=new gl(a));c=k.add(b,c,d,h,f);if(c.proxy)return c;d=zha();c.proxy=d;d.src=a;d.listener=c;if(a.addEventListener)e===void 0&&(e=!1),a.addEventListener(b.toString(),d,e);else if(a.attachEvent)a.attachEvent(Aha(b.toString()),d);else if(a.addListener&&a.removeListener)a.addListener(d);else throw Error("addEventListener and attachEvent are unavailable.");Bha++;return c};
  jl = function(a,b,c,d,e){if(Array.isArray(b)){for(let f=0;f<b.length;f++)jl(a,b[f],c,d,e);return null}c=ll(c);return el(a)?a.XM(b,c,g.Ma(d)?!!d.capture:!!d,e):yha(a,b,c,!0,d,e)};
  g.kl = function(a,b,c,d,e){if(d&&d.once)return jl(a,b,c,d,e);if(Array.isArray(b)){for(let f=0;f<b.length;f++)g.kl(a,b[f],c,d,e);return null}c=ll(c);return el(a)?a.listen(b,c,g.Ma(d)?!!d.capture:!!d,e):yha(a,b,c,!1,d,e)};
  g.G.addEventListener = function(a,b,c,d){g.kl(this,a,b,c,d)};
  Dha = function(a,b,c,d,e){if(Array.isArray(b))for(let f=0;f<b.length;f++)Dha(a,b[f],c,d,e);else d=g.Ma(d)?!!d.capture:!!d,c=ll(c),el(a)?a.wd(b,c,d,e):a&&(a=ml(a))&&(b=a.tG(b,c,d,e))&&ol(b)};
  g.G.removeEventListener = function(a,b,c,d){Dha(this,a,b,c,d)};
  sl = function(a,b,c,d){b=a.uo.listeners[String(b)];if(!b)return!0;b=b.concat();var e=!0;for(let f=0;f<b.length;++f){let h=b[f];if(h&&!h.removed&&h.capture==c){let k=h.listener,l=h.handler||h.src;h.MK&&g.hl(a.uo,h);e=k.call(l,d)!==!1&&e}}return e&&!d.defaultPrevented};
  g.G.dispatchEvent = function(a){var b=this.EU;if(b){var c=[];for(var d=1;b;b=b.EU)c.push(b),++d}b=this.E4;d=a.type||a;if(typeof a==="string")a=new g.cl(a,b);else if(a instanceof g.cl)a.target=a.target||b;else{var e=a;a=new g.cl(d,b);g.ic(a,e)}e=!0;var f;if(c)for(f=c.length-1;!a.B&&f>=0;f--){var h=a.A=c[f];e=sl(h,d,!0,a)&&e}a.B||(h=a.A=b,e=sl(h,d,!0,a)&&e,a.B||(e=sl(h,d,!1,a)&&e));if(c)for(f=0;!a.B&&f<c.length;f++)h=a.A=c[f],e=sl(h,d,!1,a)&&e;return e};
  g.G.ka = function(){g.rl.Lh.ka.call(this);this.uo&&this.uo.removeAll(void 0);this.EU=null};
  g.G.listen = function(a,b,c,d){return this.uo.add(String(a),b,!1,c,d)};
  g.G.XM = function(a,b,c,d){return this.uo.add(String(a),b,!0,c,d)};
  g.G.wd = function(a,b,c,d){this.uo.remove(String(a),b,c,d)};
  g.G.tG = function(a,b,c,d){return this.uo.tG(String(a),b,c,d)};
  g.G.hasListener = function(a,b){return this.uo.hasListener(a!==void 0?String(a):void 0,b)};
  var fn = class extends g.rl{constructor(a){super();this.C=this.j=0;this.eq=a??{bl:(b,c)=>setTimeout(b,c),
ak:b=>{clearTimeout(b)}};
this.isOnline=window.navigator?.onLine??!0;this.A=async()=>{await gn(this)};
window.addEventListener("offline",this.A);window.addEventListener("online",this.A);this.C||this.Mf()}dispose(){window.removeEventListener("offline",this.A);window.removeEventListener("online",this.A);this.eq.ak(this.C);delete fn.instance}ej(){return this.isOnline}Mf(){this.C=this.eq.bl(async()=>{this.isOnline?window.navigator?.onLine||await gn(this):await gn(this);this.Mf()},3E4)}};
  wka = function(){var a=g.en;fn.instance||(fn.instance=new fn(a));return fn.instance};
  us = undefined;
  ws = function(){us||(us=new vs("yt.offline"));return us};
  var ys = class extends g.rl{constructor(){super();this.A=!1;this.j=wka();this.j.listen("networkstatus-online",()=>{if(this.A&&g.Cp("offline_error_handling")){var a=ws().get("errors",!0);if(a){for(let b in a)if(a[b]){let c=new g.Vq(b,"sent via offline_errors");c.name=a[b].name;c.stack=a[b].stack;c.level=a[b].level;g.lp(c)}ws().set("errors",{},2592E3,!0)}}})}ej(){return this.j.ej()}Iz(a){this.j.isOnline=a}U6(){var a=window.navigator.onLine;
return a===void 0?!0:a}X5(){this.A=!0}listen(a,b){return this.j.listen(a,b)}FO(a){return gn(this.j,a)}};
  Ooa = function(){if(!ys.instance){let a=g.Ia("yt.networkStatusManager.instance")||new ys;g.Ha("yt.networkStatusManager.instance",a);ys.instance=a}return ys.instance};
  Poa = function(a,b){a.rateLimit?a.j?(g.en.ak(a.C),a.C=g.en.bl(()=>{a.B!==b&&(a.dispatchEvent(b),a.B=b,a.j=(0,g.T)())},a.rateLimit-((0,g.T)()-a.j))):(a.dispatchEvent(b),a.B=b,a.j=(0,g.T)()):a.dispatchEvent(b)};
  var xs = class{constructor(){this.j=new Map;this.A=!1}requestComplete(a,b){b&&(this.A=!0);a=this.removeParams(a);this.j.get(a)||this.j.set(a,b)}isEndpointCFR(a){a=this.removeParams(a);return(a=this.j.get(a))?!1:a===!1&&this.A?!0:null}removeParams(a){return a.split("?")[0]}};
  Noa = function(){if(!xs.instance){let a=g.Ia("yt.networkRequestMonitor.instance")||new xs;g.Ha("yt.networkRequestMonitor.instance",a);xs.instance=a}return xs.instance};
  g.J_ = class extends g.rl{constructor(a={}){super();this.j=this.C=0;this.A=Ooa();var b=g.Ia("yt.networkStatusManager.instance.listen").bind(this.A);b&&(a.rateLimit?(this.rateLimit=a.rateLimit,b("networkstatus-online",()=>{Poa(this,"publicytnetworkstatus-online")}),b("networkstatus-offline",()=>{Poa(this,"publicytnetworkstatus-offline")})):(b("networkstatus-online",()=>{this.dispatchEvent("publicytnetworkstatus-online")}),b("networkstatus-offline",()=>{this.dispatchEvent("publicytnetworkstatus-offline")})))}ej(){var a=
g.Ia("yt.networkStatusManager.instance.isNetworkAvailable");
return a?a.bind(this.A)():!0}Iz(a){var b=g.Ia("yt.networkStatusManager.instance.networkStatusHint").bind(this.A);b&&b(a)}async FO(a){var b=g.Ia("yt.networkStatusManager.instance.sendNetworkCheckRequest").bind(this.A);return g.Cp("skip_network_check_if_cfr")&&Noa().isEndpointCFR("generate_204")?new Promise(c=>{this.Iz(window.navigator?.onLine||!0);c(this.ej())}):b?b(a):!0}};
  K_ = undefined;
  ps = undefined;
  yr = function(a,b){a.j.objectStoreNames.contains(b)&&a.j.deleteObjectStore(b)};
  toa = function(){if(ps)return ps();ps=Or("LogsDatabaseV2",{zu:{LogsRequestsStore:{Cp:2}},shared:!1,upgrade(a,b,c){b(2)&&xr(a,"LogsRequestsStore",{keyPath:"id",autoIncrement:!0});b(3);b(5)&&(c=c.objectStore("LogsRequestsStore"),c.j.indexNames.contains("newRequest")&&c.j.deleteIndex("newRequest"),zr(c,"newRequestV2",["status","interface","timestamp"]));b(7)&&yr(a,"sapisid");b(9)&&yr(a,"SWHealthLog")},version:9});return ps()};
  qs = function(a){return g.Fr(toa(),a)};
  Aoa = async function(a){a=await qs(a);var b=(0,g.T)()-2592E6;await g.wr(a,["LogsRequestsStore"],{mode:"readwrite",kc:!0},c=>g.Br(c.objectStore("LogsRequestsStore"),{},d=>{if(d.getValue().timestamp<=b)return d.delete().then(()=>g.Cr(d))}))};
  zoa = async function(a,b){return(await qs(b)).delete("LogsRequestsStore",a)};
  uoa = function(a){g.Cp("nwl_csi_killswitch")||ks("networkless_performance",a,{sampleRate:1})};
  woa = async function(a,b){var c={startTime:(0,g.T)(),infos:{transactionType:"YT_IDB_TRANSACTION_TYPE_READ"},ticks:{}};b=await qs(b);var d=g.ip("INNERTUBE_CONTEXT_CLIENT_NAME",0),e=[a,d,0];d=[a,d,(0,g.T)()];var f=IDBKeyRange.bound(e,d),h="prev";g.Cp("use_fifo_for_networkless")&&(h="next");var k=void 0;e=a==="NEW"?"readwrite":"readonly";g.Cp("use_readonly_for_get_most_recent_by_status_killswitch")&&(e="readwrite");await g.wr(b,["LogsRequestsStore"],{mode:e,kc:!0},l=>g.Dr(l.objectStore("LogsRequestsStore").index("newRequestV2"),
{query:f,direction:h},m=>{m.getValue()&&(k=m.getValue(),a==="NEW"&&(k.status="QUEUED",m.update(k)))}));
c.ticks.tc=(0,g.T)();uoa(c);return k};
  xoa = async function(a,b){return g.wr(await qs(b),["LogsRequestsStore"],{mode:"readwrite",kc:!0},c=>{var d=c.objectStore("LogsRequestsStore");return d.get(a).then(e=>{if(e)return e.status="QUEUED",d.put(e).then(()=>e)})})};
  yoa = async function(a,b,c=!0,d){return g.wr(await qs(b),["LogsRequestsStore"],{mode:"readwrite",kc:!0},e=>{var f=e.objectStore("LogsRequestsStore");return f.get(a).then(h=>h?(h.status="NEW",c&&(h.sendCount+=1),d!==void 0&&(h.options.compress=d),f.put(h).then(()=>h)):g.pr.resolve(void 0))})};
  voa = async function(a,b){var c={startTime:(0,g.T)(),infos:{transactionType:"YT_IDB_TRANSACTION_TYPE_WRITE"},ticks:{}};b=await qs(b);a={...a,options:JSON.parse(JSON.stringify(a.options)),interface:g.ip("INNERTUBE_CONTEXT_CLIENT_NAME",0)};a=await b.put("LogsRequestsStore",a);c.ticks.tc=(0,g.T)();uoa(c);return a};
  var Koa = 0;
  var ts = {};
  Ioa = function(a,b,c={}){var d=new Image,e=`${Koa++}`;ts[e]=d;d.onload=d.onerror=()=>{b&&ts[e]&&b();delete ts[e]};
c.scrubReferrer&&(d.referrerPolicy="no-referrer");d.src=a};
  var Goa = class{constructor({url:a,poa:b}){this.A=a;this.C=b;this.B=(new Date).getTime()-17040672E5;this.j={};for(var c=/[?&]([^&=]+)=([^&]*)/g;b=c.exec(a);)this.j[b[1]]=b[2]}};
  wk = function(a,b){return b?"&"+a+"="+encodeURIComponent(b):""};
  Tfa = function(a){a=a.C;if(!a)return"";var b=wk("uap",a.platform)+wk("uapv",a.platformVersion)+wk("uafv",a.uaFullVersion)+wk("uaa",a.architecture)+wk("uam",a.model)+wk("uab",a.bitness);a.fullVersionList&&(b+="&uafvl="+encodeURIComponent(a.fullVersionList.map(c=>encodeURIComponent(c.brand)+";"+encodeURIComponent(c.version)).join("|")));
a.wow64!=null&&(b+="&uaw="+Number(a.wow64));return b.slice(1)};
  vk = function(a,...b){b=b.filter(Boolean).join("&");if(!b)return a;var c=a.match(/[?&]adurl=/);return c?a.slice(0,c.index+1)+b+"&"+a.slice(c.index+1):a+(a.indexOf("?")<0?"?":"&")+b};
  var Ri = /#|$/;
  Qi = function(a,b,c,d){for(var e=c.length;(b=a.indexOf(c,b))>=0&&b<d;){var f=a.charCodeAt(b-1);if(f==38||f==63)if(f=a.charCodeAt(b+e),!f||f==61||f==38||f==35)return b;b+=e+1}return-1};
  Si = function(a,b){var c=a.search(Ri),d=Qi(a,0,b,c);if(d<0)return null;var e=a.indexOf("&",d);if(e<0||e>c)e=c;d+=b.length+1;return kd(a.slice(d,e!==-1?e:0))};
  Hoa = function(a,b=""){try{if(window.navigator&&window.navigator.sendBeacon&&window.navigator.sendBeacon(a,b))return!0}catch(c){}return!1};
  g.eq = function(a){var b=g.uc();return b?b.toLowerCase().indexOf(a)>=0:!1};
  g.gq = function(){return g.eq("cobalt")};
  g.rs = function(a,b,c,d,e="",f=!1,h=!1){if(a)if(!c||g.gq()||g.Cp("web_ping_disable_scrub_referrer"))if(e)Kp(a,b,"POST",e,d);else if(g.ip("USE_NET_AJAX_FOR_PING_TRANSPORT",!1)||d||h)Kp(a,b,"GET","",d,void 0,f,h);else{b:{try{c:{var k=new Goa({url:a});if(k.j.dsh==="1")var l=null;else{var m=k.j.ae;if(m==="1"){let q=k.j.adurl;if(q)try{l={version:3,P5:decodeURIComponent(q),N4:vk(k.A,"act=1","ri=1",Tfa(k))};break c}catch(u){}}l=m==="2"?{version:4,P5:vk(k.A,"dct=1","suid="+k.B,"ri=1"),N4:vk(k.A,"act=1","ri=1",
"suid="+k.B)}:null}}if(l){let q=Ii(a);var p=!(!q||!q.endsWith("/aclk")||Si(a,"ri")!=="1");break b}}catch(q){}p=!1}p?Hoa(a)?(b&&b(),c=!0):c=!1:c=!1;c||Ioa(a,b)}else np(new g.Vq("Legacy referrer-scrubbed ping detected")),a&&Ioa(a,void 0,{scrubReferrer:!0})};
  Soa = function(a,b,c){b=g.Cp("web_fp_via_jspb")?Object.assign({},b):b;g.Cp("use_request_time_ms_header")?b.headers&&vp(a)&&(b.headers["X-Goog-Request-Time"]=JSON.stringify(Math.round((0,g.T)()))):b.postParams?.requestTimeMs&&(b.postParams.requestTimeMs=Math.round((0,g.T)()));c&&Object.keys(b).length===0?g.rs(a):b.compress?b.postBody?(typeof b.postBody!=="string"&&(b.postBody=JSON.stringify(b.postBody)),ls(a,b.postBody,b,g.Lp)):ls(a,JSON.stringify(b.postParams),b,Mp):g.Lp(a,b)};
  Moa = function(a){if(g.Cp("offline_error_handling")){var b=ws().get("errors",!0)||{};b[a.message]={name:a.name,stack:a.stack};a.level&&(b[a.message].level=a.level);ws().set("errors",b,2592E3,!0)}};
  g.im = class{constructor(){this.promise=new Promise((a,b)=>{this.resolve=a;this.reject=b})}};
  kna = async function(a,b){var c=[];b=await g.Fr(Gr,b);await g.wr(b,["databases"],{kc:!0,mode:"readonly"},d=>{c.length=0;return g.Br(d.objectStore("databases"),{},e=>{a(e.getValue())&&c.push(e.getValue());return g.Cr(e)})});
return c};
  lna = function(a,b){return kna(c=>c.publicName===a&&c.userIdentifier!==void 0,b)};
  tna = function(a,b,c){a=a.map(async d=>{await Er(d.actualName,b);await Hr(d.actualName,c)});
return Promise.all(a).then(()=>{})};
  una = async function(a){var b={},c=await g.Nr();c&&(ir(a),a=await lna(a,c),await tna(a,b,c))};
  Boa = async function(){await una("LogsDatabaseV2")};
  As = function(a,b){g.Cp("use_event_time_ms_header")&&vp(a)&&(b.headers||(b.headers={}),b.headers["X-Goog-Event-Time"]=JSON.stringify(Math.round((0,g.T)())));return b};
  ms = function(a){return!!a.Fg||a.GK};
  poa = function(a){ms(a)&&!a.QF&&(a.j=!0,a.xL&&Math.random()<=a.UK&&a.hj.d5(a.Fg),a.xO(),a.ii.ej()&&a.B(),a.ii.listen(a.uU,a.B.bind(a)),a.ii.listen(a.NT,a.C.bind(a)))};
  os = function(a,b){a.Z2&&!a.ii.ej()?a.Z2(b):a.handleError(b)};
  qoa = function(a){a=a?.error?.code;return!(a&&a>=400&&a<=599)};
  roa = function(a){a=a?.error?.code;return!(a!==400&&a!==415)};
  soa = function(a,b){if(!ms(a))throw Error("IndexedDB is not supported: updateRequestHandlers");var c=b.options.onError?b.options.onError:()=>{};
b.options.onError=async(e,f)=>{var h=qoa(f),k=roa(f);k&&a.Ua&&a.Ua("web_enable_error_204")&&a.handleError(Error("Request failed due to compression"),b.url,f);if(a.Ua&&a.Ua("nwl_consider_error_code")&&h||a.Ua&&!a.Ua("nwl_consider_error_code")&&a.potentialEsfErrorCounter<=a.dO)if(a.ii.FO&&await a.ii.FO(),!a.ii.ej()){c(e,f);a.Ua&&a.Ua("nwl_consider_error_code")&&b?.id!==void 0&&await a.hj.iV(b.id,a.Fg,!1);return}a.Ua&&a.Ua("nwl_consider_error_code")&&!h&&a.potentialEsfErrorCounter>a.dO||(a.potentialEsfErrorCounter++,
b?.id!==void 0&&(b.sendCount<a.t1?(await a.hj.iV(b.id,a.Fg,!0,k?!1:void 0),a.eq.bl(()=>{a.ii.ej()&&a.B()},a.s1)):await a.hj.QB(b.id,a.Fg)),c(e,f))};
var d=b.options.onSuccess?b.options.onSuccess:()=>{};
b.options.onSuccess=async(e,f)=>{b?.id!==void 0&&await a.hj.QB(b.id,a.Fg);a.ii.Iz&&a.Ua&&a.Ua("vss_network_hint")&&a.ii.Iz(!0);d(e,f)};
return b};
  var njb = class{constructor(a){this.GK=this.j=!1;this.potentialEsfErrorCounter=this.A=0;this.handleError=()=>{};
this.pC=()=>{};
this.now=Date.now;this.QF=!1;this.uc={Kna:b=>{this.Fg=b},
ooa:()=>{this.B()},
a5:()=>{this.C()},
SG:async b=>{await this.SG(b)},
tO:(b,c)=>this.tO(b,c),
xO:()=>{this.xO()}};
this.h2=a.h2??100;this.t1=a.t1??1;this.g1=a.g1??2592E6;this.b1=a.b1??12E4;this.s1=a.s1??5E3;this.Fg=a.Fg??void 0;this.xL=!!a.xL;this.UK=a.UK??.1;this.dO=a.dO??10;a.handleError&&(this.handleError=a.handleError);a.pC&&(this.pC=a.pC);a.QF&&(this.QF=a.QF);a.GK&&(this.GK=a.GK);this.Ua=a.Ua;this.eq=a.eq;this.hj=a.hj;this.ii=a.ii;this.Wu=a.Wu;this.uU=a.uU;this.NT=a.NT;ms(this)&&(!this.Ua||this.Ua("networkless_logging"))&&poa(this)}writeThenSend(a,b={}){if(ms(this)&&this.j){let c={url:a,options:b,timestamp:this.now(),
status:"NEW",sendCount:0};this.hj.set(c,this.Fg).then(d=>{c.id=d;this.ii.ej()&&this.SG(c)}).catch(d=>{this.SG(c);
os(this,d)})}else this.Wu(a,b)}sendThenWrite(a,b={},c){if(ms(this)&&this.j){let d={url:a,
options:b,timestamp:this.now(),status:"NEW",sendCount:0};this.Ua&&this.Ua("nwl_skip_retry")&&(d.skipRetry=c);if(this.ii.ej()||this.Ua&&this.Ua("nwl_aggressive_send_then_write")&&!d.skipRetry){if(!d.skipRetry){let e=b.onError?b.onError:()=>{};
b.onError=async(f,h)=>{await this.hj.set(d,this.Fg).catch(k=>{os(this,k)});
e(f,h)}}this.Wu(a,b,d.skipRetry)}else this.hj.set(d,this.Fg).catch(e=>{this.Wu(a,b,d.skipRetry);
os(this,e)})}else c=this.Ua&&this.Ua("nwl_skip_retry")&&c,this.Wu(a,b,c)}sendAndWrite(a,b={}){if(ms(this)&&this.j){let c={url:a,
options:b,timestamp:this.now(),status:"NEW",sendCount:0},d=!1,e=b.onSuccess?b.onSuccess:()=>{};
c.options.onSuccess=(f,h)=>{c.id!==void 0?this.hj.QB(c.id,this.Fg):d=!0;this.ii.Iz&&this.Ua&&this.Ua("vss_network_hint")&&this.ii.Iz(!0);e(f,h)};
this.Wu(c.url,c.options,void 0,!0);this.hj.set(c,this.Fg).then(f=>{c.id=f;d&&this.hj.QB(c.id,this.Fg)}).catch(f=>{os(this,f)})}else this.Wu(a,b,void 0,!0)}B(){if(!ms(this))throw Error("IndexedDB is not supported: throttleSend");
this.A||(this.A=this.eq.bl(async()=>{var a=await this.hj.bZ("NEW",this.Fg);a?(await this.SG(a),this.A&&(this.A=0,this.B())):this.C()},this.h2))}C(){this.eq.ak(this.A);
this.A=0}async SG(a){if(!ms(this))throw Error("IndexedDB is not supported: immediateSend");a.id!==void 0&&(await this.hj.Y7(a.id,this.Fg)||this.pC(Error("The request cannot be found in the database.")));this.tO(a,this.g1)?(a.skipRetry||(a=soa(this,a)),a&&(a.skipRetry&&a.id!==void 0&&await this.hj.QB(a.id,this.Fg),this.Wu(a.url,a.options,!!a.skipRetry))):(this.pC(Error("Networkless Logging: Stored logs request expired age limit")),a.id!==void 0&&await this.hj.QB(a.id,this.Fg))}tO(a,b){a=a.timestamp;
return!(this.now()-a>=b)}xO(){if(!ms(this))throw Error("IndexedDB is not supported: retryQueuedRequests");this.hj.bZ("QUEUED",this.Fg).then(a=>{a&&!this.tO(a,this.b1)?this.eq.bl(async()=>{a.id!==void 0&&await this.hj.iV(a.id,this.Fg);this.xO()}):this.ii.ej()&&this.B()})}};
  var Qoa = class extends njb{constructor(){K_||(K_=new g.J_({Kma:!0,mka:!0}));super({hj:{d5:Aoa,QB:zoa,bZ:woa,Y7:xoa,iV:yoa,set:voa},ii:K_,handleError:(a,b,c)=>{var d=c?.error?.code;d===400||d===415?(a=new g.Vq(a.message,b,c?.error?.code),np(a,void 0,void 0,void 0,!0)):g.lp(a)},
pC:np,Wu:Soa,now:g.T,Z2:Moa,eq:g.Zq(),uU:"publicytnetworkstatus-online",NT:"publicytnetworkstatus-offline",xL:!0,UK:.1,dO:g.Dp("potential_esf_error_limit",10),Ua:g.Cp,QF:!(Uq()&&g.Hi(document.location.toString())!=="www.youtube-nocookie.com")});this.D=new g.im;g.Cp("networkless_immediately_drop_all_requests")&&Boa();vna("LogsDatabaseV2")}writeThenSend(a,b){b||(b={});b=As(a,b);Uq()||(this.j=!1);super.writeThenSend(a,b)}sendThenWrite(a,b,c){b||(b={});b=As(a,b);Uq()||(this.j=!1);super.sendThenWrite(a,
b,c)}sendAndWrite(a,b){b||(b={});b=As(a,b);Uq()||(this.j=!1);super.sendAndWrite(a,b)}awaitInitialization(){return this.D.promise}};
  var Coa = undefined;
  Doa = function(a){return g.Fr(Coa(),a)};
  Eoa = async function(a){a=await Doa(a);var b=(0,g.T)()-2592E6;await g.wr(a,["SWHealthLog"],{mode:"readwrite",kc:!0},c=>g.Br(c.objectStore("SWHealthLog"),{},d=>{if(d.getValue().timestamp<=b)return d.delete().then(()=>g.Cr(d))}))};
  Foa = async function(a){await (await Doa(a)).clear("SWHealthLog")};
  Roa = async function(a){if(!a.Fg)throw g.or("clearSWHealthLogsDb");Foa(a.Fg).catch(b=>{a.handleError(b)})};
  zs = function(){var a=g.Ia("yt.networklessRequestController.instance");a||(a=new Qoa,g.Ha("yt.networklessRequestController.instance",a),g.Cp("networkless_logging")&&g.Nr().then(b=>{a.Fg=b;poa(a);a.D.resolve();a.xL&&Math.random()<=a.UK&&a.Fg&&Eoa(a.Fg);g.Cp("networkless_immediately_drop_sw_health_store")&&Roa(a)}));
return a};
  var Toa = {};
  g.Bs = function(a,b,c,d){!g.ip("VISITOR_DATA")&&b!=="visitor_id"&&Math.random()<.01&&np(new g.Vq("Missing VISITOR_DATA when sending innertube request.",b,c,d));if(!a.isReady())throw a=new g.Vq("innertube xhrclient not ready",b,c,d),g.lp(a),a;var e={headers:d.headers||{},method:"POST",postParams:c,postBody:d.postBody,postBodyFormat:d.postBodyFormat||"JSON",onTimeout:()=>{d.onTimeout()},
onFetchTimeout:d.onTimeout,onSuccess:(m,p)=>{if(d.onSuccess)d.onSuccess(p)},
onFetchSuccess:m=>{if(d.onSuccess)d.onSuccess(m)},
onProgress:m=>{if(d.onProgress)d.onProgress(m)},
onError:(m,p)=>{if(d.onError)d.onError(p)},
onFetchError:m=>{if(d.onError)d.onError(m)},
timeout:d.timeout,withCredentials:!0,compress:d.compress};e.headers["Content-Type"]||(e.headers["Content-Type"]="application/json");c="";var f=a.config_.SZ;f&&(c=f);f=a.config_.TZ||!1;var h=coa(f,c,d);Object.assign(e.headers,h);e.headers.Authorization&&!c&&f&&(e.headers["x-origin"]=window.location.origin);var k=tp(`${c}${`/youtubei/${a.config_.innertubeApiVersion}/${b}`}`,{alt:"json"}),l=(m=!1)=>{try{if(m&&d.retry&&!d.networklessOptions.bypassNetworkless)e.method="POST",d.networklessOptions.writeThenSend?
zs().writeThenSend(k,e):zs().sendAndWrite(k,e);else if(d.compress)if(e.postBody){let p=e.postBody;typeof p!=="string"&&(p=JSON.stringify(e.postBody));ls(k,p,e,g.Lp)}else ls(k,JSON.stringify(e.postParams),e,Mp);else Mp(k,e)}catch(p){if(p.name==="InvalidAccessError")np(Error("An extension is blocking network request."));else throw p;}};
g.Ia("ytNetworklessLoggingInitializationOptions")&&Toa.isNwlInitialized?nna().then(m=>{l(m)}):l(!1)};
  var Ot = !0;
  hqa = function(a,b,c,d,e={},f,h){if(a.size===0)c();else{var k=Math.round((0,g.T)()),l=a.size;for(let [p,q]of a){a=p;var m=q;let u=g.fc({context:g.Yr(b.config_||g.Xr())});if(!g.La(m)&&!g.Cp("throw_err_when_logevent_malformed_killswitch")){d();break}let v=h||g.Cp("web_vss_routing_check_all_tier_policies")&&Array.isArray(m)&&m.some(X=>Ft(Dt(X)||"")),z=qqa(v);
u.events=m;(m=Mt[a])&&rqa(u,a,m);delete Mt[a];let F=a==="visitorOnlyApprovedKey";sqa(u,k,F);tqa(e);let L=X=>{g.Cp("start_client_gcf")&&g.en.bl(async()=>{await uqa(X)});
l--;l||c()},N=0,S=!1,Q=X=>{S||(S=!0,Pt(X),l--,d())},V=()=>{N++;
if(e.bypassNetworkless&&N===1)try{g.Bs(b,z,u,Qt({writeThenSend:!0},F,L,V,f));Ot=!1;return}catch(X){Q(X);return}l--;l||c()};
try{g.Bs(b,z,u,Qt(e,F,L,V,f)),Ot=!1}catch(X){Q(X)}}}};
  Rha = function(a){a.D||(a.D=!0,g.Dl(a.l6,a))};
  var Wha = qf;
  Tha = function(a,b){a.C=!0;g.Dl(function(){a.C&&Wha.call(null,b)})};
  ab = function(a,b){if(Error.captureStackTrace)Error.captureStackTrace(this,ab);else{let c=Error().stack;c&&(this.stack=c)}a&&(this.message=String(a));b!==void 0&&(this.cause=b)};
  Gl = function(a){ab.call(this,a)};
  g.se = function(){};
  Iha = function(){this.next=this.context=this.A=this.B=this.j=null;this.C=!1};
  var Jha = {};
  Al = function(a,b,c){var d=Jha.get();d.B=a;d.A=b;d.context=c;return d};
  El = function(a,b){a.j||a.Sa!=2&&a.Sa!=3||Rha(a);a.B?a.B.next=b:a.j=b;a.B=b};
  Nha = function(a,b,c,d){El(a,Al(b||g.se,c||null,d))};
  Uha = function(a,b,c,d,e){function f(l){k||(k=!0,d.call(e,l))}
function h(l){k||(k=!0,c.call(e,l))}
var k=!1;try{b.call(a,h,f)}catch(l){f(l)}};
  Kha = function(a,b,c,d){if(a instanceof g.zl)return Nha(a,b,c,d),!0;if(a)try{var e=!!a.$goog_Thenable}catch(f){e=!1}else e=!1;if(e)return a.then(b,c,d),!0;if(g.Ma(a))try{let f=a.then;if(typeof f==="function")return Uha(a,f,b,c,d),!0}catch(f){return c.call(d,f),!0}return!1};
  yl = function(a,b,c){a.Sa==0&&(a===c&&(b=3,c=new TypeError("Promise cannot resolve to itself")),a.Sa=1,Kha(c,a.Vaa,a.Waa,a)||(a.K=c,a.Sa=b,a.A=null,Rha(a),b!=3||c instanceof Gl||Tha(a,c)))};
  g.zl = function(a,b){this.Sa=0;this.K=void 0;this.B=this.j=this.A=null;this.C=this.D=!1;if(a!=g.se)try{let c=this;a.call(b,function(d){yl(c,2,d)},function(d){yl(c,3,d)})}catch(c){yl(this,3,c)}};
  g.G = g.zl.prototype;
  var tl = undefined;
  g.G.finally = function(a){a=tl(a);return new g.zl((b,c)=>{Nha(this,d=>{a();b(d)},d=>{a();
c(d)})})};
  Sha = function(a,b,c,d){var e=Al(null,null,null);e.j=new g.zl(function(f,h){e.B=b?function(k){try{let l=b.call(d,k);f(l)}catch(l){h(l)}}:f;
e.A=c?function(k){try{let l=c.call(d,k);l===void 0&&k instanceof Gl?h(k):f(l)}catch(l){h(l)}}:h});
e.j.A=a;El(a,e);return e.j};
  g.G.Zl = function(a,b){return Sha(this,null,tl(a),b)};
  g.G.catch = {};
  Pha = function(a){var b=null;a.j&&(b=a.j,a.j=b.next,b.next=null);a.j||(a.B=null);return b};
  Vha = function(a,b,c){b==2?a.B.call(a.context,c):a.A&&a.A.call(a.context,c)};
  Qha = function(a,b,c,d){if(c==3&&b.A&&!b.C)for(;a&&a.C;a=a.A)a.C=!1;if(b.j)b.j.A=null,Vha(b,c,d);else try{b.C?b.B.call(b.context):Vha(b,c,d)}catch(e){Wha.call(null,e)}Jha.put(b)};
  Oha = function(a,b){if(a.Sa==0)if(a.A){var c=a.A;if(c.j){var d=0,e=null,f=null;for(let h=c.j;h&&(h.C||(d++,h.j==a&&(e=h),!(e&&d>1)));h=h.next)e||(f=h);e&&(c.Sa==0&&d==1?Oha(c,b):(f?(d=f,d.next==c.B&&(c.B=d),d.next=d.next.next):Pha(c),Qha(c,e,3,b)))}a.A=null}else yl(a,3,b)};
  g.G.cancel = function(a){if(this.Sa==0){let b=new Gl(a);g.Dl(function(){Oha(this,b)},this)}};
  g.G.Vaa = function(a){this.Sa=0;yl(this,2,a)};
  g.G.Waa = function(a){this.Sa=0;yl(this,3,a)};
  g.G.l6 = function(){for(var a;a=Pha(this);)Qha(this,a,this.Sa,this.K);this.D=!1};
  bqa = function(a,b){if(a.endpoint==="log_event"){g.Cp("more_accurate_gel_parser")&&zt().storePayload({isJspb:!1},a.payload);Bt(a);var c=Ct(a),d=new Map;d.set(c,[a.payload]);var e=Dt(a.payload)||"";(a=Wpa(b))&&wt(a);return new g.zl((f,h)=>{vt&&vt.isReady()?hqa(d,vt,f,h,{bypassNetworkless:!0},!0,Ft(e)):f()})}};
  var Et = {};
  var N_ = class{constructor(){this.C=this.A=this.B=0;this.j=!1}};
  var Fqa = {};
  var mqa = {};
  var Eqa = {};
  var lqa = {};
  Gt = function(a,b=200){return a?b===300?lqa:Eqa:b===300?mqa:Fqa};
  Nt = function(a){g.Cp("transport_use_scheduler")?g.en.ak(a):g.Ip(a)};
  var Rt = 1;
  var At = new Map;
  g.St = class extends fi{constructor(a){super(a)}};
  ig = function(a){if(a==null)return a;if(typeof a==="string"&&a)a=+a;else if(typeof a!=="number")return;return fg(a)?a|0:void 0};
  qh = function(a,b){a=Qg(a,b);return(a==null?a:fg(a)?a|0:void 0)??0};
  var agb = class extends fi{constructor(a){super(a)}};
  var Wna = class extends fi{constructor(a){super(a)}getDeviceId(){return ph(this,6)}fC(a){var b=Vg(this,9,ig,3,!0);Tf(b,a);return b[a]}getPlayerType(){return qh(this,36)}setHomeGroupInfo(a){return lh(this,agb,81,a)}clearLocationPlayabilityToken(){return Sg(this,89)}};
  var Zr = class extends fi{constructor(a){super(a)}B(a){return lh(this,Wna,1,a)}};
  dg = function(a){if(a!=null&&typeof a!=="number")throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);return a};
  var Xna = class extends fi{constructor(a){super(a)}};
  var as = [2,3,4,5,6];
  var Yna = class extends fi{constructor(a){super(a)}getValue(){return ph(this,gh(this,as,2))}clearValue(){return eh(this,2,as)}};
  jh = function(a,b,c,d,e,f,h,k,l){f=f&&f!==4?f!==1&&(a?Rf(a,c):2&c)?1:f:4;k=!!k||f===3;var m=!!l&&!(a?Rf(a,c):2&c);(f===2||m)&&a&&Mg(a)&&(b=a.Fe,c=b[Qf]|0);a=Tg(b,e,h);var p=a===Ug?7:a[Qf]|0,q=Of(p,c);if(l=!(4&q)){var u=a,v=c;let z=!!(2&q);z&&(v|=2);let F=!z,L=!0,N=0,S=0;for(;N<u.length;N++){let Q=Hba(u[N],d,v);if(Q instanceof d){if(!z){let V=Rf(Q);F&&(F=!V);L&&(L=V)}u[S++]=Q}}S<N&&(u.length=S);q|=4;q=L?q&-4097:q|4096;q=F?q|8:q&-9}q!==p&&(a[Qf]=q,2&q&&Object.freeze(a));if(m&&!(8&q||!a.length&&(f===1||
(f!==4?0:2&q||!(16&q)&&32&c)))){Wg(q)&&(a=[...a],q=Xg(q,c),c=Rg(b,c,e,a,h));d=a;m=q;for(p=0;p<d.length;p++)u=d[p],q=Wba(u),u!==q&&(d[p]=q);m|=8;q=m=d.length?m|4096:m&-4097;a[Qf]=q}return a=Zba(a,q,b,c,e,h,f,l,k)};
  nh = function(a,b,c,d){Ng(a);var e=a.Fe;a=jh(a,e,e[Qf]|0,c,b,2,void 0,!0);d=d!=null?tg(d,c):new c;a.push(d);b=c=a===Ug?7:a[Qf]|0;(d=Rf(d))?(c&=-9,a.length===1&&(c&=-4097)):c|=4096;c!==b&&(a[Qf]=c);d||Og(e)};
  var bs = class extends fi{constructor(a){super(a)}setSafetyMode(a){return vh(this,5,a)}};
  Bma = function(a){switch(a){case "DESKTOP":return 1;case "UNKNOWN_PLATFORM":return 0;case "TV":return 2;case "GAME_CONSOLE":return 3;case "MOBILE":return 4;case "TABLET":return 5}};
  zba = function(a){if(typeof a!=="number")throw Lf("int32");if(!fg(a))throw Lf("int32");return a|0};
  hg = function(a){return a==null?a:zba(a)};
  Zna = function(a){var b=new Zr,c=new Wna;uh(c,1,a.CS);uh(c,2,a.BS);vh(c,16,a.QZ);uh(c,17,a.innertubeContextClientVersion);if(a.vM){var d=a.vM,e=new $r;d.coldConfigData&&uh(e,1,d.coldConfigData);d.appInstallData&&uh(e,6,d.appInstallData);d.coldHashData&&uh(e,3,d.coldHashData);d.hotHashData&&e.Yu(d.hotHashData);lh(c,$r,62,e)}(d=g.Ga.devicePixelRatio)&&d!=1&&Sg(c,65,dg(d));d=Ep();d!==""&&uh(c,54,d);d=Fp();if(d.length>0){e=new Xna;for(let f=0;f<d.length;f++){let h=new Yna;uh(h,1,d[f].key);eh(h,2,as,rg(d[f].value));
nh(e,15,Yna,h)}lh(b,Xna,5,e)}Qna(a,c);Rna(b);Sna(c);Tna(a,c);Una(c);g.Cp("start_client_gcf")&&Vna(c);g.ip("DELEGATED_SESSION_ID")&&!g.Cp("pageid_as_header_web")&&(a=new bs,uh(a,3,g.ip("DELEGATED_SESSION_ID")));!g.Cp("fill_delegate_context_in_gel_killswitch")&&(a=g.ip("INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT"))&&(d=ih(b,bs,3)||new bs,a=uh(d,18,a),lh(b,bs,3,a));a=g.ip("DEVICE","");for(let [f,h]of Object.entries(qp(a)))a=f,d=h,a==="cbrand"?uh(c,12,d):a==="cmodel"?uh(c,13,d):a==="cbr"?uh(c,87,
d):a==="cbrver"?uh(c,88,d):a==="cos"?uh(c,18,d):a==="cosver"?uh(c,19,d):a==="cplatform"&&vh(c,42,Bma(d));Mq()&&(a=uh(c,18,"IOS"),a=vh(a,42,5),vh(a,46,2));g.Cp("web_attention_logging_enabled")&&(Sg(c,55,hg(window.innerWidth)),Sg(c,56,hg(window.innerHeight)));b.B(c);return b};
  var Aqa = class extends fi{constructor(a){super(a)}getToken(){return sh(this,2)}setToken(a){return uh(this,2,a)}};
  vqa = function(a,b,c){if(c.getVideoId())var d=1;else if(c.getPlaylistId())d=2;else return;lh(a,jqa,4,c);a=ih(a,Zr,1)||new Zr;c=ih(a,bs,3)||new bs;var e=new Aqa;e.setToken(b);vh(e,1,d);nh(c,12,Aqa,e);lh(a,bs,3,c)};
  th = function(a,b,c){return Sg(a,b,mg(c))};
  var zqa = class extends fi{constructor(a){super(a)}};
  wqa = function(a,b,c){Ut()||th(a,2,b);if(!c&&(b=g.ip("EVENT_ID"))){c=yqa();let d=new zqa;uh(d,1,b);th(d,2,c);lh(a,zqa,5,d)}};
  var Fc = class{constructor(a){this.j=a}toString(){return this.j+""}};
  Gc = function(a){var b=Ec();a=b?b.createScriptURL(a):a;return new Fc(a)};
  Zo = function(a){return a?(a=a.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue)?Gc(a):null:null};
  var pt = void 0;
  Spa = function(){pt||(pt=Zo(g.ip("WORKER_SERIALIZATION_URL")));return pt||void 0};
  Hc = function(a){if(a instanceof Fc)return a.j;throw Error("");};
  var qt = void 0;
  Tpa = function(){var a=Spa();qt||a===void 0||(qt=new Worker(Hc(a),void 0));return qt};
  var Tt = class extends fi{constructor(a){super(a,500)}};
  xqa = function(a,b){if(b){let d=[];for(let e=0;e<b.length;e++)try{d.push(new Tt(b[e]))}catch{Pt(new g.Vq("Transport failed to deserialize "+String(b[e])))}b=d}else b=[];for(var c of b)nh(a,3,Tt,c);c={startTime:(0,g.T)(),ticks:{},infos:{}};a=a.Kh();c.ticks.geljspc=(0,g.T)();g.Cp("log_jspb_serialize_latency")&&ks("gel_jspb_serialize",c,{sampleRate:.1});return a};
  Ypa = function(a,b,c,d={},e,f,h,k={value:0}){f=qqa(f);var l=!1,m=p=>{l||(l=!0,Pt(p),k.value--,k.value||c())};
d=Qt(d,h,p=>{g.Cp("start_client_gcf")&&g.en.bl(async()=>{await uqa(p)});
k.value--;k.value||c()},()=>{k.value--;
k.value||c()},e);
d.headers["Content-Type"]="application/json+protobuf";d.postBodyFormat="JSPB";d.postBody=a;try{g.Bs(b,f,"",d),Ot=!1}catch(p){m(p)}};
  iqa = function(a,b,c,d={},e,f){if(a.size===0)c();else{var h=Math.round((0,g.T)()),k={value:a.size},l=new Map([...a]);for(let [m]of l){let p=m;l=a.get(p);let q=F=>{delete Lt[p];At.delete(Rt);Pt(F);k.value--;k.value||c()},u=new g.St;
try{let F=Zna(b.config_||g.Xr());lh(u,Zr,1,F);let L=Lt[p];L&&vqa(u,p,L);delete Lt[p]}catch(F){q(F);continue}let v=p==="visitorOnlyApprovedKey";wqa(u,h,v);tqa(d);if(g.Cp("jspb_serialize_with_worker")){let F=Tpa();if(F&&d.writeThenSend){At.set(Rt,{client:b,resolve:c,networklessOptions:d,isIsolated:e,useVSSEndpoint:f,dangerousLogToVisitorSession:v,requestsOutstanding:k});try{F.postMessage({op:"gelBatchToSerialize",batchRequest:Hg(u),clientEvents:l,key:Rt})}catch(L){q(L);break}Rt++;break}}let z;try{z=
xqa(u,l)}catch(F){q(F);continue}Ypa(z,b,c,d,e,f,v,k)}}};
  kqa = function(a,b,c={},d=!1,e=200,f=!1){var h=vt,k=new Map,l=new Map,m={isJspb:d,cttAuthInfo:void 0,tier:e},p={isJspb:d,cttAuthInfo:void 0};if(d){for(let q of Object.keys(Et))b=g.Cp("enable_web_tiered_gel")?zt().smartExtractMatchingEntries({keys:[m,p],sizeLimit:1E3}):zt().extractMatchingEntries({isJspb:!0,cttAuthInfo:q}),b.length>0&&k.set(q,b),(g.Cp("web_fp_via_jspb_and_json")&&c.writeThenSend||!g.Cp("web_fp_via_jspb_and_json"))&&delete Et[q];iqa(k,h,a,c,!1,f)}else{for(let q of Object.keys(Et))k=g.Cp("enable_web_tiered_gel")?
zt().smartExtractMatchingEntries({keys:[{isJspb:!1,cttAuthInfo:q,tier:e},{isJspb:!1,cttAuthInfo:q}],sizeLimit:1E3}):zt().extractMatchingEntries({isJspb:!1,cttAuthInfo:q}),k.length>0&&l.set(q,k),(g.Cp("web_fp_via_jspb_and_json")&&c.writeThenSend||!g.Cp("web_fp_via_jspb_and_json"))&&delete Et[q];hqa(l,h,a,b,c,!1,f)}};
  Ht = function(a={},b=!1,c){new g.zl((d,e)=>{var f=Gt(b,c);Nt(f.B);Nt(f.A);f.A=0;if(vt&&vt.isReady()){var h=f.j;f.j=!1;if(g.Cp("enable_web_tiered_gel")&&g.Cp("web_vss_routing_check_all_tier_policies")){f=Gt(b,300);let k=Gt(b,200);h=h||f.j||k.j;f.j=!1;k.j=!1}c===void 0&&g.Cp("enable_web_tiered_gel")?kqa(d,e,a,b,300,h):kqa(d,e,a,b,c,h)}else gqa(b,c),d()})};
  var nqa = undefined;
  g.Xq = function(a,b,c){return Wq(0,b,0,c)};
  var ht = window;
  jt = function(){return"h5vcc"in ht&&ht.h5vcc.traceEvent?.traceBegin&&ht.h5vcc.traceEvent?.traceEnd?1:"performance"in ht&&ht.performance.mark&&ht.performance.measure?2:0};
  g.Rc = function(a,b=`unexpected value ${a}!`){throw Error(b);};
  kt = function(a){var b=jt();switch(b){case 1:ht.h5vcc.traceEvent.traceBegin("YTLR",a);break;case 2:ht.performance.mark(`${a}-start`);break;case 0:break;default:g.Rc(b,"unknown trace type")}};
  var nt = {};
  Epa = function(a){var b=jt();switch(b){case 1:ht.h5vcc.traceEvent.traceEnd("YTLR",a);break;case 2:b=`${a}-start`;let c=`${a}-end`;ht.performance.mark(c);ht.performance.measure(a,b,c);break;case 0:break;default:g.Rc(b,"unknown trace type")}};
  Fpa = function(a){var b=Array.from(a.j.keys()).sort((c,d)=>(a.j[d].priority??0)-(a.j[c].priority??0));
for(let c of b)b=a.j[c],b.jobId===void 0||b.iO||(a.scheduler.ak(b.jobId),Wq(0,b.YS,10))};
  var Gpa = undefined;
  Hpa = function(a,b,c){Gpa&&console.groupCollapsed&&console.groupEnd&&(console.groupCollapsed(`[${a.constructor.name}] '${a.state}' to '${b}'`),console.log("with message: ",c),console.groupEnd())};
  Mpa = function(a){nt&&a&&kt(a)};
  Npa = function(a){if(g.Cp("web_lifecycle_error_handling_killswitch"))return a();try{return a()}catch(b){window.onerror?.(b.message,"",0,0,b)}};
  mt = function(a){nt&&a&&Epa(a)};
  Opa = function(a,...b){return()=>{Mpa(a.name);Npa(()=>a.callback(...b));
mt(a.name)}};
  Jma = function(a){var b=g.Ia("yt.scheduler.instance.addImmediateJob");b?b(a):a()};
  Kpa = function(a,...b){g.Zq();for(let c of a)a=Opa(c,...b),Jma(a)};
  var Ppa = class{constructor(a){this.scheduler=g.Zq();this.A=new g.im;this.j=a;for(let b=0;b<this.j.length;b++){let c=this.j[b];a=()=>{c.YS();this.j[b].iO=!0;this.j.every(e=>e.iO===!0)&&this.A.resolve()};
let d=Wq(0,a,c.priority??0);this.j[b]={...c,YS:a,jobId:d}}}cancel(){for(let a of this.j)a.jobId===void 0||a.iO||this.scheduler.ak(a.jobId),a.iO=!0;this.A.resolve()}};
  Jpa = function(a,b,...c){b=b.map(d=>{var e=a.A??d.priority??0;return{YS:Opa(d,...c),priority:e}});
b.length&&(a.B=new Ppa(b))};
  var lt = undefined;
  Ipa = async function(a,...b){g.Zq();for(let c of a){let d;Jma(()=>{Mpa(c.name);var e=Npa(()=>c.callback(...b));
lt(e)?d=g.Cp("web_lifecycle_error_handling_killswitch")?e.then(()=>{mt(c.name)}):e.then(()=>{mt(c.name)},f=>{window.onerror?.(f.message,"",0,0,f);
mt(c.name)}):mt(c.name)});
d&&await d}};
  Lpa = function(a,b){var c=b.filter(e=>(a.A??e.priority??0)===10),d=b.filter(e=>(a.A??e.priority??0)!==10);
return a.D.Zna?async(...e)=>{await Ipa(c,...e);Jpa(a,d,...e)}:(...e)=>{Kpa(c,...e);
Jpa(a,d,...e)}};
  var xjb = class{constructor(){this.state="none";this.plugins=[];this.A=void 0;this.C=[];this.D={};nt&&kt(this.state)}get currentState(){return this.state}install(a){this.plugins.push(a);return this}uninstall(...a){a.forEach(b=>{b=this.plugins.indexOf(b);b>-1&&this.plugins.splice(b,1)})}transition(a,b){nt&&Epa(this.state);
var c=this.transitions.find(d=>Array.isArray(d.from)?d.from.find(e=>e===this.state&&d.to===a):d.from===this.state&&d.to===a);
if(c){this.B&&(Fpa(this.B),this.B=void 0);g.Cp("kevlar_startup_split")&&this.C.length&&(this.C.forEach(e=>{Fpa(e)}),this.C=[]);
Hpa(this,a,b);this.state=a;nt&&kt(this.state);c=c.action.bind(this);let d=this.plugins.filter(e=>e[a]).map(e=>e[a]);
c(Lpa(this,d),b)}else throw Error(`no transition specified from ${this.state} to ${a}`);}};
  var Qpa = class extends xjb{constructor(){super();this.j=null;this.A=10;this.transitions=[{from:"none",to:"application_navigating",action:this.K},{from:"application_navigating",to:"none",action:this.L},{from:"application_navigating",to:"application_navigating",action:()=>{}},
{from:"none",to:"none",action:()=>{}}]}K(a,b){this.j=g.Xq(0,()=>{this.currentState==="application_navigating"&&this.transition("none")},5E3);
a(b?.event)}L(a,b){this.j&&(g.en.ak(this.j),this.j=null);a(b?.event)}};
  ot = undefined;
  Rpa = function(){ot||(ot=new Qpa);return ot};
  Jt = function(a,b){return g.Cp("transport_use_scheduler")===!1?g.Gp(a,b):g.Cp("logging_avoid_blocking_during_navigation")||g.Cp("lr_logging_avoid_blocking_during_navigation")?g.Xq(0,()=>{Rpa().currentState==="none"?a():Rpa().install({none:{callback:a}})},b):g.Xq(0,a,b)};
  var oqa = undefined;
  var pqa = undefined;
  gqa = function(a=!1,b=200){var c=()=>{Ht({writeThenSend:!0},a,b)},d=Gt(a,b),e=d===lqa||d===mqa?5E3:nqa;
g.Cp("web_gel_timeout_cap")&&!d.A&&(e=Jt(()=>{c()},e),d.A=e);
Nt(d.B);e=g.ip("LOGGING_BATCH_TIMEOUT",g.Dp("web_gel_debounce_ms",1E4));g.Cp("shorten_initial_gel_batch_timeout")&&Ot&&(e=oqa);e=Jt(()=>{g.Dp("gel_min_batch_size")>0?zt().getSequenceCount({cttAuthInfo:void 0,isJspb:a,tier:b})>=pqa&&c():c()},e);
d.B=e};
  It = undefined;
  cqa = function(a,b=!1,c,d=!1){a&&wt(a);a=g.Dp("tvhtml5_logging_max_batch_ads_fork")||g.Dp("tvhtml5_logging_max_batch")||g.Dp("web_logging_max_batch")||100;var e=(0,g.T)(),f=Gt(b,c.tier),h=f.C;d&&(f.j=!0);d=0;c&&(d=zt().getSequenceCount(c));d>=1E3?Ht({writeThenSend:!0},b,c.tier):d>=a?It||(It=Jt(()=>{Ht({writeThenSend:!0},b,c.tier);It=void 0},0)):e-h>=10&&(gqa(b,c.tier),f.C=e)};
  dqa = function(a,b){if(a.endpoint==="log_event"){Bt(a);var c=Ct(a),d=Dt(a.payload)||"",e=$pa(d),f=200;if(e){if(e.enabled===!1&&!g.Cp("web_payload_policy_disabled_killswitch"))return;f=aqa(e.tier);if(f===400){bqa(a,b);return}}Et[c]=!0;c={cttAuthInfo:c,isJspb:!1,tier:f};zt().storePayload(c,a.payload);cqa(b,!1,c,Ft(d))}};
  Xt = function(a,b,c,d={}){var e={},f=Math.round(d.timestamp||(0,g.T)());e.eventTimeMs=f<Number.MAX_SAFE_INTEGER?f:0;e[a]=b;a=$s();e.context={lastActivityMs:String(d.timestamp||!isFinite(a)?-1:a)};d.sequenceGroup&&!g.Cp("web_gel_sequence_info_killswitch")&&(a=e.context,b=d.sequenceGroup,b={index:Hqa(b),groupKey:b},a.sequence=b,d.endOfSequence&&delete Wt[d.sequenceGroup]);g.Cp("web_tag_automated_log_events")&&(e.context.automatedLogEventSource=d.automatedLogEventSource);(d.sendIsolatedPayload?bqa:dqa)({endpoint:"log_event",
payload:e,cttAuthInfo:d.cttAuthInfo,dangerousLogToVisitorSession:d.dangerousLogToVisitorSession},c)};
  g.Zt = function(a,b,c={}){var d=g.Yt;g.ip("ytLoggingEventsDefaultDisabled",!1)&&g.Yt===g.Yt&&(d=null);Xt(a,b,d,c)};
  var Sqa = 0;
  var Tqa = ["PhantomJS","Googlebot","TO STOP THIS SECURITY SCAN go/scan"];
  jp = function(a){var b=gp.EXPERIMENT_FLAGS;return b?b[a]:void 0};
  var Uqa = [];
  Iqa = function(a=!1){Ht(void 0,a)};
  Qqa = function(a,b="ERROR"){try{Pqa.add(a.message)}catch(p){}Lqa++;if(b==="ERROR"){cu.publish("handleError",a);if(g.Cp("record_app_crashed_web")&&Rqa===0&&a.sampleWeight===1){Rqa++;var c={appCrashType:"APP_CRASH_TYPE_BREAKPAD"};g.Cp("report_client_error_with_app_crash_ks")||(c.systemHealth={crashData:{clientError:{logMessage:{message:a.message}}}});g.Zt("appCrashed",c)}Sqa++}else b==="WARNING"&&cu.publish("handleWarning",a);if(g.Cp("kevlar_gel_error_routing")){c={};b:{for(d of Tqa)if(g.eq(d.toLowerCase())){var d=
!0;break b}d=!1}if(d)c=void 0;else{var e={stackTrace:a.stack};a.fileName&&(e.filename=a.fileName);d=a.lineNumber&&a.lineNumber.split?a.lineNumber.split(":"):[];d.length!==0&&(d.length!==1||isNaN(Number(d[0]))?d.length!==2||isNaN(Number(d[0]))||isNaN(Number(d[1]))||(e.lineNumber=Number(d[0]),e.columnNumber=Number(d[1])):e.lineNumber=Number(d[0]));d={level:"ERROR_LEVEL_UNKNOWN",message:a.message,errorClassName:a.name,sampleWeight:a.sampleWeight};b==="ERROR"?d.level="ERROR_LEVEL_ERROR":b==="WARNING"&&
(d.level="ERROR_LEVEL_WARNNING");e={isObfuscated:!0,browserStackInfo:e};c.pageUrl=window.location.href;c.kvPairs=[];g.ip("FEXP_EXPERIMENTS")&&(c.experimentIds=g.ip("FEXP_EXPERIMENTS"));var f=g.ip("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS");if(!jp("web_disable_gel_stp_ecatcher_killswitch")&&f)for(var h of Object.keys(f))c.kvPairs.push({key:h,value:String(f[h])});if(h=a.params)for(var k of Object.keys(h))c.kvPairs.push({key:`client.${k}`,value:String(h[k])});if(k=a.params?.sessionReplayId)c.sessionReplayId=
String(k);k=g.ip("SERVER_NAME");h=g.ip("SERVER_VERSION");k&&h&&(c.kvPairs.push({key:"server.name",value:k}),c.kvPairs.push({key:"server.version",value:h}));(k=g.ip("PLAYER_CLIENT_VERSION"))&&c.kvPairs.push({key:"client.player.version",value:k});c={errorMetadata:c,stackTrace:e,logMessage:d}}if(c&&(g.Zt("clientError",c),b==="ERROR"||g.Cp("errors_flush_gel_always_killswitch")))a:{if(g.Cp("web_fp_via_jspb")){c=Uqa;Uqa=[];if(c)for(var l of c)Xt(l.J0,l.payload,g.Yt,l.options);Iqa(!0);if(!g.Cp("web_fp_via_jspb_and_json"))break a}Iqa()}}if(!g.Cp("suppress_error_204_logging")){l=
a.params||{};b={urlParams:{a:"logerror",t:"jserror",type:a.name,msg:a.message.substr(0,250),line:a.lineNumber,level:b,"client.name":l.name},postParams:{url:g.ip("PAGE_NAME",window.location.href),file:a.fileName},method:"POST"};l.version&&(b["client.version"]=l.version);if(b.postParams){a.stack&&(b.postParams.stack=a.stack);for(let p of Object.keys(l))b.postParams[`client.${p}`]=l[p];if(a=g.ip("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS"))for(var m of Object.keys(a))b.postParams[m]=a[m];(m=g.ip("LAVA_VERSION"))&&
(b.postParams["lava.version"]=m);m=g.ip("SERVER_NAME");a=g.ip("SERVER_VERSION");m&&a&&(b.postParams["server.name"]=m,b.postParams["server.version"]=a);(m=g.ip("PLAYER_CLIENT_VERSION"))&&(b.postParams["client.player.version"]=m)}g.Lp(`${g.ip("ECATCHER_REPORT_HOST","")}/error_204`,b)}};
  Kqa = function(a,b,c="ERROR"){if(a){a.hasOwnProperty("level")&&a.level&&(c=a.level);if(g.Cp("wiz_enable_metadata_extraction_killswitch")){var d=b;if(!d?.componentStack){var e=a.Y2?.l5;e&&(d||(d={}),d.componentStack=e)}b=d||b}else b=Jqa(a,b),d=a.Y2?.Jy,d!==void 0&&c!=="IGNORED"&&(c=d>=3?"ERROR":"WARNING");if(g.Cp("console_log_js_exceptions")||["test","dev","autopush","staging"].includes(g.ip("SERVER_VERSION")))d=[],d.push(`Name: ${a.name}`),d.push(`Message: ${a.message}`),a.hasOwnProperty("params")&&
d.push(`Error Params: ${JSON.stringify(a.params)}`),a.hasOwnProperty("args")&&d.push(`Error args: ${JSON.stringify(a.args,null,2)}`),d.push(`File name: ${a.fileName}`),d.push(`Stacktrace: ${a.stack}`),window.console.log(d.join("\n"),a);if(!(Lqa>=5)){d=[];for(f of Mqa)try{f()&&d.push(f())}catch(z){}var f=d;f=[...Nqa,...f];var h=Baa(a);d=h.message||"Unknown Error";e=h.name||"UnknownError";var k=h.stack||a.foa||"Not available";if(k.startsWith(`${e}: ${d}`)){var l=k.split("\n");l.shift();k=l.join("\n")}l=
h.lineNumber||"Not available";h=h.fileName||"Not available";let v=0;if(a.hasOwnProperty("args")&&a.args&&a.args.length)for(var m=0;m<a.args.length&&!(v=lpa(a.args[m],`params.${m}`,b,v),v>=500);m++);else if(a.hasOwnProperty("params")&&a.params){let z=a.params;if(typeof a.params==="object")for(m in z){if(!z[m])continue;let F=`params.${m}`,L=Os(z[m]);b[F]=L;v+=F.length+L.length;if(v>500)break}else b.params=Os(z)}if(f.length)for(m=0;m<f.length&&!(v=lpa(f[m],`params.context.${m}`,b,v),v>=500);m++);navigator.vendor&&
!b.hasOwnProperty("vendor")&&(b["device.vendor"]=navigator.vendor);m={message:d,name:e,lineNumber:l,fileName:h,stack:k,params:b,sampleWeight:1};b=Number(a.columnNumber);isNaN(b)||(m.lineNumber=`${m.lineNumber}:${b}`);if(a.level==="IGNORED")var p=0;else a:{a=Ls();for(p of a.ou)if(m.message&&m.message.match(p.Yr)){p=p.weight;break a}for(var q of a.Et)if(q.callback(m)){p=q.weight;break a}p=1}m.sampleWeight=p;p=m;for(var u of Oqa){if(!u.UN[p.name])continue;q=u.UN[p.name];for(let z of q){q=p.message.match(z.Ql);
if(!q)continue;p.params["params.error.original"]=q[0];a=z.groups;m={};for(b=0;b<a.length;b++)m[a[b]]=q[b+1],p.params[`params.error.${a[b]}`]=q[b+1];p.message=u.DT(m);break}}p.params||(p.params={});u=Ls();p.params["params.errorServiceSignature"]=`msg=${u.ou.length}&cb=${u.Et.length}`;p.params["params.serviceWorker"]="false";g.Ga.document&&g.Ga.document.querySelectorAll&&(p.params["params.fscripts"]=String(document.querySelectorAll("script:not([nonce])").length));window.yterr&&typeof window.yterr===
"function"&&window.yterr(p);p.sampleWeight===0||Pqa.has(p.message)||Qqa(p,c)}}};
  g.$t = function(a,b="ERROR"){var c={};c.name=g.ip("INNERTUBE_CONTEXT_CLIENT_NAME",1);c.version=g.ip("INNERTUBE_CONTEXT_CLIENT_VERSION");Kqa(a,c,b)};
  g.bu = function(a){g.$t(a,"WARNING")};
  Iz = function(a,b,c=!1,d=""){!a&&c&&g.bu(Error(`Player URL validator detects invalid url. ${d}: ${b}`));return a};
  cy = function(a){return Iz(Jz(a,fxa,gxa),a,!1,"Trusted Stream URL")};
  Km = function(a,b){this.A=this.j=null;this.B=a||null;this.C=!!b};
  g.G = Km.prototype;
  Ki = function(a,b){if(a){a=a.split("&");for(let c=0;c<a.length;c++){let d=a[c].indexOf("="),e,f=null;d>=0?(e=a[c].substring(0,d),f=a[c].substring(d+1)):e=a[c];b(e,f?kd(f):"")}}};
  Om = function(a){a.j||(a.j=new Map,a.A=0,a.B&&Ki(a.B,function(b,c){a.add(kd(b),c)}))};
  Pm = function(a,b){b=String(b);a.C&&(b=b.toLowerCase());return b};
  g.G.add = function(a,b){Om(this);this.B=null;a=Pm(this,a);var c=this.j.get(a);c||this.j.set(a,c=[]);c.push(b);this.A=this.A+1;return this};
  g.G.remove = function(a){Om(this);a=Pm(this,a);return this.j.has(a)?(this.B=null,this.A=this.A-this.j.get(a).length,this.j.delete(a)):!1};
  g.G.clear = function(){this.j=this.B=null;this.A=0};
  g.G.forEach = function(a,b){Om(this);this.j.forEach(function(c,d){c.forEach(function(e){a.call(b,e,d,this)},this)},this)};
  g.G.Hr = function(){Om(this);var a=Array.from(this.j.values()),b=Array.from(this.j.keys()),c=[];for(let d=0;d<b.length;d++){let e=a[d];for(let f=0;f<e.length;f++)c.push(b[d])}return c};
  Pja = function(a,b){Om(a);b=Pm(a,b);return a.j.has(b)};
  g.G.Eo = function(a){Om(this);var b=[];if(typeof a==="string")Pja(this,a)&&(b=b.concat(this.j.get(Pm(this,a))));else{a=Array.from(this.j.values());for(let c=0;c<a.length;c++)b=b.concat(a[c])}return b};
  g.G.set = function(a,b){Om(this);this.B=null;a=Pm(this,a);Pja(this,a)&&(this.A=this.A-this.j.get(a).length);this.j.set(a,[b]);this.A=this.A+1;return this};
  g.G.get = function(a,b){if(!a)return b;a=this.Eo(a);return a.length>0?String(a[0]):b};
  g.G.toString = function(){if(this.B)return this.B;if(!this.j)return"";var a=[],b=Array.from(this.j.keys());for(let d=0;d<b.length;d++){var c=b[d];let e=g.jd(c);c=this.Eo(c);for(let f=0;f<c.length;f++){let h=e;c[f]!==""&&(h+="="+g.jd(c[f]));a.push(h)}}return this.B=a.join("&")};
  g.G.clone = function(){var a=new Km;a.B=this.B;this.j&&(a.j=new Map(this.j),a.A=this.A);return a};
  g.Vb = function(a){var b=[],c=0;for(let d in a)b[c++]=d;return b};
  Kja = function(a){if(a.Hr&&typeof a.Hr=="function")return a.Hr();if(!a.Eo||typeof a.Eo!="function"){if(typeof Map!=="undefined"&&a instanceof Map)return Array.from(a.keys());if(!(typeof Set!=="undefined"&&a instanceof Set)){if(g.La(a)||typeof a==="string"){let b=[];a=a.length;for(let c=0;c<a;c++)b.push(c);return b}return g.Vb(a)}}};
  Ub = function(a){var b=[],c=0;for(let d in a)b[c++]=a[d];return b};
  Jja = function(a){if(a.Eo&&typeof a.Eo=="function")return a.Eo();if(typeof Map!=="undefined"&&a instanceof Map||typeof Set!=="undefined"&&a instanceof Set)return Array.from(a.values());if(typeof a==="string")return a.split("");if(g.La(a)){let b=[],c=a.length;for(let d=0;d<c;d++)b.push(a[d]);return b}return Ub(a)};
  Lja = function(a,b,c){if(a.forEach&&typeof a.forEach=="function")a.forEach(b,c);else if(g.La(a)||typeof a==="string")Array.prototype.forEach.call(a,b,c);else{let d=Kja(a),e=Jja(a),f=e.length;for(let h=0;h<f;h++)b.call(c,e[h],d&&d[h],a)}};
  g.G.extend = function(a){for(let b=0;b<arguments.length;b++)Lja(arguments[b],function(c,d){this.add(d,c)},this)};
  Jm = function(a,b){return a?b?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""};
  g.Fm = function(a,b,c){a.D=c?Jm(b,!0):b;a.D&&(a.D=a.D.replace(/:$/,""))};
  g.Gm = function(a,b,c){a.j=c?Jm(b,!0):b};
  g.Hm = function(a,b){if(b){b=Number(b);if(isNaN(b)||b<0)throw Error("Bad port number "+b);a.B=b}else a.B=null};
  var Nja = /[#\?@]/g;
  Oja = function(a){a=a.charCodeAt(0);return"%"+(a>>4&15).toString(16)+(a&15).toString(16)};
  Lm = function(a,b,c){return typeof a==="string"?(a=encodeURI(a).replace(b,Oja),c&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null};
  g.yb = function(a){var b=a.length;if(b>0){let c=Array(b);for(let d=0;d<b;d++)c[d]=a[d];return c}return[]};
  g.Qja = function(a,b,c){a.remove(b);c.length>0&&(a.B=null,a.j.set(Pm(a,b),g.yb(c)),a.A=a.A+c.length)};
  Mja = function(a,b){b&&!a.C&&(Om(a),a.B=null,a.j.forEach(function(c,d){var e=d.toLowerCase();d!=e&&(this.remove(d),g.Qja(this,e,c))},a));
a.C=b};
  Im = function(a,b,c){b instanceof Km?(a.C=b,Mja(a.C,a.L)):(c||(b=Lm(b,Nja)),a.C=new Km(b,a.L))};
  g.Em = function(a){this.j=this.U=this.D="";this.B=null;this.K=this.A="";this.L=!1;var b;a instanceof g.Em?(this.L=a.L,g.Fm(this,a.D),this.U=a.U,g.Gm(this,a.j),g.Hm(this,a.B),this.A=a.A,Im(this,a.C.clone()),this.K=a.K):a&&(b=g.Gi(String(a)))?(this.L=!1,g.Fm(this,b[1]||"",!0),this.U=Jm(b[2]||""),g.Gm(this,b[3]||"",!0),g.Hm(this,b[4]),this.A=Jm(b[5]||"",!0),Im(this,b[6]||"",!0),this.K=Jm(b[7]||"")):(this.L=!1,this.C=new Km(null,this.L))};
  g.Nm = function(a){return a instanceof g.Em?a.clone():new g.Em(a)};
  var mV = {TP:function(a,b){a[w[23]](0,b)},
DH:function(a){a[w[56]]()},
AD:function(a,b){var c=a[0];a[0]=a[b%a[w[4]]];a[b%a[w[4]]]=c}};
  dy = function(a,b,c){var d=b^a;if((a-6^21)<a&&(a+7&29)>=a){var e=c[w[d^8673]](w[d^8697]);let h=0;e[0]||h++;let k={};for(;h<e[w[4]];h+=2)e[h]&&by(2,d^13532,k,e[h],e[h+1]);var f=k}a-8<<1<a&&(a-8^17)>=a&&(ay(1,d^2813,c),f=c[w[d^5880]]);((a^82)&15)==3&&(e=c[w[d^6613]](w[d^6599]),mV[w[d^6621]](e,1),mV[w[d^6651]](e,1),mV[w[d^6621]](e,1),mV[w[d^6651]](e,d^6644),mV[w[d^6621]](e,2),mV[w[d^6530]](e,d^6654),mV[w[d^6530]](e,d^6613),f=e[w[d^6603]](w[d^6599]));a+3&7||(f=encodeURIComponent(c));((a^53)&15)==3&&(f=
c!==null);return f};
  IH = function(a,b,c,d,e,f,h){var k;(a+6&25)>=a&&(a+5&43)<a&&(k=d(e,f,h));(a-4|10)<a&&(a-8|34)>=a&&(k=decodeURIComponent(c));return k};
  bl = function(a,b,c,d){var e=b^a;if((a+8&7)>=5&&a>>2<20){for(var f=e^6668,h=[];++f-h[w[4]]-(e^6764);){switch(f){case e^6774:f-=e^6722;case e^6679:case e^6672:case e^6673:continue;case e^6711:f=e^6755;case e^6674:case e^6675:case e^6700:continue;case e^6754:f=e^6675}h[w[e^6764]](String[w[e^6762]](f))}var k=h}a+7>>1>=a&&(a-5|33)<a&&(ay(3,e^3405,c),f=IH(e^4442,e^5165,c[w[e^4444]](w[e^4427])||w[e^4419])[w[e^4433]](w[e^4473]),k=c[w[3]]===w[e^4424]&&f[w[4]]>1&&!!f[1]);(a^21)>>3==1&&((c[e^2883]===-3||((0,c[e^
2829])((0,c[e^2935])((0,c[e^2932])(),c[e^2840],c[e^2831]),c[e^2926],(0,c[0])(c[e^2901],c[e^2830]),c[e^2842],c[e^2898]),0))&&(0,c[e^2819])(((0,c[e^2843])(c[e^2898],c[e^2905]),c[e^2915])(c[4],c[e^2897]),c[e^2920],c[3],c[4]),c[e^2845]!=new Date(w[e^2830])/(e^2214)&&(c[new Date(w[e^2900])/(e^2214)]>=-(e^2884)||((0,c[new Date(w[e^2820])/(e^2214)])(c[4],c[e^2903]),0))&&(0,c[e^2844])(c[4],c[e^2928]),c[e^2818]<=-6&&(c[3]!==3&&((0,c[e^2937])(c[e^2920],(0,c[e^2920])(c[e^2918],c[e^2832]),(0,c[e^2915])(c[e^2884],
c[e^2931]),(0,c[e^2831])((0,c[2])(),c[e^2843],c[e^2841]),c[5],c[e^2925]),1)||((0,c[e^2818])((0,c[e^2923])(c[e^2819],c[e^2825]),c[5],(0,c[6])(),c[e^2924],c[e^2883]),c[e^2818])((0,c[e^2847])(c[3],c[e^2900]),c[5],(0,c[e^2920])(),c[e^2924],c[e^2883])),(c[e^2840]<-(e^2884)||((0,c[e^2928])(c[e^2926],c[e^2912]),0))&&(0,c[e^2842])(c[e^2912],c[e^2905]),c[e^2919]>-1?(((((((((((0,c[e^2923])(c[e^2887],c[3]),c[e^2842])(c[e^2901],c[e^2913]),c[new Date(w[e^2938])/(e^2214)])(c[e^2912]),(((0,c[5])((0,c[e^2939])(),
c[e^2903],c[e^2901]),c[e^2914])(c[new Date(w[e^2912])/(e^2214)],c[e^2824]),c[e^2842])(c[e^2901],c[e^2840]),c[5])((0,c[e^2939])(),c[e^2903],c[e^2901]),c[e^2880])((0,c[e^2847])(c[e^2835],c[e^2823]),c[e^2842],(0,c[5])((0,c[6])(),c[e^2903],c[3]),c[e^2901],c[e^2836]),((((0,c[e^2842])(c[3],c[e^2934]),c[e^2845])(c[e^2912]),c[e^2847])(c[e^2912],c[e^2829]),c[e^2842])(c[3],c[e^2821]),c[4])(c[e^2835]),c[e^2842])(c[e^2901],c[e^2932]),c[e^2928])(c[e^2922],c[e^2901]),c[e^2818])(((0,c[e^2842])(c[e^2825],c[e^2941]),
c[5])((0,c[e^2920])(),c[e^2930],c[3]),c[e^2928],c[e^2844],c[e^2883]),c[5])((0,c[e^2920])(),c[e^2930],c[e^2883]),c[(e^3055)%(new Date(w[e^2831])/(e^2214))-1-(e^2818)])(c[3],c[e^2822]):((((0,c[e^2847])(c[e^2835],c[e^2907]),c[e^2940])((((0,c[4])(c[e^2825]),c[e^2837])(c[e^2902]),c[e^2842])(c[e^2883],c[e^2831]),c[e^2818],((((((0,c[e^2923])(c[e^2833],c[3]),c[e^2928])(c[e^2909],c[3]),c[e^2914])(c[e^2825],c[e^2942]),(0,c[e^2932])((0,c[e^2884])(c[e^2936],c[e^2913]),c[e^2838],(0,c[e^2902])((0,c[e^2943])((0,c[e^
2927])(),c[e^2886],c[e^2913]),c[e^2847],c[e^2889],c[new Date(w[e^2839])/(e^2214)]),c[e^2900],c[e^2943]),c[e^2899])(c[e^2925],c[e^2909]),c[e^2922])(c[e^2920],c[e^2937]),c[new Date(w[e^2842])/(e^2214)])(c[new Date(w[e^2913])/(e^2214)+(e^2881)],c[e^2840]),(0,c[e^2827])(c[e^2938],(0,c[e^2938])(c[new Date(w[e^2824])/(e^2214)],c[e^2882]),(0,c[e^2828])(c[e^2835],c[e^2904]),(0,c[e^2817])(c[e^2832],c[e^2842]),c[e^2938],c[e^2828]),(0,c[1])(c[e^2886],c[e^2926]),c[1],c[e^2911],c[e^2926]),c[e^2822])(c[e^2939],
c[e^2942]),c[e^2905])(c[e^2926],c[new Date(w[e^2844])/(e^2214)]),c[e^2882]!==-6&&(0,c[e^2921])(c[e^2928]),c[e^2832]!==-6&&(((0,c[e^2881])((0,c[e^2904])(c[e^2926]),c[e^2905],c[e^2938],c[e^2843]),c[e^2836])(c[e^2902],c[e^2939]),(0,c[e^2827])(c[e^2917]),c[e^2825])(c[e^2917],c[4]),c[e^2828]!=5&&(c[e^2881]===-2&&((0,c[e^2826])(c[e^2939],c[e^2831]),{})||(0,c[e^2826])(c[e^2899],c[e^2823])),c[(e^2882)+(new Date(w[e^2942])/(e^2214))**5%(e^2794)]>-2&&((0,c[e^2818])((0,c[e^2836])(c[e^2830],c[e^2899]),c[e^2882],
c[e^2917],c[e^2930]),(0,c[e^2826])(c[e^2899],c[e^2840]),c[e^2825])(c[e^2939],c[e^2915]),k=[]);if((a-6^28)>=a&&(a+2&42)<a)for(d=(d%c[w[4]]+c[w[4]])%c[w[4]];d--;)c[w[e^6132]](c[w[e^6139]]());return k};
  Rga = function(a,b){return bl[w[5]](this,10,6105,a,b)};
  Sga = function(a,b,c,d,e,f,h,k,l,m){return by[w[5]](this,12,1163,a,b,c,d,e,f,h,k,l,m)};
  Tga = function(){return ay[w[5]](this,64,4622)};
  raa = function(a,b,c,d,e,f,h){return lc[w[5]](this,16,1795,a,b,c,d,e,f,h)};
  KWa = function(a){return dy[w[5]](this,6,1100,a)};
  tH = function(a,b,c){var d=b^a;if(!((a^6)>>4)){ay(6,d^3441,c);var e=g.Pb(c[w[d^4461]],KWa)}if((a-1|31)>=a&&(a+7^26)<a){for(var f=d^947,h=[];++f-h[w[4]]-(d^979);){switch(f){case d^936:f=d^991;continue;case d^904:f=d^946;break;case d^946:f-=d^993;continue;case d^969:f=d^915;continue;case d^989:f=d^940}h[w[d^979]](String[w[d^981]](f))}e=h}return e};
  var rVa = {};
  Qr = function(a,b,c,d){var e=b^a;if((a&107)==a){ay(4,e^7604,c);var f=c[w[e^409]]+(c[w[e^409]]?w[e^500]:w[e^484])+c[w[e^436]]+c[w[3]];if(tH(1,e^4294,c)){let l=[];g.Mb(c[w[e^426]],(m,p)=>{m!==null&&l[w[e^410]](`${p}=${m}`)});
f+=`?${l[w[e^433]](w[e^425])}`}var h=f}if((a&103)==a)a:{var k=g.R(c,rVa)||c[w[e^1875]];f={rZ:!1,AF:w[e^1809],pJ:w[e^1809],s:w[e^1809]};if(!k){h=f;break a}k=qp(k);f[w[e^1866]]=!0;f[w[e^1862]]=k[w[e^1851]];f[w[e^1843]]=k[w[e^1883]];f[w[e^1852]]=k[w[e^1852]];h=f}if(!((a^49)>>4)){f=e^463;for(k=[];++f-k[w[4]]-(e^431);)switch(f){case e^417:f=e^464;default:k[w[e^431]](String[w[e^425]](f));case e^465:case e^464:case e^495:break;case e^500:f-=e^451;case e^467:case e^466:continue;case e^437:f=e^419;case e^
468:}h=k}(a-2^14)<a&&(a+5^5)>=a&&d[w[4]]!=0&&(f=ey(20,16,c,d),c=f[0]);return h};
  Uga = function(a,b){return Qr[w[5]](this,12,2217,a,b)};
  Vga = function(a,b,c,d,e){return IH[w[5]](this,11,6727,a,b,c,d,e)};
  ija = function(a,b,c,d){var e=b^a,f;(a-3&8)<2&&a-6>>3>=1&&c[w[4]]!=0&&(d=(d%c[w[4]]+c[w[4]])%c[w[4]],c[w[23]](0,1,c[w[23]](d,1,c[0])[0]));(a-8^23)>=a&&(a+8&11)<a&&(d=(d%c[w[4]]+c[w[4]])%c[w[4]],c[w[e^4874]](d,1));return f};
  Wga = function(a,b){return ija[w[5]](this,24,3612,a,b)};
  Xga = function(a){return lc[w[5]](this,22,7313,a)};
  Yga = function(a,b){return ija[w[5]](this,8,4885,a,b)};
  Zga = function(){return Qr[w[5]](this,50,445)};
  $ga = function(a){return by[w[5]](this,9,8757,a)};
  aha = function(a,b,c){return lc[w[5]](this,8,8250,a,b,c)};
  bha = function(){return tH[w[5]](this,16,995)};
  cha = function(a,b,c,d,e,f){return by[w[5]](this,47,8793,a,b,c,d,e,f)};
  dha = function(a,b,c,d,e,f,h,k){return ey[w[5]](this,24,7825,a,b,c,d,e,f,h,k)};
  eha = function(a,b){return hha[w[5]](this,20,3671,a,b)};
  fha = function(){return bl[w[5]](this,5,6729)};
  var gha = -206606788;
  Mj = function(a,b,c){var d=b^a,e;a+5>>4>=2&&(a+1&8)<4&&(e=c[w[2]]?c[w[2]][w[22]](w[63]):c[w[35]]===w[63]);(a^30)>>4||((0,c[d^3143])((0,c[d^3096])(c[d^3119],c[d^3104]),c[d^3148],c[d^3094],c[d^3155]),(0,c[d^3135])(c[d^3104]),(0,c[d^3148])(c[d^3094],c[d^3088]),(0,c[d^3096])(c[d^3107],c[d^3134])===(0,c[d^3153])(c[d^3126],c[d^3073]),(0,c[d^3128])((0,c[d^3152])(),c[d^3101],c[d^3134]),(0,c[d^3148])(c[d^3162],c[d^3077]),(0,c[d^3148])(c[d^3104],c[d^3100]),e=[]);return e};
  hha = function(a,b,c,d){var e=b^a;a-1>>4<2&&(a>>2&7)>=4&&(c=(c%d[w[4]]+d[w[4]])%d[w[4]],d[w[e^3668]](-c)[w[e^3707]]()[w[e^3697]](function(m){d[w[e^3684]](m)}));
if(((a|9)&5)==1)a:{var f=c[w[e^3254]](w[e^3236]),h=[Rga,e^1880283108,null,-(e^486411720),-(e^359314615),-(e^1364942494),Sga,e^2041982452,e^1081928021,Tga,raa,e^355644708,e^249830153,-(e^1238884123),-(e^783482747),e^1708655748,w[e^3218],e^1900791075,Uga,e^274639668,e^2062026563,e^1588827125,e^8381531,e^557693514,-(e^263136074),-(e^1650676325),-(e^1348742874),null,e^384554564,e^99048904,e^1164159178,-(e^1546207703),Vga,e^1878176243,-(e^1998961942),e^10236744,e^648015910,Wga,e^555332478,Xga,Yga,Zga,
e^693878479,e^1284022898,-(e^1901189794),-(e^660220297),-(e^1287318437),e^2134679520,e^1051402310,null,e^1515615526,e^52392711,e^1582468366,e^688771471,-(e^303530765),f,$ga,aha,bha,e^6382680,e^208887807,e^1966369690,e^1576414159,-(e^86073711),e^1766481550,f,cha,dha,-(e^440891727),w[e^3300],-(e^823877909),-(e^2134768185),e^1880283108,-(e^1646139667),e^1365378652,-(e^827877495),-(e^1617448930),w[e^3321],-(e^1211419419),f,-(e^355666420),e^728200433,e^1164159178,w[e^3231],e^2058964835,-(e^185078407),
w[e^3304],-(e^123556756),e^952403913,eha,fha,e^6382680,w[e^3307],-(e^1106487967),-(e^263136074),-(e^355666420)];h[2]=h;h[e^3256]=h;h[e^3218]=h;if(typeof gha===w[e^3216]){var k=c;break a}try{try{var l=bl(e^3259,e^2037,h)}catch(m){h=Mj(e^3251,e^184,h)}}catch(m){k=w[e^3306]+c;break a}k=f[w[e^3240]](w[e^3236])}return k};
  lc = function(a,b,c,d,e,f,h,k,l){var m=b^a,p;(a>>1&7)<2&&(a|3)>>4>=0&&(p=c(h,k,l));if(((a^71)&14)==2){var q=hha(1,m^201,c);d[w[6]](w[m^3169],q);p=[]}if((a&108)==a){var u=c[w[4]];e[w[m^8192]](function(v,z,F){this[w[m^8210]](F[z]=c[(c[w[m^8250]](v)-c[w[m^8250]](this[z])+z+u--)%c[w[4]]])},d[w[m^8231]](w[m^8245]))}(a+5^32)>=a&&(a-6^24)<a&&c[w[56]]();
return p};
  ey = function(a,b,c,d,e,f,h,k,l,m){var p=b^a,q;(a|24)==a&&(q=d(e,f,h,k,l,m));if(!((a^3)>>4)){var u;ay(1,p^3514,c);(u=c[w[p^4513]][w[p^4539]]||null)&&(u=lc(p^4517,p^7630,u,c));q=[]}(a>>1&7)==2&&(c=(c%d[w[4]]+d[w[4]])%d[w[4]],u=d[0],d[0]=d[c],d[c]=u,q=[c]);return q};
  ay = function(a,b,c,d,e){var f=b^a;if((a-5^5)<a&&(a+7&10)>=a&&c[w[2]])var h=ay(52,6362,c);if((a|24)==a){h=c[w[f^7053]](w[f^7048],f^7049);var k=c[w[f^7053]](w[f^7048],h+1);h>0&&k>0?(d[w[3]]=c[w[f^7066]](0,k),c=c[w[f^7066]](k+1)):(d[w[3]]=c,c=w[f^7042]);var l=[c]}a-8<41&&(a|9)>=25&&(h=c[d],k=h[w[f^5432]](w[f^5385]),k>0?by(1,f^27,e,h[w[f^5423]](0,k),h[w[f^5423]](k+1)):h&&(e[h]=w[f^5431]),l=[]);if((a>>1&10)<10&&a-8>=16){h=f^4622;for(k=[];++h-k[w[4]]-(f^4718);)switch(h){case f^4724:h=f^4654;continue;case f^
4629:h=f^4706;break;case f^4623:h=f^4705;continue;case f^4704:h=f^4823;case f^4661:h-=f^4724;default:k[w[f^4718]](String[w[f^4712]](h))}l=k}if((a-1^13)>=a&&(a+9&25)<a){if(!(cy(c[w[2]])||c[w[2]][w[f^6392]](w[f^6353])||c[w[2]][w[f^6392]](w[f^6328])||c[w[2]][w[f^6392]](w[f^6394])))throw new g.Vq(w[f^6326],c[w[2]]);h=g.Nm(c[w[2]]);c[w[f^6349]]=h[w[f^6305]];c[w[f^6368]]=h[w[f^6398]]+(h[w[f^6368]]!=null?`:${h[w[f^6368]]}`:w[f^6377]);k=h[w[2]];k[w[f^6392]](w[f^6370])?(c[w[3]]=w[f^6370],k=k[w[f^6385]](f^
6368)):k[w[f^6392]](w[0])?(c[w[3]]=w[0],k=k[w[f^6385]](f^6371)):k[w[f^6392]](w[f^6323])?(k=ay(f^6354,f^855,k,c),k=k[0]):(c[w[3]]=k,k=w[f^6377]);var m=c[w[f^6398]];c[w[f^6398]]=dy(3,f^14617,k);Object[w[f^6356]](c[w[f^6398]],by(f^6397,f^5637,h[w[f^6391]][w[f^6375]]()));Object[w[f^6356]](c[w[f^6398]],m);c[w[f^6398]][w[f^6399]]===w[f^6317]&&(delete c[w[f^6398]][w[f^6399]],c[w[3]]+=w[1]);c[w[2]]=w[f^6377];c[w[f^6339]]=w[f^6377];c[w[f^6391]]&&(h=ey(1,f^2398,c));l=[]}return l};
  g.ec = function(a){var b={};for(let c in a)b[c]=a[c];return b};
  g.JH = class{constructor(a,b=!1){this[w[2]]=a;this[w[25]]=b;this[w[35]]=w[7];this[w[3]]=w[7];this[w[14]]=w[7];this[w[16]]={};this[w[45]]=w[7]}set(a,b){this[w[16]][a]!==b&&(this[w[16]][a]=b,this[w[45]]=w[7])}get(a){ay(8,7170,this);return this[w[16]][a]||null}gf(){this[w[45]]||(this[w[45]]=Qr(8,434,this));return this[w[45]]}clone(){var a=new g.JH(this[w[2]],this[w[25]]);a[w[35]]=this[w[35]];a[w[3]]=this[w[3]];a[w[14]]=this[w[14]];a[w[16]]=g.ec(this[w[16]]);a[w[45]]=this[w[45]];return a}};
  mI = function(a,b="",c=""){a=new g.JH(a,!0);a.set("alr","yes");c&&(c=dy(33,6625,IH(28,1387,c)),a[w[6]](b,dy(21,8188,c)));return a};
  //#endregion --- end [nsigFunction] ---

  function nsigFunction(a, b, c) {
    return mI(a, b, c);
  }

  const rawValues = {
    "nsigFunction": "mI",
    "signatureTimestampVar": "20770"
  };

  return { nsigFunction, rawValues };
})({});

// Adapted from YouTube.js getNsigProcessorFn (MIT, Copyright 2021 LuanRT).
function process(n = "", sp = "", s = "") {
  const mockURL = "https://ytjs.googlevideo.com/videoplayback?expire=1234567890&n=" + encodeURIComponent(n);
  const ctor = exportedVars.nsigFunction(mockURL, sp, s);
  for (const prop of Object.getOwnPropertyNames(Object.getPrototypeOf(ctor))) {
    if (!["constructor", "clone", "set", "get"].includes(prop) && typeof ctor[prop] === "function") ctor[prop]();
  }
  const sig = ctor.get(sp), nsig = ctor.get("n");
  return { sig: sig ? decodeURIComponent(sig) : undefined, n: nsig ? decodeURIComponent(nsig) : undefined };
}
const request = JSON.parse(std.in.getline());
print(JSON.stringify(process(request.n || "", request.sp || "", request.sig || "")));

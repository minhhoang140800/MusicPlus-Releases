Music Plus 0.9.2 — Windows x64

Fix selectable text colors, full artist songs endpoint/pagination, isolated album tracks.
Settings is an in-app overlay: X or Escape to close; outside clicks pulse the border.

Use Settings > Check for updates in 0.9.1, or close the app completely and extract/overwrite this ZIP.
%LOCALAPPDATA%\MusicPlus8 retains your existing account/settings/cache.
Build and 25 fixture/policy checks passed. Actual Windows UI/updater/live YouTube testing
is still required; no live-account speed or full catalog completeness claims.

# Music Plus 0.9.1

Windows x64, .NET Framework 4.8 + WebView2 Runtime. Compact ZIP, no installer.

## Cập nhật giữ dữ liệu

Thoát hẳn app (kể cả khay hệ thống), giải nén toàn bộ ZIP và chép đè vào thư mục app cũ.
Mở MusicPlus.exe. Không xóa %LOCALAPPDATA%\MusicPlus8: thư mục này lưu đăng nhập,
cài đặt, metadata, cache và thứ tự Library trên máy Windows hiện tại.
Không sao chép dữ liệu đăng nhập cho người khác. Máy/tài khoản Windows khác phải đăng nhập riêng.
Không có updater hay dịch vụ chạy nền mới. Có thể giữ bản ZIP cũ để rollback;
trước khi thử bản mới nên sao lưu dữ liệu app trên chính máy của mình.

## Thay đổi

- Double-click playlist trong Add to playlist để xác nhận.
- Playlist đang phát có màu hồng và vạch bên trái, khác playlist đang chọn.
- Dòng đầu dropdown Search là tên gợi ý/từ khóa tìm kiếm; các dòng sau là kết quả.
- Lyrics: tên bài in đậm, artist nhỏ hơn bên dưới; cỡ lời bài hát giảm 10%.
- Copy title/artist/album trong menu chuột phải; artist/album có menu Copy riêng.
- Nút Back cạnh ô Search khôi phục kết quả, bộ lọc và vị trí cuộn trước khi mở trang khác.
- Artist/album trong các hàng là link; giữ từng artist theo endpoint YouTube cung cấp.
  Nếu thiếu endpoint, tra cứu đúng tên khi bấm; không tự chọn kết quả tên khác.
- Placeholder Search dịch sang phải 6px.

## Source và build

Source khôi phục từ binary 0.8.11, sau đó sửa cho 0.8.12 và 0.9.1. Không phải source gốc.
Engine audio native giữ nguyên 0.8.11; source engine native không có. Không tích hợp Test5/Free mới.
Runtime và license của các thành phần được giữ trong runtime/.

Build Windows: cài .NET SDK 8, chạy ./Build.ps1. GitHub Actions cũng build khi push tag v*.
Test portable: dotnet run --project tests/tests.csproj (fixtures metadata/order/notifications;
shim serializer chỉ dùng để compile fixture parser, không kiểm thử JSON/network thực).
Build Linux cross-compile đạt; giao diện WPF, login/API/live audio chưa được chạy trên Windows
trong môi trường tạo bản ZIP. Cần kiểm thử thực tế trước khi coi là bản ổn định.
Không đưa cookie, settings, cache, logs tài khoản vào repo.

## 0.9.1 fixes

Selectable title/album/artist text (drag then Ctrl+C); hover underline on metadata links.
Settings > Check for updates reads only the public manifest in MusicPlus-Releases.
No login/token and no background polling. Download is bounded, SHA-256 checked, path validation
rejects traversal; staged assembly version must match. A temporary PowerShell helper waits for
this process to exit, backs up replaced files, copies the staged app and restarts it; failure
attempts rollback. No files in the MusicPlus8 data root are overwritten. Install once manually
to get this button. Windows helper/rollback still require real-device verification.

Playlist Add uses the loaded Library when available; a confirmed setVideoId updates the shown
playlist locally, with refresh fallback when YouTube omits the identifier. Remove changes the
shown rows immediately after confirmation and restores on API failure. Network timing is logged.
Audio chunk copies avoid dispatching each chunk to WPF; HTTP connection cap raised to 8 so
API calls and range transfers need not queue behind the .NET default limit. This does not prove
a measured latency improvement; cold tracks still require complete download/remux.
